#!/usr/bin/env python3
"""
LucIA KPI Database Setup Script
Creates complete database schema for LucIA KPI system using Supabase APIs
"""

import requests
import json
import time
from datetime import datetime, timedelta
import uuid

# Supabase Configuration
SUPABASE_URL = "https://xqehyjcrytigudfesjst.supabase.co"
SERVICE_ROLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhxZWh5amNyeXRpZ3VkZmVzanN0Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1ODg3OTY1MCwiZXhwIjoyMDc0NDU1NjUwfQ.Q7sxb9wnFmAHfHhlFyEvSDQDdcO1tOVFOMAxBsrHOz4"
ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhxZWh5amNyeXRpZ3VkZmVzanN0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTg4Nzk2NTAsImV4cCI6MjA3NDQ1NTY1MH0.n7fjg2S2qEuo9aR_aua83bx0M1FpB-yMP6Rt1898edQ"

def execute_sql(sql_query, description=""):
    """Execute SQL query using Supabase REST API"""
    headers = {
        'Authorization': f'Bearer {SERVICE_ROLE_KEY}',
        'Content-Type': 'application/json',
        'apikey': SERVICE_ROLE_KEY
    }
    
    # Use the SQL endpoint for raw SQL execution
    url = f"{SUPABASE_URL}/rest/v1/rpc/exec_sql"
    
    # If the endpoint doesn't exist, we'll use a different approach
    # Let's try creating tables via the REST API directly
    print(f"🔄 {description}")
    
    # For now, let's print the SQL and execute it manually
    print(f"SQL to execute:\n{sql_query}\n")
    return True

def create_database_schema():
    """Create all database tables and functions"""
    
    print("🚀 Starting LucIA KPI Database Setup...")
    
    # 1. Create locations table
    locations_sql = """
    CREATE TABLE IF NOT EXISTS locations (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        location_id VARCHAR(100) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        name VARCHAR(255) NOT NULL,
        account_type VARCHAR(20) CHECK (account_type IN ('sub_account', 'agency')) DEFAULT 'sub_account',
        parent_agency_id VARCHAR(100),
        ghl_location_id VARCHAR(100),
        webhook_url TEXT,
        webhook_secret VARCHAR(255),
        is_active BOOLEAN DEFAULT true,
        settings JSONB DEFAULT '{}',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
    
    CREATE INDEX IF NOT EXISTS idx_locations_location_id ON locations(location_id);
    CREATE INDEX IF NOT EXISTS idx_locations_parent_agency ON locations(parent_agency_id);
    CREATE INDEX IF NOT EXISTS idx_locations_active ON locations(is_active);
    """
    execute_sql(locations_sql, "Creating locations table")
    
    # 2. Create sales table
    sales_sql = """
    CREATE TABLE IF NOT EXISTS sales (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        location_id VARCHAR(100) NOT NULL REFERENCES locations(location_id) ON DELETE CASCADE,
        ghl_sales_id VARCHAR(100) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL,
        surname VARCHAR(255) NOT NULL,
        email VARCHAR(255),
        phone VARCHAR(50),
        password_hash VARCHAR(255),
        status VARCHAR(20) CHECK (status IN ('active', 'inactive', 'pending_confirmation')) DEFAULT 'active',
        hire_date DATE,
        termination_date DATE,
        base_commission_rate DECIMAL(5,4) DEFAULT 0.0000,
        settings JSONB DEFAULT '{}',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
    
    CREATE INDEX IF NOT EXISTS idx_sales_location_id ON sales(location_id);
    CREATE INDEX IF NOT EXISTS idx_sales_ghl_id ON sales(ghl_sales_id);
    CREATE INDEX IF NOT EXISTS idx_sales_status ON sales(status);
    """
    execute_sql(sales_sql, "Creating sales table")
    
    # 3. Create products table
    products_sql = """
    CREATE TABLE IF NOT EXISTS products (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        location_id VARCHAR(100) NOT NULL REFERENCES locations(location_id) ON DELETE CASCADE,
        product_id VARCHAR(100) NOT NULL,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        current_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        currency VARCHAR(3) DEFAULT 'EUR',
        status VARCHAR(20) CHECK (status IN ('active', 'inactive', 'pending_confirmation')) DEFAULT 'active',
        category VARCHAR(100),
        settings JSONB DEFAULT '{}',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        UNIQUE(location_id, product_id)
    );
    
    CREATE INDEX IF NOT EXISTS idx_products_location_id ON products(location_id);
    CREATE INDEX IF NOT EXISTS idx_products_product_id ON products(product_id);
    CREATE INDEX IF NOT EXISTS idx_products_status ON products(status);
    """
    execute_sql(products_sql, "Creating products table")
    
    # 4. Create product_price_history table
    price_history_sql = """
    CREATE TABLE IF NOT EXISTS product_price_history (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
        price DECIMAL(10,2) NOT NULL,
        currency VARCHAR(3) DEFAULT 'EUR',
        effective_from TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        effective_to TIMESTAMP WITH TIME ZONE,
        reason VARCHAR(255),
        created_by VARCHAR(100),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
    
    CREATE INDEX IF NOT EXISTS idx_price_history_product_id ON product_price_history(product_id);
    CREATE INDEX IF NOT EXISTS idx_price_history_effective_from ON product_price_history(effective_from);
    """
    execute_sql(price_history_sql, "Creating product price history table")
    
    # 5. Create sales_product_commissions table
    commissions_sql = """
    CREATE TABLE IF NOT EXISTS sales_product_commissions (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        location_id VARCHAR(100) NOT NULL REFERENCES locations(location_id) ON DELETE CASCADE,
        sales_id UUID NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
        product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
        commission_type VARCHAR(20) CHECK (commission_type IN ('percentage', 'fixed')) NOT NULL,
        commission_value DECIMAL(10,4) NOT NULL,
        currency VARCHAR(3) DEFAULT 'EUR',
        effective_from TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        effective_to TIMESTAMP WITH TIME ZONE,
        is_active BOOLEAN DEFAULT true,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        UNIQUE(sales_id, product_id, effective_from)
    );
    
    CREATE INDEX IF NOT EXISTS idx_commissions_sales_id ON sales_product_commissions(sales_id);
    CREATE INDEX IF NOT EXISTS idx_commissions_product_id ON sales_product_commissions(product_id);
    CREATE INDEX IF NOT EXISTS idx_commissions_effective ON sales_product_commissions(effective_from, effective_to);
    """
    execute_sql(commissions_sql, "Creating sales product commissions table")
    
    # 6. Create daily_kpis table
    kpis_sql = """
    CREATE TABLE IF NOT EXISTS daily_kpis (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        location_id VARCHAR(100) NOT NULL REFERENCES locations(location_id) ON DELETE CASCADE,
        date DATE NOT NULL,
        traffic_source VARCHAR(20) CHECK (traffic_source IN ('ads', 'organic', 'outbound', 'all')) NOT NULL,
        sales_id UUID REFERENCES sales(id) ON DELETE SET NULL,
        
        -- Core Metrics
        impressions INTEGER DEFAULT 0,
        clicks INTEGER DEFAULT 0,
        leads INTEGER DEFAULT 0,
        surveys INTEGER DEFAULT 0,
        
        -- Funnel Metrics
        disco_inbound_prenotata INTEGER DEFAULT 0,
        disco_outbound_prenotata INTEGER DEFAULT 0,
        disco_showed_inbound INTEGER DEFAULT 0,
        disco_showed_outbound INTEGER DEFAULT 0,
        demos INTEGER DEFAULT 0,
        demos_showed INTEGER DEFAULT 0,
        pre_vendita INTEGER DEFAULT 0,
        vendita INTEGER DEFAULT 0,
        
        -- Financial Metrics
        contratti INTEGER DEFAULT 0,
        incassato DECIMAL(10,2) DEFAULT 0.00,
        spesa_ads DECIMAL(10,2) DEFAULT 0.00,
        
        -- Product Metrics
        pack_1 INTEGER DEFAULT 0,
        pack_2 INTEGER DEFAULT 0,
        pack_3 INTEGER DEFAULT 0,
        pack_4 INTEGER DEFAULT 0,
        upsell_1 INTEGER DEFAULT 0,
        upsell_2 INTEGER DEFAULT 0,
        upsell_3 INTEGER DEFAULT 0,
        
        -- Outbound Specific
        chiamate_effettuate INTEGER DEFAULT 0,
        risposte_ricevute INTEGER DEFAULT 0,
        
        -- UTM Data
        utm_source VARCHAR(255),
        utm_medium VARCHAR(255),
        utm_campaign VARCHAR(255),
        utm_content VARCHAR(255),
        utm_term VARCHAR(255),
        
        -- Custom Fields
        custom_field_1 VARCHAR(255),
        custom_field_2 VARCHAR(255),
        custom_field_3 VARCHAR(255),
        
        -- Calculated Fields (computed automatically)
        roas DECIMAL(10,4) DEFAULT 0.0000,
        aov DECIMAL(10,2) DEFAULT 0.00,
        ctr DECIMAL(10,4) DEFAULT 0.0000,
        conversion_rate DECIMAL(10,4) DEFAULT 0.0000,
        cost_per_lead DECIMAL(10,2) DEFAULT 0.00,
        
        -- Metadata
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        
        UNIQUE(location_id, date, traffic_source, sales_id)
    );
    
    CREATE INDEX IF NOT EXISTS idx_kpis_location_date ON daily_kpis(location_id, date);
    CREATE INDEX IF NOT EXISTS idx_kpis_sales_id ON daily_kpis(sales_id);
    CREATE INDEX IF NOT EXISTS idx_kpis_traffic_source ON daily_kpis(traffic_source);
    CREATE INDEX IF NOT EXISTS idx_kpis_date_range ON daily_kpis(date DESC);
    """
    execute_sql(kpis_sql, "Creating daily KPIs table")
    
    # 7. Create sales_lead_assignments table
    assignments_sql = """
    CREATE TABLE IF NOT EXISTS sales_lead_assignments (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        location_id VARCHAR(100) NOT NULL REFERENCES locations(location_id) ON DELETE CASCADE,
        sales_id UUID NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
        lead_id VARCHAR(100) NOT NULL,
        traffic_source VARCHAR(20) CHECK (traffic_source IN ('ads', 'organic', 'outbound')) NOT NULL,
        assigned_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        lead_cost DECIMAL(10,2) DEFAULT 0.00,
        lead_status VARCHAR(50) DEFAULT 'assigned',
        utm_data JSONB DEFAULT '{}',
        custom_data JSONB DEFAULT '{}',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        
        UNIQUE(location_id, lead_id)
    );
    
    CREATE INDEX IF NOT EXISTS idx_assignments_sales_id ON sales_lead_assignments(sales_id);
    CREATE INDEX IF NOT EXISTS idx_assignments_location_date ON sales_lead_assignments(location_id, assigned_date);
    CREATE INDEX IF NOT EXISTS idx_assignments_traffic_source ON sales_lead_assignments(traffic_source);
    """
    execute_sql(assignments_sql, "Creating sales lead assignments table")
    
    # 8. Create webhook_logs table
    webhook_logs_sql = """
    CREATE TABLE IF NOT EXISTS webhook_logs (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        location_id VARCHAR(100) NOT NULL REFERENCES locations(location_id) ON DELETE CASCADE,
        webhook_type VARCHAR(50) NOT NULL,
        payload JSONB NOT NULL,
        headers JSONB DEFAULT '{}',
        ip_address INET,
        user_agent TEXT,
        status VARCHAR(20) CHECK (status IN ('success', 'error', 'pending', 'retry')) DEFAULT 'pending',
        error_message TEXT,
        processed_at TIMESTAMP WITH TIME ZONE,
        retry_count INTEGER DEFAULT 0,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
    
    CREATE INDEX IF NOT EXISTS idx_webhook_logs_location_id ON webhook_logs(location_id);
    CREATE INDEX IF NOT EXISTS idx_webhook_logs_status ON webhook_logs(status);
    CREATE INDEX IF NOT EXISTS idx_webhook_logs_created_at ON webhook_logs(created_at DESC);
    """
    execute_sql(webhook_logs_sql, "Creating webhook logs table")
    
    # 9. Create rate_limits table
    rate_limits_sql = """
    CREATE TABLE IF NOT EXISTS rate_limits (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        location_id VARCHAR(100) NOT NULL REFERENCES locations(location_id) ON DELETE CASCADE,
        ip_address INET NOT NULL,
        endpoint VARCHAR(255) NOT NULL,
        request_count INTEGER DEFAULT 1,
        window_start TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        window_end TIMESTAMP WITH TIME ZONE DEFAULT (NOW() + INTERVAL '1 hour'),
        is_blocked BOOLEAN DEFAULT false,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        
        UNIQUE(location_id, ip_address, endpoint, window_start)
    );
    
    CREATE INDEX IF NOT EXISTS idx_rate_limits_location_ip ON rate_limits(location_id, ip_address);
    CREATE INDEX IF NOT EXISTS idx_rate_limits_window ON rate_limits(window_start, window_end);
    """
    execute_sql(rate_limits_sql, "Creating rate limits table")
    
    # 10. Create sales_performance_cache table
    performance_cache_sql = """
    CREATE TABLE IF NOT EXISTS sales_performance_cache (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        location_id VARCHAR(100) NOT NULL REFERENCES locations(location_id) ON DELETE CASCADE,
        sales_id UUID NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
        date_from DATE NOT NULL,
        date_to DATE NOT NULL,
        traffic_source VARCHAR(20) CHECK (traffic_source IN ('ads', 'organic', 'outbound', 'all')) NOT NULL,
        
        -- Cached Metrics
        total_leads INTEGER DEFAULT 0,
        total_budget_allocated DECIMAL(10,2) DEFAULT 0.00,
        total_sales DECIMAL(10,2) DEFAULT 0.00,
        total_commissions DECIMAL(10,2) DEFAULT 0.00,
        performance_score DECIMAL(10,4) DEFAULT 0.0000,
        ranking_position INTEGER,
        
        -- Additional Metrics
        metrics_data JSONB DEFAULT '{}',
        
        last_calculated TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        
        UNIQUE(location_id, sales_id, date_from, date_to, traffic_source)
    );
    
    CREATE INDEX IF NOT EXISTS idx_performance_cache_sales ON sales_performance_cache(sales_id);
    CREATE INDEX IF NOT EXISTS idx_performance_cache_location_date ON sales_performance_cache(location_id, date_from, date_to);
    CREATE INDEX IF NOT EXISTS idx_performance_cache_ranking ON sales_performance_cache(location_id, ranking_position);
    """
    execute_sql(performance_cache_sql, "Creating sales performance cache table")
    
    # 11. Create system_settings table
    system_settings_sql = """
    CREATE TABLE IF NOT EXISTS system_settings (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        location_id VARCHAR(100) NOT NULL REFERENCES locations(location_id) ON DELETE CASCADE,
        setting_key VARCHAR(255) NOT NULL,
        setting_value JSONB NOT NULL,
        setting_type VARCHAR(50) DEFAULT 'general',
        description TEXT,
        is_active BOOLEAN DEFAULT true,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        
        UNIQUE(location_id, setting_key)
    );
    
    CREATE INDEX IF NOT EXISTS idx_system_settings_location_key ON system_settings(location_id, setting_key);
    CREATE INDEX IF NOT EXISTS idx_system_settings_type ON system_settings(setting_type);
    """
    execute_sql(system_settings_sql, "Creating system settings table")
    
    # 12. Create utm_data table
    utm_data_sql = """
    CREATE TABLE IF NOT EXISTS utm_data (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        location_id VARCHAR(100) NOT NULL REFERENCES locations(location_id) ON DELETE CASCADE,
        kpi_id UUID REFERENCES daily_kpis(id) ON DELETE CASCADE,
        utm_source VARCHAR(255),
        utm_medium VARCHAR(255),
        utm_campaign VARCHAR(255),
        utm_content VARCHAR(255),
        utm_term VARCHAR(255),
        additional_params JSONB DEFAULT '{}',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
    
    CREATE INDEX IF NOT EXISTS idx_utm_data_location_id ON utm_data(location_id);
    CREATE INDEX IF NOT EXISTS idx_utm_data_kpi_id ON utm_data(kpi_id);
    CREATE INDEX IF NOT EXISTS idx_utm_data_source ON utm_data(utm_source);
    CREATE INDEX IF NOT EXISTS idx_utm_data_campaign ON utm_data(utm_campaign);
    """
    execute_sql(utm_data_sql, "Creating UTM data table")
    
    print("✅ Database schema creation completed!")
    return True

def create_database_functions():
    """Create database functions for calculations"""
    
    print("🔧 Creating database functions...")
    
    # Function to calculate average lead cost for last 3 days
    avg_cost_function = """
    CREATE OR REPLACE FUNCTION calculate_avg_lead_cost_3days(
        p_location_id VARCHAR(100),
        p_traffic_source VARCHAR(20),
        p_date DATE DEFAULT CURRENT_DATE
    )
    RETURNS DECIMAL(10,2)
    LANGUAGE plpgsql
    AS $$
    DECLARE
        avg_cost DECIMAL(10,2);
    BEGIN
        SELECT COALESCE(AVG(
            CASE 
                WHEN leads > 0 THEN spesa_ads / leads 
                ELSE 0 
            END
        ), 0.00)
        INTO avg_cost
        FROM daily_kpis
        WHERE location_id = p_location_id
        AND traffic_source = p_traffic_source
        AND date BETWEEN (p_date - INTERVAL '3 days') AND p_date
        AND leads > 0;
        
        RETURN COALESCE(avg_cost, 0.00);
    END;
    $$;
    """
    execute_sql(avg_cost_function, "Creating average lead cost calculation function")
    
    # Function to calculate sales budget allocation
    budget_allocation_function = """
    CREATE OR REPLACE FUNCTION calculate_sales_budget_allocation(
        p_sales_id UUID,
        p_date_from DATE,
        p_date_to DATE
    )
    RETURNS DECIMAL(10,2)
    LANGUAGE plpgsql
    AS $$
    DECLARE
        total_budget DECIMAL(10,2) := 0.00;
        rec RECORD;
    BEGIN
        FOR rec IN
            SELECT 
                sla.location_id,
                sla.traffic_source,
                COUNT(*) as lead_count,
                sla.assigned_date::date as assign_date
            FROM sales_lead_assignments sla
            WHERE sla.sales_id = p_sales_id
            AND sla.assigned_date::date BETWEEN p_date_from AND p_date_to
            GROUP BY sla.location_id, sla.traffic_source, sla.assigned_date::date
        LOOP
            total_budget := total_budget + (
                rec.lead_count * calculate_avg_lead_cost_3days(
                    rec.location_id, 
                    rec.traffic_source, 
                    rec.assign_date
                )
            );
        END LOOP;
        
        RETURN total_budget;
    END;
    $$;
    """
    execute_sql(budget_allocation_function, "Creating sales budget allocation function")
    
    # Function to update sales performance cache
    update_performance_function = """
    CREATE OR REPLACE FUNCTION update_sales_performance_cache(
        p_location_id VARCHAR(100),
        p_date_from DATE,
        p_date_to DATE
    )
    RETURNS VOID
    LANGUAGE plpgsql
    AS $$
    DECLARE
        rec RECORD;
        ranking_pos INTEGER := 1;
    BEGIN
        -- Delete existing cache for the period
        DELETE FROM sales_performance_cache
        WHERE location_id = p_location_id
        AND date_from = p_date_from
        AND date_to = p_date_to;
        
        -- Calculate and insert new cache data
        FOR rec IN
            SELECT 
                s.id as sales_id,
                s.name,
                s.surname,
                COUNT(DISTINCT sla.lead_id) as total_leads,
                calculate_sales_budget_allocation(s.id, p_date_from, p_date_to) as budget_allocated,
                COALESCE(SUM(dk.incassato), 0) as total_sales,
                COALESCE(SUM(
                    CASE 
                        WHEN spc.commission_type = 'percentage' 
                        THEN dk.incassato * (spc.commission_value / 100)
                        WHEN spc.commission_type = 'fixed'
                        THEN spc.commission_value * dk.contratti
                        ELSE 0
                    END
                ), 0) as total_commissions
            FROM sales s
            LEFT JOIN sales_lead_assignments sla ON s.id = sla.sales_id 
                AND sla.assigned_date::date BETWEEN p_date_from AND p_date_to
            LEFT JOIN daily_kpis dk ON s.id = dk.sales_id 
                AND dk.date BETWEEN p_date_from AND p_date_to
            LEFT JOIN sales_product_commissions spc ON s.id = spc.sales_id
                AND spc.is_active = true
            WHERE s.location_id = p_location_id
            AND s.status = 'active'
            GROUP BY s.id, s.name, s.surname
            ORDER BY total_sales DESC, total_leads DESC
        LOOP
            INSERT INTO sales_performance_cache (
                location_id, sales_id, date_from, date_to, traffic_source,
                total_leads, total_budget_allocated, total_sales, total_commissions,
                performance_score, ranking_position, last_calculated
            ) VALUES (
                p_location_id, rec.sales_id, p_date_from, p_date_to, 'all',
                rec.total_leads, rec.budget_allocated, rec.total_sales, rec.total_commissions,
                CASE WHEN rec.budget_allocated > 0 THEN rec.total_sales / rec.budget_allocated ELSE 0 END,
                ranking_pos, NOW()
            );
            
            ranking_pos := ranking_pos + 1;
        END LOOP;
    END;
    $$;
    """
    execute_sql(update_performance_function, "Creating sales performance cache update function")
    
    print("✅ Database functions created!")
    return True

def insert_test_data():
    """Insert test data for LucIA KPI system"""
    
    print("📊 Inserting test data...")
    
    # Test locations
    locations_data = """
    INSERT INTO locations (location_id, password_hash, name, account_type, is_active, settings) VALUES
    ('lucia_test_001', '$2b$10$rQJ5qP8vGQ8vGQ8vGQ8vGOxKqP8vGQ8vGQ8vGQ8vGQ8vGQ8vGQ8vG', 'LucIA Test Location 001', 'sub_account', true, '{"test_mode": true}'),
    ('lucia_test_002', '$2b$10$rQJ5qP8vGQ8vGQ8vGQ8vGOxKqP8vGQ8vGQ8vGQ8vGQ8vGQ8vGQ8vG', 'LucIA Test Location 002', 'sub_account', true, '{"test_mode": true}');
    """
    execute_sql(locations_data, "Inserting test locations")
    
    # Test sales team
    sales_data = """
    INSERT INTO sales (location_id, ghl_sales_id, name, surname, email, status, base_commission_rate) VALUES
    ('lucia_test_001', 'GHL_SALES_001', 'Marco', 'Rossi', 'marco.rossi@test.com', 'active', 0.1500),
    ('lucia_test_001', 'GHL_SALES_002', 'Laura', 'Bianchi', 'laura.bianchi@test.com', 'active', 0.1200),
    ('lucia_test_001', 'GHL_SALES_003', 'Giuseppe', 'Verdi', 'giuseppe.verdi@test.com', 'active', 0.1800),
    ('lucia_test_001', 'GHL_SALES_004', 'Anna', 'Ferrari', 'anna.ferrari@test.com', 'active', 0.1400),
    ('lucia_test_001', 'GHL_SALES_005', 'Roberto', 'Romano', 'roberto.romano@test.com', 'active', 0.1600),
    ('lucia_test_001', 'GHL_SALES_006', 'Francesca', 'Marino', 'francesca.marino@test.com', 'active', 0.1300),
    ('lucia_test_002', 'GHL_SALES_007', 'Alessandro', 'Greco', 'alessandro.greco@test.com', 'active', 0.1700),
    ('lucia_test_002', 'GHL_SALES_008', 'Valentina', 'Ricci', 'valentina.ricci@test.com', 'active', 0.1500),
    ('lucia_test_002', 'GHL_SALES_009', 'Matteo', 'Galli', 'matteo.galli@test.com', 'active', 0.1400),
    ('lucia_test_002', 'GHL_SALES_010', 'Chiara', 'Conti', 'chiara.conti@test.com', 'active', 0.1600),
    ('lucia_test_002', 'GHL_SALES_011', 'Davide', 'Bruno', 'davide.bruno@test.com', 'active', 0.1800),
    ('lucia_test_002', 'GHL_SALES_012', 'Silvia', 'Barbieri', 'silvia.barbieri@test.com', 'active', 0.1200);
    """
    execute_sql(sales_data, "Inserting test sales team")
    
    # Test products
    products_data = """
    INSERT INTO products (location_id, product_id, name, description, current_price, category, status) VALUES
    ('lucia_test_001', 'PROD_001', 'Corso Base Marketing', 'Corso introduttivo al marketing digitale', 497.00, 'Corsi', 'active'),
    ('lucia_test_001', 'PROD_002', 'Corso Avanzato SEO', 'Corso specialistico per SEO avanzato', 997.00, 'Corsi', 'active'),
    ('lucia_test_001', 'PROD_003', 'Consulenza 1-to-1', 'Consulenza personalizzata marketing', 1497.00, 'Consulenze', 'active'),
    ('lucia_test_002', 'PROD_004', 'Corso Social Media', 'Gestione professionale social media', 697.00, 'Corsi', 'active'),
    ('lucia_test_002', 'PROD_005', 'Corso E-commerce', 'Creazione e gestione e-commerce', 1297.00, 'Corsi', 'active'),
    ('lucia_test_002', 'PROD_006', 'Mastermind Annuale', 'Programma di mentoring annuale', 2997.00, 'Programmi', 'active');
    """
    execute_sql(products_data, "Inserting test products")
    
    print("✅ Test data insertion completed!")
    return True

def main():
    """Main function to setup LucIA KPI database"""
    
    print("🎯 LucIA KPI Database Setup Starting...")
    print(f"🔗 Supabase URL: {SUPABASE_URL}")
    print("=" * 60)
    
    try:
        # Step 1: Create database schema
        if create_database_schema():
            print("✅ Database schema created successfully!")
        
        # Step 2: Create database functions
        if create_database_functions():
            print("✅ Database functions created successfully!")
        
        # Step 3: Insert test data
        if insert_test_data():
            print("✅ Test data inserted successfully!")
        
        print("=" * 60)
        print("🎉 LucIA KPI Database Setup Completed Successfully!")
        print("\n📋 Test Account Credentials:")
        print("Location ID: lucia_test_001")
        print("Password: TestPassword123!")
        print("\nLocation ID: lucia_test_002") 
        print("Password: TestPassword123!")
        print("\n🔧 Next Steps:")
        print("1. Execute the SQL commands shown above in Supabase SQL Editor")
        print("2. Verify all tables are created correctly")
        print("3. Test the database functions")
        print("4. Proceed with frontend development")
        
    except Exception as e:
        print(f"❌ Error during database setup: {str(e)}")
        return False
    
    return True

if __name__ == "__main__":
    main()