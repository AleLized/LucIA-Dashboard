-- =====================================================
-- LucIA KPI Database - Complete Creation Script
-- Execute this SQL in Supabase SQL Editor
-- =====================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =====================================================
-- 1. LOCATIONS TABLE
-- =====================================================
CREATE TABLE public.locations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    location_id VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    ghl_location_id VARCHAR(255),
    password_hash VARCHAR(255) NOT NULL,
    webhook_url TEXT,
    webhook_secret VARCHAR(255),
    is_active BOOLEAN DEFAULT true,
    settings JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- 2. SALES TABLE (renamed from commerciali for clarity)
-- =====================================================
CREATE TABLE public.sales (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    location_id VARCHAR(255) NOT NULL,
    ghl_sales_id VARCHAR(255) UNIQUE,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255),
    status VARCHAR(50) DEFAULT 'active' CHECK (status IN ('active', 'pending', 'inactive')),
    commission_percent DECIMAL(5,2) DEFAULT 10.0,
    commission_fixed DECIMAL(10,2) DEFAULT 0.0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Foreign Key
    CONSTRAINT fk_sales_location FOREIGN KEY (location_id) REFERENCES public.locations(location_id) ON DELETE CASCADE
);

-- =====================================================
-- 3. PRODUCTS TABLE
-- =====================================================
CREATE TABLE public.products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    location_id VARCHAR(255) NOT NULL,
    product_id VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    current_price DECIMAL(10,2) NOT NULL,
    current_commission_percent DECIMAL(5,2) DEFAULT 0.0,
    current_commission_fixed DECIMAL(10,2) DEFAULT 0.0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Constraints
    UNIQUE(location_id, product_id),
    CONSTRAINT fk_products_location FOREIGN KEY (location_id) REFERENCES public.locations(location_id) ON DELETE CASCADE
);

-- =====================================================
-- 4. PRODUCT_PRICE_HISTORY TABLE
-- =====================================================
CREATE TABLE public.product_price_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    commission_percent DECIMAL(5,2) DEFAULT 0.0,
    commission_fixed DECIMAL(10,2) DEFAULT 0.0,
    changed_by VARCHAR(255),
    changed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Foreign Key
    CONSTRAINT fk_price_history_product FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE
);

-- =====================================================
-- 5. DAILY_KPIS TABLE
-- =====================================================
CREATE TABLE public.daily_kpis (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    location_id VARCHAR(255) NOT NULL,
    sales_id UUID,
    product_id UUID,
    date DATE NOT NULL,
    traffic_source VARCHAR(50) NOT NULL CHECK (traffic_source IN ('ads', 'organic', 'outbound', 'all')),
    
    -- Core KPI Metrics
    leads INTEGER DEFAULT 0,
    sales_count INTEGER DEFAULT 0,
    revenue DECIMAL(10,2) DEFAULT 0,
    ad_spend DECIMAL(10,2) DEFAULT 0,
    
    -- Extended Metrics
    impressions INTEGER DEFAULT 0,
    clicks INTEGER DEFAULT 0,
    surveys INTEGER DEFAULT 0,
    demos INTEGER DEFAULT 0,
    contracts INTEGER DEFAULT 0,
    
    -- UTM Data
    utm_source VARCHAR(255),
    utm_medium VARCHAR(255),
    utm_campaign VARCHAR(255),
    utm_content VARCHAR(255),
    utm_term VARCHAR(255),
    
    -- Calculated Metrics
    roas DECIMAL(10,4) DEFAULT 0,
    cost_per_lead DECIMAL(10,2) DEFAULT 0,
    conversion_rate DECIMAL(10,4) DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Foreign Keys
    CONSTRAINT fk_daily_kpis_location FOREIGN KEY (location_id) REFERENCES public.locations(location_id) ON DELETE CASCADE,
    CONSTRAINT fk_daily_kpis_sales FOREIGN KEY (sales_id) REFERENCES public.sales(id) ON DELETE SET NULL,
    CONSTRAINT fk_daily_kpis_product FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL
);

-- =====================================================
-- 6. WEBHOOK_LOGS TABLE
-- =====================================================
CREATE TABLE public.webhook_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    location_id VARCHAR(255) NOT NULL,
    event_type VARCHAR(100) NOT NULL,
    payload JSONB NOT NULL,
    processed_at TIMESTAMP WITH TIME ZONE,
    status VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending', 'processed', 'failed')),
    error_message TEXT,
    retry_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Foreign Key
    CONSTRAINT fk_webhook_logs_location FOREIGN KEY (location_id) REFERENCES public.locations(location_id) ON DELETE CASCADE
);

-- =====================================================
-- 7. SALES_PERFORMANCE_CACHE TABLE
-- =====================================================
CREATE TABLE public.sales_performance_cache (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    location_id VARCHAR(255) NOT NULL,
    sales_id UUID NOT NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    
    -- Cached Performance Metrics
    total_leads INTEGER DEFAULT 0,
    total_sales INTEGER DEFAULT 0,
    total_revenue DECIMAL(10,2) DEFAULT 0,
    total_commission DECIMAL(10,2) DEFAULT 0,
    avg_deal_value DECIMAL(10,2) DEFAULT 0,
    conversion_rate DECIMAL(10,4) DEFAULT 0,
    performance_score DECIMAL(10,2) DEFAULT 0,
    
    last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Foreign Keys
    CONSTRAINT fk_performance_cache_location FOREIGN KEY (location_id) REFERENCES public.locations(location_id) ON DELETE CASCADE,
    CONSTRAINT fk_performance_cache_sales FOREIGN KEY (sales_id) REFERENCES public.sales(id) ON DELETE CASCADE,
    
    -- Unique constraint
    UNIQUE(location_id, sales_id, period_start, period_end)
);

-- =====================================================
-- PERFORMANCE INDEXES
-- =====================================================
CREATE INDEX idx_locations_location_id ON public.locations(location_id);
CREATE INDEX idx_sales_location_id ON public.sales(location_id);
CREATE INDEX idx_sales_ghl_id ON public.sales(ghl_sales_id);
CREATE INDEX idx_products_location_id ON public.products(location_id);
CREATE INDEX idx_daily_kpis_location_date ON public.daily_kpis(location_id, date);
CREATE INDEX idx_daily_kpis_sales ON public.daily_kpis(sales_id);
CREATE INDEX idx_daily_kpis_product ON public.daily_kpis(product_id);
CREATE INDEX idx_daily_kpis_traffic_source ON public.daily_kpis(traffic_source);
CREATE INDEX idx_webhook_logs_location ON public.webhook_logs(location_id);
CREATE INDEX idx_webhook_logs_status ON public.webhook_logs(status);
CREATE INDEX idx_performance_cache_location_sales ON public.sales_performance_cache(location_id, sales_id);

-- =====================================================
-- DATABASE FUNCTIONS
-- =====================================================

-- 1. CALCULATE SALES BUDGET ALLOCATION
CREATE OR REPLACE FUNCTION public.calculate_sales_budget_allocation(
    p_location_id VARCHAR(255),
    p_days INTEGER DEFAULT 3
)
RETURNS TABLE(
    sales_id UUID,
    sales_name VARCHAR(255),
    ghl_sales_id VARCHAR(255),
    avg_leads_per_day NUMERIC,
    avg_cost_per_lead NUMERIC,
    suggested_daily_budget NUMERIC,
    performance_data JSONB
) 
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    WITH recent_performance AS (
        SELECT 
            dk.sales_id,
            s.name AS sales_name,
            s.ghl_sales_id,
            AVG(dk.leads::numeric) AS avg_leads_per_day,
            AVG(CASE WHEN dk.leads > 0 THEN dk.ad_spend / dk.leads ELSE 0 END) AS avg_cost_per_lead,
            SUM(dk.leads) AS total_leads,
            SUM(dk.ad_spend) AS total_spend,
            SUM(dk.revenue) AS total_revenue,
            COUNT(*) AS days_active
        FROM public.daily_kpis dk
        JOIN public.sales s ON dk.sales_id = s.id
        WHERE dk.location_id = p_location_id
            AND dk.date >= CURRENT_DATE - INTERVAL '1 day' * p_days
            AND dk.sales_id IS NOT NULL
            AND dk.traffic_source = 'ads'
        GROUP BY dk.sales_id, s.name, s.ghl_sales_id
    )
    SELECT 
        rp.sales_id,
        rp.sales_name,
        rp.ghl_sales_id,
        rp.avg_leads_per_day,
        rp.avg_cost_per_lead,
        ROUND((rp.avg_leads_per_day * rp.avg_cost_per_lead)::numeric, 2) AS suggested_daily_budget,
        jsonb_build_object(
            'total_leads', rp.total_leads,
            'total_spend', rp.total_spend,
            'total_revenue', rp.total_revenue,
            'days_active', rp.days_active,
            'roas', CASE WHEN rp.total_spend > 0 THEN ROUND((rp.total_revenue / rp.total_spend)::numeric, 4) ELSE 0 END
        ) AS performance_data
    FROM recent_performance rp
    ORDER BY suggested_daily_budget DESC;
END;
$$;

-- 2. GET SALES RANKING
CREATE OR REPLACE FUNCTION public.get_sales_ranking(
    p_location_id VARCHAR(255),
    p_date_from DATE DEFAULT CURRENT_DATE - INTERVAL '30 days',
    p_date_to DATE DEFAULT CURRENT_DATE
)
RETURNS TABLE(
    rank_position INTEGER,
    sales_id UUID,
    sales_name VARCHAR(255),
    ghl_sales_id VARCHAR(255),
    total_leads INTEGER,
    total_sales INTEGER,
    total_revenue NUMERIC,
    total_commission NUMERIC,
    conversion_rate NUMERIC,
    avg_deal_value NUMERIC,
    performance_score NUMERIC
) 
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    WITH sales_performance AS (
        SELECT 
            s.id AS sales_id,
            s.name AS sales_name,
            s.ghl_sales_id,
            COALESCE(SUM(dk.leads), 0) AS total_leads,
            COALESCE(SUM(dk.sales_count), 0) AS total_sales,
            COALESCE(SUM(dk.revenue), 0) AS total_revenue,
            COALESCE(SUM(dk.revenue * s.commission_percent / 100), 0) AS total_commission,
            CASE 
                WHEN SUM(dk.leads) > 0 
                THEN ROUND((SUM(dk.sales_count)::numeric / SUM(dk.leads)::numeric * 100), 2)
                ELSE 0 
            END AS conversion_rate,
            CASE 
                WHEN SUM(dk.sales_count) > 0 
                THEN ROUND((SUM(dk.revenue) / SUM(dk.sales_count))::numeric, 2)
                ELSE 0 
            END AS avg_deal_value
        FROM public.sales s
        LEFT JOIN public.daily_kpis dk ON s.id = dk.sales_id 
            AND dk.date BETWEEN p_date_from AND p_date_to
        WHERE s.location_id = p_location_id 
            AND s.is_active = true
        GROUP BY s.id, s.name, s.ghl_sales_id, s.commission_percent
    ),
    ranked_sales AS (
        SELECT 
            sp.*,
            -- Performance score calculation (weighted)
            ROUND((
                (sp.total_revenue * 0.5) + 
                (sp.conversion_rate * 10 * 0.3) + 
                (sp.total_sales * 20 * 0.2)
            )::numeric, 2) AS performance_score
        FROM sales_performance sp
    )
    SELECT 
        ROW_NUMBER() OVER (ORDER BY rs.performance_score DESC)::INTEGER AS rank_position,
        rs.sales_id,
        rs.sales_name,
        rs.ghl_sales_id,
        rs.total_leads::INTEGER,
        rs.total_sales::INTEGER,
        rs.total_revenue,
        rs.total_commission,
        rs.conversion_rate,
        rs.avg_deal_value,
        rs.performance_score
    FROM ranked_sales rs
    ORDER BY rs.performance_score DESC;
END;
$$;

-- 3. UPDATE SALES PERFORMANCE CACHE
CREATE OR REPLACE FUNCTION public.update_sales_performance_cache(
    p_location_id VARCHAR(255) DEFAULT NULL,
    p_period_days INTEGER DEFAULT 30
)
RETURNS TABLE(
    location_id VARCHAR(255),
    sales_updated INTEGER,
    cache_timestamp TIMESTAMP WITH TIME ZONE
) 
LANGUAGE plpgsql
AS $$
DECLARE
    current_location VARCHAR(255);
    updated_count INTEGER := 0;
    period_start DATE := CURRENT_DATE - INTERVAL '1 day' * p_period_days;
    period_end DATE := CURRENT_DATE;
BEGIN
    -- Loop through locations
    FOR current_location IN 
        SELECT DISTINCT l.location_id 
        FROM public.locations l 
        WHERE (p_location_id IS NULL OR l.location_id = p_location_id)
    LOOP
        -- Update cache for all sales in current location
        INSERT INTO public.sales_performance_cache (
            location_id, sales_id, period_start, period_end,
            total_leads, total_sales, total_revenue, total_commission,
            avg_deal_value, conversion_rate, performance_score, last_updated
        )
        SELECT 
            current_location,
            s.id,
            period_start,
            period_end,
            COALESCE(SUM(dk.leads), 0),
            COALESCE(SUM(dk.sales_count), 0),
            COALESCE(SUM(dk.revenue), 0),
            COALESCE(SUM(dk.revenue * s.commission_percent / 100), 0),
            CASE WHEN SUM(dk.sales_count) > 0 THEN SUM(dk.revenue) / SUM(dk.sales_count) ELSE 0 END,
            CASE WHEN SUM(dk.leads) > 0 THEN SUM(dk.sales_count)::numeric / SUM(dk.leads)::numeric * 100 ELSE 0 END,
            COALESCE(SUM(dk.revenue), 0) + COALESCE(SUM(dk.leads), 0) * 10, -- Simple performance score
            NOW()
        FROM public.sales s
        LEFT JOIN public.daily_kpis dk ON s.id = dk.sales_id 
            AND dk.date BETWEEN period_start AND period_end
        WHERE s.location_id = current_location
        GROUP BY s.id, s.commission_percent
        ON CONFLICT (location_id, sales_id, period_start, period_end) 
        DO UPDATE SET 
            total_leads = EXCLUDED.total_leads,
            total_sales = EXCLUDED.total_sales,
            total_revenue = EXCLUDED.total_revenue,
            total_commission = EXCLUDED.total_commission,
            avg_deal_value = EXCLUDED.avg_deal_value,
            conversion_rate = EXCLUDED.conversion_rate,
            performance_score = EXCLUDED.performance_score,
            last_updated = EXCLUDED.last_updated;
        
        GET DIAGNOSTICS updated_count = ROW_COUNT;
        
        RETURN QUERY SELECT current_location, updated_count, NOW();
    END LOOP;
    
    RETURN;
END;
$$;

-- 4. HANDLE UNKNOWN SALES/PRODUCT
CREATE OR REPLACE FUNCTION public.handle_unknown_sales_product(
    p_location_id VARCHAR(255),
    p_ghl_sales_id VARCHAR(255) DEFAULT NULL,
    p_sales_name VARCHAR(255) DEFAULT NULL,
    p_product_id VARCHAR(255) DEFAULT NULL,
    p_product_name VARCHAR(255) DEFAULT NULL
)
RETURNS TABLE(
    action_taken VARCHAR(50),
    entity_type VARCHAR(20),
    entity_id UUID,
    message TEXT
) 
LANGUAGE plpgsql
AS $$
DECLARE
    new_sales_id UUID;
    new_product_id UUID;
    location_exists BOOLEAN;
BEGIN
    -- Check if location exists
    SELECT EXISTS(SELECT 1 FROM public.locations WHERE location_id = p_location_id) INTO location_exists;
    
    IF NOT location_exists THEN
        RETURN QUERY SELECT 'error'::VARCHAR(50), 'location'::VARCHAR(20), NULL::UUID, 'Location not found'::TEXT;
        RETURN;
    END IF;
    
    -- Handle unknown sales
    IF p_ghl_sales_id IS NOT NULL THEN
        SELECT id INTO new_sales_id 
        FROM public.sales 
        WHERE ghl_sales_id = p_ghl_sales_id;
        
        IF new_sales_id IS NULL THEN
            INSERT INTO public.sales (
                location_id, ghl_sales_id, name, email, status, is_active
            ) VALUES (
                p_location_id,
                p_ghl_sales_id,
                COALESCE(p_sales_name, 'Unknown Sales'),
                p_ghl_sales_id || '@' || p_location_id || '.temp',
                'pending',
                false
            ) RETURNING id INTO new_sales_id;
            
            RETURN QUERY SELECT 'created'::VARCHAR(50), 'sales'::VARCHAR(20), new_sales_id, 'New sales created in pending status'::TEXT;
        ELSE
            RETURN QUERY SELECT 'exists'::VARCHAR(50), 'sales'::VARCHAR(20), new_sales_id, 'Sales already exists'::TEXT;
        END IF;
    END IF;
    
    -- Handle unknown product
    IF p_product_id IS NOT NULL THEN
        SELECT id INTO new_product_id 
        FROM public.products 
        WHERE product_id = p_product_id AND location_id = p_location_id;
        
        IF new_product_id IS NULL THEN
            INSERT INTO public.products (
                location_id, product_id, name, description, current_price, is_active
            ) VALUES (
                p_location_id,
                p_product_id,
                COALESCE(p_product_name, 'Unknown Product'),
                'Auto-created from webhook data',
                0.00,
                false
            ) RETURNING id INTO new_product_id;
            
            RETURN QUERY SELECT 'created'::VARCHAR(50), 'product'::VARCHAR(20), new_product_id, 'New product created in pending status'::TEXT;
        ELSE
            RETURN QUERY SELECT 'exists'::VARCHAR(50), 'product'::VARCHAR(20), new_product_id, 'Product already exists'::TEXT;
        END IF;
    END IF;
    
    RETURN;
END;
$$;

-- =====================================================
-- INSERT TEST DATA
-- =====================================================

-- Insert test locations
INSERT INTO public.locations (location_id, name, ghl_location_id, password_hash, webhook_url, webhook_secret, is_active, settings)
VALUES 
('lucia_test_001', 'LucIA Test Location 001', 'ghl_loc_001', crypt('TestPassword123!', gen_salt('bf')), 'https://lucia-kpi.example.com/webhook/001', 'secret_001', true, '{"timezone": "Europe/Rome", "currency": "EUR"}'),
('lucia_test_002', 'LucIA Test Location 002', 'ghl_loc_002', crypt('TestPassword123!', gen_salt('bf')), 'https://lucia-kpi.example.com/webhook/002', 'secret_002', true, '{"timezone": "Europe/Rome", "currency": "EUR"}');

-- Insert test sales team
INSERT INTO public.sales (location_id, ghl_sales_id, name, email, password_hash, status, commission_percent, is_active)
VALUES 
-- Location 1 Sales Team
('lucia_test_001', 'ghl_sales_1_01', 'Alessandro Ferrari', 'alessandro.ferrari@lucia_test_001.com', crypt('SalesPassword123!', gen_salt('bf')), 'active', 12.50, true),
('lucia_test_001', 'ghl_sales_1_02', 'Giulia Rossi', 'giulia.rossi@lucia_test_001.com', crypt('SalesPassword123!', gen_salt('bf')), 'active', 10.00, true),
('lucia_test_001', 'ghl_sales_1_03', 'Marco Bianchi', 'marco.bianchi@lucia_test_001.com', crypt('SalesPassword123!', gen_salt('bf')), 'active', 15.00, true),
('lucia_test_001', 'ghl_sales_1_04', 'Sofia Romano', 'sofia.romano@lucia_test_001.com', crypt('SalesPassword123!', gen_salt('bf')), 'active', 8.50, true),
('lucia_test_001', 'ghl_sales_1_05', 'Luca Conti', 'luca.conti@lucia_test_001.com', crypt('SalesPassword123!', gen_salt('bf')), 'active', 11.00, true),
('lucia_test_001', 'ghl_sales_1_06', 'Francesca Ricci', 'francesca.ricci@lucia_test_001.com', crypt('SalesPassword123!', gen_salt('bf')), 'active', 13.50, true),
-- Location 2 Sales Team
('lucia_test_002', 'ghl_sales_2_01', 'Alessandro Ferrari', 'alessandro.ferrari@lucia_test_002.com', crypt('SalesPassword123!', gen_salt('bf')), 'active', 9.50, true),
('lucia_test_002', 'ghl_sales_2_02', 'Giulia Rossi', 'giulia.rossi@lucia_test_002.com', crypt('SalesPassword123!', gen_salt('bf')), 'active', 14.00, true),
('lucia_test_002', 'ghl_sales_2_03', 'Marco Bianchi', 'marco.bianchi@lucia_test_002.com', crypt('SalesPassword123!', gen_salt('bf')), 'active', 7.50, true),
('lucia_test_002', 'ghl_sales_2_04', 'Sofia Romano', 'sofia.romano@lucia_test_002.com', crypt('SalesPassword123!', gen_salt('bf')), 'active', 12.00, true),
('lucia_test_002', 'ghl_sales_2_05', 'Luca Conti', 'luca.conti@lucia_test_002.com', crypt('SalesPassword123!', gen_salt('bf')), 'active', 10.50, true),
('lucia_test_002', 'ghl_sales_2_06', 'Francesca Ricci', 'francesca.ricci@lucia_test_002.com', crypt('SalesPassword123!', gen_salt('bf')), 'active', 11.50, true);

-- Insert test products
INSERT INTO public.products (location_id, product_id, name, description, current_price, current_commission_percent, is_active)
VALUES 
-- Location 1 Products
('lucia_test_001', 'prod_001_01', 'Pacchetto Base', 'Descrizione del Pacchetto Base per lucia_test_001', 299.99, 10.0, true),
('lucia_test_001', 'prod_001_02', 'Pacchetto Premium', 'Descrizione del Pacchetto Premium per lucia_test_001', 599.99, 12.0, true),
('lucia_test_001', 'prod_001_03', 'Pacchetto Enterprise', 'Descrizione del Pacchetto Enterprise per lucia_test_001', 999.99, 15.0, true),
-- Location 2 Products
('lucia_test_002', 'prod_002_01', 'Pacchetto Base', 'Descrizione del Pacchetto Base per lucia_test_002', 299.99, 10.0, true),
('lucia_test_002', 'prod_002_02', 'Pacchetto Premium', 'Descrizione del Pacchetto Premium per lucia_test_002', 599.99, 12.0, true),
('lucia_test_002', 'prod_002_03', 'Pacchetto Enterprise', 'Descrizione del Pacchetto Enterprise per lucia_test_002', 999.99, 15.0, true);

-- Generate sample KPI data for the last 30 days
WITH date_series AS (
    SELECT generate_series(
        CURRENT_DATE - INTERVAL '29 days',
        CURRENT_DATE,
        INTERVAL '1 day'
    )::date AS date
),
location_sales_traffic AS (
    SELECT 
        l.location_id,
        s.id AS sales_id,
        d.date,
        t.traffic_source
    FROM (VALUES ('lucia_test_001'), ('lucia_test_002')) AS l(location_id)
    CROSS JOIN date_series d
    CROSS JOIN (VALUES ('ads'), ('organic'), ('outbound')) AS t(traffic_source)
    JOIN public.sales s ON s.location_id = l.location_id
    WHERE s.is_active = true
),
sample_data AS (
    SELECT 
        lst.*,
        (random() * 15 + 5)::integer AS leads,
        (random() * 5 + 1)::integer AS sales_count,
        (random() * 2000 + 500)::numeric(10,2) AS revenue,
        CASE 
            WHEN lst.traffic_source = 'ads' THEN (random() * 500 + 100)::numeric(10,2)
            ELSE 0
        END AS ad_spend,
        (random() * 3000 + 1000)::integer AS impressions,
        (random() * 150 + 50)::integer AS clicks
    FROM location_sales_traffic lst
)
INSERT INTO public.daily_kpis (
    location_id, sales_id, date, traffic_source, leads, sales_count, revenue, ad_spend,
    impressions, clicks, surveys, demos, contracts, utm_source, utm_medium, utm_campaign,
    roas, cost_per_lead, conversion_rate
)
SELECT 
    sd.location_id,
    sd.sales_id,
    sd.date,
    sd.traffic_source,
    sd.leads,
    sd.sales_count,
    sd.revenue,
    sd.ad_spend,
    CASE WHEN sd.traffic_source = 'ads' THEN sd.impressions ELSE 0 END,
    CASE WHEN sd.traffic_source = 'ads' THEN sd.clicks ELSE (random() * 20)::integer END,
    (sd.leads * (random() * 0.3 + 0.6))::integer AS surveys,
    (sd.leads * (random() * 0.2 + 0.1))::integer AS demos,
    sd.sales_count AS contracts,
    (ARRAY['facebook', 'google', 'linkedin', 'email', 'direct'])[floor(random() * 5 + 1)] AS utm_source,
    (ARRAY['cpc', 'organic', 'email', 'social', 'referral'])[floor(random() * 5 + 1)] AS utm_medium,
    'campaign_' || (random() * 10 + 1)::integer AS utm_campaign,
    CASE 
        WHEN sd.ad_spend > 0 THEN ROUND((sd.revenue / sd.ad_spend)::numeric, 4)
        ELSE 0 
    END AS roas,
    CASE 
        WHEN sd.leads > 0 AND sd.ad_spend > 0 THEN ROUND((sd.ad_spend / sd.leads)::numeric, 2)
        ELSE 0 
    END AS cost_per_lead,
    CASE 
        WHEN sd.leads > 0 THEN ROUND((sd.sales_count::numeric / sd.leads::numeric * 100), 4)
        ELSE 0 
    END AS conversion_rate
FROM sample_data sd;

-- =====================================================
-- ENABLE RLS AND CREATE POLICIES
-- =====================================================

-- Enable RLS on all tables
ALTER TABLE public.locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.daily_kpis ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.webhook_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sales_performance_cache ENABLE ROW LEVEL SECURITY;

-- Create basic policies (allow all for service role, restrict for others)
CREATE POLICY "Enable all for service role" ON public.locations FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "Enable all for service role" ON public.sales FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "Enable all for service role" ON public.products FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "Enable all for service role" ON public.daily_kpis FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "Enable all for service role" ON public.webhook_logs FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "Enable all for service role" ON public.sales_performance_cache FOR ALL USING (auth.role() = 'service_role');

-- =====================================================
-- VERIFICATION QUERIES
-- =====================================================

-- Verify table creation and relationships
SELECT 
    'Database Setup Complete' AS status,
    (SELECT COUNT(*) FROM public.locations) AS locations_count,
    (SELECT COUNT(*) FROM public.sales) AS sales_count,
    (SELECT COUNT(*) FROM public.products) AS products_count,
    (SELECT COUNT(*) FROM public.daily_kpis) AS kpi_records_count;

-- Verify foreign key constraints
SELECT 
    'Foreign Key Constraints' AS constraint_type,
    COUNT(*) AS constraint_count
FROM information_schema.table_constraints 
WHERE constraint_type = 'FOREIGN KEY' 
    AND table_schema = 'public'
    AND table_name IN ('sales', 'products', 'daily_kpis', 'webhook_logs', 'product_price_history', 'sales_performance_cache');

-- Verify functions
SELECT 
    'Database Functions' AS function_type,
    COUNT(*) AS function_count
FROM information_schema.routines 
WHERE routine_schema = 'public' 
    AND routine_name IN (
        'calculate_sales_budget_allocation',
        'get_sales_ranking',
        'update_sales_performance_cache',
        'handle_unknown_sales_product'
    );

-- Test sample function
SELECT 'Function Test' AS test_type, COUNT(*) AS result_count
FROM public.get_sales_ranking('lucia_test_001');

-- =====================================================
-- COMPLETION MESSAGE
-- =====================================================
SELECT 
    '🎯 LUCIA KPI DATABASE CREATED SUCCESSFULLY!' AS status,
    'All tables, relationships, functions, and test data ready' AS description,
    'Schema Visualizer should now show all table relationships' AS note,
    'Test Credentials: lucia_test_001 / TestPassword123!' AS login_info;