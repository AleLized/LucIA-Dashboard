#!/usr/bin/env python3
"""
Execute LucIA KPI Database Schema via Supabase REST API
"""

import requests
import json
import time

# Supabase Configuration
SUPABASE_URL = "https://xqehyjcrytigudfesjst.supabase.co"
SERVICE_ROLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhxZWh5amNyeXRpZ3VkZmVzanN0Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1ODg3OTY1MCwiZXhwIjoyMDc0NDU1NjUwfQ.Q7sxb9wnFmAHfHhlFyEvSDQDdcO1tOVFOMAxBsrHOz4"

def execute_sql_via_api(sql_commands):
    """Execute SQL commands via Supabase API"""
    
    headers = {
        'Authorization': f'Bearer {SERVICE_ROLE_KEY}',
        'Content-Type': 'application/json',
        'apikey': SERVICE_ROLE_KEY
    }
    
    # Read the complete SQL file
    with open('/workspace/lucia_kpi_complete_schema.sql', 'r') as f:
        complete_sql = f.read()
    
    print("🚀 Executing LucIA KPI Database Schema...")
    print(f"📄 SQL File Size: {len(complete_sql)} characters")
    
    # Split SQL into individual commands
    sql_parts = complete_sql.split(';')
    
    success_count = 0
    error_count = 0
    
    for i, sql_part in enumerate(sql_parts):
        sql_part = sql_part.strip()
        if not sql_part or sql_part.startswith('--') or len(sql_part) < 10:
            continue
            
        print(f"🔄 Executing command {i+1}/{len(sql_parts)}")
        
        try:
            # Try to execute via the RPC endpoint
            response = requests.post(
                f"{SUPABASE_URL}/rest/v1/rpc/exec_sql",
                headers=headers,
                json={"sql": sql_part + ";"}
            )
            
            if response.status_code == 200:
                success_count += 1
                print(f"✅ Command {i+1} executed successfully")
            else:
                error_count += 1
                print(f"❌ Command {i+1} failed: {response.status_code} - {response.text}")
                
        except Exception as e:
            error_count += 1
            print(f"❌ Command {i+1} error: {str(e)}")
        
        # Small delay to avoid rate limiting
        time.sleep(0.1)
    
    print(f"\n📊 Execution Summary:")
    print(f"✅ Successful commands: {success_count}")
    print(f"❌ Failed commands: {error_count}")
    
    return success_count > 0

def verify_database_setup():
    """Verify that the database was set up correctly"""
    
    headers = {
        'Authorization': f'Bearer {SERVICE_ROLE_KEY}',
        'Content-Type': 'application/json',
        'apikey': SERVICE_ROLE_KEY
    }
    
    print("\n🔍 Verifying database setup...")
    
    # Check if locations table exists and has data
    try:
        response = requests.get(
            f"{SUPABASE_URL}/rest/v1/locations?select=*",
            headers=headers
        )
        
        if response.status_code == 200:
            locations = response.json()
            print(f"✅ Locations table: {len(locations)} records found")
            
            for location in locations:
                print(f"   📍 {location['name']} ({location['location_id']})")
        else:
            print(f"❌ Could not verify locations table: {response.status_code}")
            
    except Exception as e:
        print(f"❌ Error verifying locations: {str(e)}")
    
    # Check if sales table exists and has data
    try:
        response = requests.get(
            f"{SUPABASE_URL}/rest/v1/sales?select=*",
            headers=headers
        )
        
        if response.status_code == 200:
            sales = response.json()
            print(f"✅ Sales table: {len(sales)} records found")
        else:
            print(f"❌ Could not verify sales table: {response.status_code}")
            
    except Exception as e:
        print(f"❌ Error verifying sales: {str(e)}")
    
    # Check if products table exists and has data
    try:
        response = requests.get(
            f"{SUPABASE_URL}/rest/v1/products?select=*",
            headers=headers
        )
        
        if response.status_code == 200:
            products = response.json()
            print(f"✅ Products table: {len(products)} records found")
        else:
            print(f"❌ Could not verify products table: {response.status_code}")
            
    except Exception as e:
        print(f"❌ Error verifying products: {str(e)}")

def main():
    """Main execution function"""
    
    print("🎯 LucIA KPI Database Setup via API")
    print("=" * 50)
    
    # Execute the SQL schema
    if execute_sql_via_api([]):
        print("\n✅ Database schema execution completed!")
        
        # Verify the setup
        verify_database_setup()
        
        print("\n🎉 LucIA KPI Database Setup Completed!")
        print("\n📋 Test Account Credentials:")
        print("Location ID: lucia_test_001")
        print("Password: TestPassword123!")
        print("\nLocation ID: lucia_test_002")
        print("Password: TestPassword123!")
        
        print("\n🔧 Next Steps:")
        print("1. Verify all tables are created in Supabase dashboard")
        print("2. Test the database functions")
        print("3. Proceed with frontend development")
        
    else:
        print("\n❌ Database setup failed!")
        print("Please execute the SQL manually in Supabase SQL Editor")
        print("File: /workspace/lucia_kpi_complete_schema.sql")

if __name__ == "__main__":
    main()