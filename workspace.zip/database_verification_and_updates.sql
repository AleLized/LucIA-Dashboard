-- LucIA KPI Database Verification and Updates
-- Checking and adding missing tables for Sales, Products, and Sales Tracking

-- 1. SALES MANAGEMENT TABLE (if not exists)
CREATE TABLE IF NOT EXISTS sales_users (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    location_id UUID NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
    sales_id VARCHAR(50) NOT NULL, -- External sales ID from GHL
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(50),
    avatar_url TEXT,
    role VARCHAR(50) DEFAULT 'sales',
    is_active BOOLEAN DEFAULT true,
    hire_date DATE,
    commission_rate DECIMAL(5,2) DEFAULT 0.00, -- Percentage
    target_monthly DECIMAL(10,2) DEFAULT 0.00,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(location_id, sales_id)
);

-- 2. PRODUCTS TABLE (if not exists)
CREATE TABLE IF NOT EXISTS products (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    location_id UUID NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
    product_id VARCHAR(100) NOT NULL, -- External product ID
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    price DECIMAL(10,2) NOT NULL,
    commission_rate DECIMAL(5,2) DEFAULT 0.00, -- Percentage
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(location_id, product_id)
);

-- 3. SALES TRANSACTIONS TABLE (Enhanced)
CREATE TABLE IF NOT EXISTS sales_transactions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    location_id UUID NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
    contact_id VARCHAR(255) NOT NULL, -- GHL contact ID
    sales_user_id UUID REFERENCES sales_users(id) ON DELETE SET NULL,
    product_id UUID REFERENCES products(id) ON DELETE SET NULL,
    
    -- Sale details
    amount DECIMAL(10,2) NOT NULL,
    status VARCHAR(50) NOT NULL CHECK (status IN ('contrattualizzato', 'incassato', 'cancelled')),
    sale_date DATE NOT NULL,
    
    -- UTM tracking
    utm_source VARCHAR(255),
    utm_campaign VARCHAR(255),
    utm_medium VARCHAR(255),
    utm_content VARCHAR(255),
    utm_term VARCHAR(255),
    traffic_source VARCHAR(50) CHECK (traffic_source IN ('ads', 'organic', 'outbound')),
    
    -- Commission tracking
    commission_rate DECIMAL(5,2),
    commission_amount DECIMAL(10,2),
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. CONVERSION RATE SETTINGS TABLE (configurable 7/30 days)
CREATE TABLE IF NOT EXISTS conversion_rate_settings (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    location_id UUID NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
    
    -- Configurable lookback periods
    disco_lookback_days INTEGER DEFAULT 7,
    demo_lookback_days INTEGER DEFAULT 30,
    sale_lookback_days INTEGER DEFAULT 30,
    
    -- Other settings
    updated_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(location_id)
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_sales_transactions_location_date ON sales_transactions(location_id, sale_date);
CREATE INDEX IF NOT EXISTS idx_sales_transactions_sales_user ON sales_transactions(sales_user_id);
CREATE INDEX IF NOT EXISTS idx_sales_transactions_utm ON sales_transactions(utm_source, utm_campaign);

-- Enable RLS
ALTER TABLE sales_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversion_rate_settings ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view sales_users for their locations" ON sales_users
    FOR SELECT USING (
        location_id IN (
            SELECT location_id FROM user_locations 
            WHERE user_id = auth.uid()
        )
    );

CREATE POLICY "Users can view products for their locations" ON products
    FOR SELECT USING (
        location_id IN (
            SELECT location_id FROM user_locations 
            WHERE user_id = auth.uid()
        )
    );

CREATE POLICY "Users can view sales_transactions for their locations" ON sales_transactions
    FOR SELECT USING (
        location_id IN (
            SELECT location_id FROM user_locations 
            WHERE user_id = auth.uid()
        )
    );

-- Grant permissions
GRANT SELECT, INSERT, UPDATE, DELETE ON sales_users TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON products TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON sales_transactions TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON conversion_rate_settings TO authenticated;