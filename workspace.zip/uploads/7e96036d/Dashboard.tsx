import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { supabase } from '@/lib/supabaseClient';
import { SalesPerformance, DateRange, ColumnVisibility, KpiMetrics } from '@/types';
import { CalendarDays, Eye, EyeOff, Settings, TrendingUp, Users, Euro } from 'lucide-react';
import { format, subDays, startOfDay, endOfDay } from 'date-fns';

const Dashboard = () => {
  const [salesData, setSalesData] = useState<SalesPerformance[]>([]);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState<DateRange>({
    start: format(subDays(new Date(), 7), 'yyyy-MM-dd'),
    end: format(new Date(), 'yyyy-MM-dd')
  });
  
  const [columnVisibility, setColumnVisibility] = useState<ColumnVisibility>({
    lead_generati: true,
    chiamata_outbound_iniziata: true,
    chiamata_outbound_completata: true,
    disco_inbound_prenotata: true,
    disco_outbound_prenotata: true,
    disco_showed_inbound: true,
    disco_showed_outbound: true,
    demo: true,
    demo_showed: true,
    pre_vendita: true,
    vendita: true,
    contratti: true,
    incassato: true,
    spesa_ads: true,
    roas: true,
    pack_1: true,
    pack_2: true,
    pack_3: true,
    pack_4: true,
    upsell_1: true,
    upsell_2: true,
    upsell_3: true,
    aov: true,
    budget_allocato: true
  });

  const [selectedLocation, setSelectedLocation] = useState('test_kpi_2025');

  useEffect(() => {
    fetchSalesData();
  }, [dateRange, selectedLocation]);

  const fetchSalesData = async () => {
    setLoading(true);
    try {
      // Fetch sales for the location
      const { data: salesList, error: salesError } = await supabase
        .from('sales')
        .select('*')
        .eq('location_id', selectedLocation)
        .eq('status', 'confirmed');

      if (salesError) throw salesError;

      // Fetch KPI data for date range
      const { data: kpiData, error: kpiError } = await supabase
        .from('daily_kpis')
        .select('*')
        .eq('location_id', selectedLocation)
        .gte('date', dateRange.start)
        .lte('date', dateRange.end);

      if (kpiError) throw kpiError;

      // Process data to calculate sales performance
      const processedData: SalesPerformance[] = salesList.map(sales => {
        const salesKpis = kpiData.filter(kpi => kpi.sales_id === sales.id);
        
        // Calculate totals and by traffic source
        const totalMetrics: KpiMetrics = {};
        const byTrafficSource = {
          ads: {} as KpiMetrics,
          organic: {} as KpiMetrics,
          outbound: {} as KpiMetrics
        };

        // Initialize metrics
        const metricKeys = [
          'lead_generati', 'chiamata_outbound_iniziata', 'chiamata_outbound_completata',
          'disco_inbound_prenotata', 'disco_outbound_prenotata', 'disco_showed_inbound',
          'disco_showed_outbound', 'demo', 'demo_showed', 'pre_vendita', 'vendita',
          'contratti', 'incassato', 'spesa_ads', 'roas', 'pack_1', 'pack_2', 'pack_3',
          'pack_4', 'upsell_1', 'upsell_2', 'upsell_3', 'aov'
        ];

        metricKeys.forEach(key => {
          totalMetrics[key] = 0;
          byTrafficSource.ads[key] = 0;
          byTrafficSource.organic[key] = 0;
          byTrafficSource.outbound[key] = 0;
        });

        // Sum up metrics
        salesKpis.forEach(kpi => {
          metricKeys.forEach(key => {
            const value = kpi[key] || 0;
            totalMetrics[key] += value;
            byTrafficSource[kpi.traffic_source][key] += value;
          });
        });

        // Calculate ROAS and AOV
        if (totalMetrics.spesa_ads > 0) {
          totalMetrics.roas = totalMetrics.incassato / totalMetrics.spesa_ads;
        }
        if (totalMetrics.vendita > 0) {
          totalMetrics.aov = totalMetrics.incassato / totalMetrics.vendita;
        }

        // Calculate budget allocation (lead assegnati x costo medio ultimi 3 giorni)
        const last3DaysKpis = kpiData
          .filter(kpi => kpi.sales_id === sales.id)
          .filter(kpi => {
            const kpiDate = new Date(kpi.date);
            const threeDaysAgo = subDays(new Date(), 3);
            return kpiDate >= threeDaysAgo;
          });

        const totalLeads = last3DaysKpis.reduce((sum, kpi) => sum + (kpi.lead_generati || 0), 0);
        const totalSpesa = last3DaysKpis.reduce((sum, kpi) => sum + (kpi.spesa_ads || 0), 0);
        const costoMedioLead = totalLeads > 0 ? totalSpesa / totalLeads : 0;
        const leadAssegnati = totalMetrics.lead_generati || 0;
        const budgetAllocato = leadAssegnati * costoMedioLead;

        return {
          sales_id: sales.id,
          nome: sales.nome,
          cognome: sales.cognome,
          email: sales.email,
          total_metrics: totalMetrics,
          by_traffic_source: byTrafficSource,
          budget_allocato: budgetAllocato,
          lead_assegnati: leadAssegnati,
          costo_medio_lead: costoMedioLead
        };
      });

      setSalesData(processedData);
    } catch (error) {
      console.error('Error fetching sales data:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleColumnVisibility = (column: string) => {
    setColumnVisibility(prev => ({
      ...prev,
      [column]: !prev[column]
    }));
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR'
    }).format(value);
  };

  const formatNumber = (value: number) => {
    return new Intl.NumberFormat('it-IT').format(value);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">KPI Dashboard</h1>
          <p className="text-muted-foreground">Performance tracking per sales</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Settings className="h-4 w-4 mr-2" />
            Impostazioni
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CalendarDays className="h-5 w-5" />
            Filtri e Periodo
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="start_date">Data Inizio</Label>
              <Input
                id="start_date"
                type="date"
                value={dateRange.start}
                onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="end_date">Data Fine</Label>
              <Input
                id="end_date"
                type="date"
                value={dateRange.end}
                onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="location">Location</Label>
              <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="test_kpi_2025">Test KPI 2025</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Column Visibility */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            Colonne Visibili
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {Object.entries(columnVisibility).map(([column, visible]) => (
              <div key={column} className="flex items-center space-x-2">
                <Checkbox
                  id={column}
                  checked={visible}
                  onCheckedChange={() => toggleColumnVisibility(column)}
                />
                <Label htmlFor={column} className="text-sm">
                  {column.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </Label>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Sales Performance Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Performance Sales ({salesData.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[200px]">Sales</TableHead>
                  <TableHead>Email</TableHead>
                  {columnVisibility.lead_generati && <TableHead>Lead</TableHead>}
                  {columnVisibility.chiamata_outbound_iniziata && <TableHead>Call Out Iniz</TableHead>}
                  {columnVisibility.chiamata_outbound_completata && <TableHead>Call Out Comp</TableHead>}
                  {columnVisibility.disco_inbound_prenotata && <TableHead>Disco In Pren</TableHead>}
                  {columnVisibility.disco_outbound_prenotata && <TableHead>Disco Out Pren</TableHead>}
                  {columnVisibility.disco_showed_inbound && <TableHead>Disco In Show</TableHead>}
                  {columnVisibility.disco_showed_outbound && <TableHead>Disco Out Show</TableHead>}
                  {columnVisibility.demo && <TableHead>Demo</TableHead>}
                  {columnVisibility.demo_showed && <TableHead>Demo Show</TableHead>}
                  {columnVisibility.pre_vendita && <TableHead>Pre-Vendita</TableHead>}
                  {columnVisibility.vendita && <TableHead>Vendite</TableHead>}
                  {columnVisibility.contratti && <TableHead>Contratti</TableHead>}
                  {columnVisibility.incassato && <TableHead>Incassato</TableHead>}
                  {columnVisibility.spesa_ads && <TableHead>Spesa ADS</TableHead>}
                  {columnVisibility.roas && <TableHead>ROAS</TableHead>}
                  {columnVisibility.pack_1 && <TableHead>Pack 1</TableHead>}
                  {columnVisibility.pack_2 && <TableHead>Pack 2</TableHead>}
                  {columnVisibility.pack_3 && <TableHead>Pack 3</TableHead>}
                  {columnVisibility.pack_4 && <TableHead>Pack 4</TableHead>}
                  {columnVisibility.upsell_1 && <TableHead>Upsell 1</TableHead>}
                  {columnVisibility.upsell_2 && <TableHead>Upsell 2</TableHead>}
                  {columnVisibility.upsell_3 && <TableHead>Upsell 3</TableHead>}
                  {columnVisibility.aov && <TableHead>AOV</TableHead>}
                  {columnVisibility.budget_allocato && <TableHead>Budget Allocato</TableHead>}
                  <TableHead>Azioni</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {salesData.map((sales) => (
                  <TableRow key={sales.sales_id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{sales.nome} {sales.cognome}</div>
                        <div className="text-sm text-muted-foreground">ID: {sales.sales_id}</div>
                      </div>
                    </TableCell>
                    <TableCell>{sales.email}</TableCell>
                    {columnVisibility.lead_generati && <TableCell>{formatNumber(sales.total_metrics.lead_generati || 0)}</TableCell>}
                    {columnVisibility.chiamata_outbound_iniziata && <TableCell>{formatNumber(sales.total_metrics.chiamata_outbound_iniziata || 0)}</TableCell>}
                    {columnVisibility.chiamata_outbound_completata && <TableCell>{formatNumber(sales.total_metrics.chiamata_outbound_completata || 0)}</TableCell>}
                    {columnVisibility.disco_inbound_prenotata && <TableCell>{formatNumber(sales.total_metrics.disco_inbound_prenotata || 0)}</TableCell>}
                    {columnVisibility.disco_outbound_prenotata && <TableCell>{formatNumber(sales.total_metrics.disco_outbound_prenotata || 0)}</TableCell>}
                    {columnVisibility.disco_showed_inbound && <TableCell>{formatNumber(sales.total_metrics.disco_showed_inbound || 0)}</TableCell>}
                    {columnVisibility.disco_showed_outbound && <TableCell>{formatNumber(sales.total_metrics.disco_showed_outbound || 0)}</TableCell>}
                    {columnVisibility.demo && <TableCell>{formatNumber(sales.total_metrics.demo || 0)}</TableCell>}
                    {columnVisibility.demo_showed && <TableCell>{formatNumber(sales.total_metrics.demo_showed || 0)}</TableCell>}
                    {columnVisibility.pre_vendita && <TableCell>{formatNumber(sales.total_metrics.pre_vendita || 0)}</TableCell>}
                    {columnVisibility.vendita && <TableCell>{formatNumber(sales.total_metrics.vendita || 0)}</TableCell>}
                    {columnVisibility.contratti && <TableCell>{formatNumber(sales.total_metrics.contratti || 0)}</TableCell>}
                    {columnVisibility.incassato && <TableCell>{formatCurrency(sales.total_metrics.incassato || 0)}</TableCell>}
                    {columnVisibility.spesa_ads && <TableCell>{formatCurrency(sales.total_metrics.spesa_ads || 0)}</TableCell>}
                    {columnVisibility.roas && <TableCell>
                      <Badge variant={sales.total_metrics.roas > 3 ? "default" : "secondary"}>
                        {(sales.total_metrics.roas || 0).toFixed(2)}x
                      </Badge>
                    </TableCell>}
                    {columnVisibility.pack_1 && <TableCell>{formatNumber(sales.total_metrics.pack_1 || 0)}</TableCell>}
                    {columnVisibility.pack_2 && <TableCell>{formatNumber(sales.total_metrics.pack_2 || 0)}</TableCell>}
                    {columnVisibility.pack_3 && <TableCell>{formatNumber(sales.total_metrics.pack_3 || 0)}</TableCell>}
                    {columnVisibility.pack_4 && <TableCell>{formatNumber(sales.total_metrics.pack_4 || 0)}</TableCell>}
                    {columnVisibility.upsell_1 && <TableCell>{formatNumber(sales.total_metrics.upsell_1 || 0)}</TableCell>}
                    {columnVisibility.upsell_2 && <TableCell>{formatNumber(sales.total_metrics.upsell_2 || 0)}</TableCell>}
                    {columnVisibility.upsell_3 && <TableCell>{formatNumber(sales.total_metrics.upsell_3 || 0)}</TableCell>}
                    {columnVisibility.aov && <TableCell>{formatCurrency(sales.total_metrics.aov || 0)}</TableCell>}
                    {columnVisibility.budget_allocato && <TableCell>
                      <div>
                        <div className="font-medium">{formatCurrency(sales.budget_allocato)}</div>
                        <div className="text-xs text-muted-foreground">
                          {sales.lead_assegnati} lead × {formatCurrency(sales.costo_medio_lead)}
                        </div>
                      </div>
                    </TableCell>}
                    <TableCell>
                      <Button variant="outline" size="sm">
                        <TrendingUp className="h-4 w-4 mr-2" />
                        Dettagli
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          {salesData.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Nessun sales trovato per il periodo selezionato</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Totale Sales</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{salesData.length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Totale Lead</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatNumber(salesData.reduce((sum, sales) => sum + (sales.total_metrics.lead_generati || 0), 0))}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Totale Incassato</CardTitle>
            <Euro className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(salesData.reduce((sum, sales) => sum + (sales.total_metrics.incassato || 0), 0))}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Budget Totale Allocato</CardTitle>
            <Euro className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(salesData.reduce((sum, sales) => sum + sales.budget_allocato, 0))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;