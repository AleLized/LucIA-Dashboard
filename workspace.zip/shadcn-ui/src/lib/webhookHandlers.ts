import { supabase } from './supabase';
import { GHLLeadPayload } from '@/api/webhooks/ghl';
import { MakeComAdsPayload } from '@/api/webhooks/makecom';

interface KPIEventData {
  contact_id: string;
  location_id: string;
  sales_id: string;
  event_type: string;
  utm_source: string | null;
  utm_campaign: string | null;
  utm_medium: string | null;
  utm_content: string | null;
  utm_term: string | null;
  source: string;
  event_date: string;
  event_data: Record<string, unknown>;
  created_at: string;
}

interface AdsData {
  location_id: string;
  date: string;
  platform: string;
  campaign_id: string;
  campaign_name: string;
  utm_source: string;
  utm_campaign: string;
  utm_medium: string;
  utm_content: string | null;
  utm_term: string | null;
  impressions: number;
  clicks: number;
  spend: number;
  ctr: number;
  cpc: number;
  cpm: number;
  created_at: string;
}

// Real-time data buffer for batch processing
class DataBuffer {
  private buffer: Map<string, KPIEventData[] | AdsData[]> = new Map();
  private batchInterval = 15 * 60 * 1000; // 15 minutes
  private timer: NodeJS.Timeout | null = null;

  constructor() {
    this.startBatchProcessing();
  }

  add(key: string, data: KPIEventData | AdsData) {
    if (!this.buffer.has(key)) {
      this.buffer.set(key, []);
    }
    (this.buffer.get(key) as (KPIEventData | AdsData)[])!.push(data);
  }

  private startBatchProcessing() {
    this.timer = setInterval(async () => {
      await this.processBatch();
    }, this.batchInterval);
  }

  private async processBatch() {
    if (this.buffer.size === 0) return;

    console.log(`Processing batch with ${this.buffer.size} data types`);
    
    for (const [key, data] of this.buffer.entries()) {
      try {
        if (key === 'kpi_events') {
          await this.batchInsertKPIEvents(data as KPIEventData[]);
        } else if (key === 'ads_data') {
          await this.batchInsertAdsData(data as AdsData[]);
        }
      } catch (error) {
        console.error(`Error processing batch for ${key}:`, error);
      }
    }

    // Clear buffer after processing
    this.buffer.clear();
  }

  private async batchInsertKPIEvents(events: KPIEventData[]) {
    const { error } = await supabase
      .from('kpi_events')
      .insert(events);
    
    if (error) {
      console.error('Batch KPI events insert error:', error);
    } else {
      console.log(`Successfully inserted ${events.length} KPI events`);
    }
  }

  private async batchInsertAdsData(adsData: AdsData[]) {
    const { error } = await supabase
      .from('ads_data')
      .insert(adsData);
    
    if (error) {
      console.error('Batch ads data insert error:', error);
    } else {
      console.log(`Successfully inserted ${adsData.length} ads records`);
    }
  }

  stop() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }
}

// Global buffer instance
const dataBuffer = new DataBuffer();

// Process GHL KPI data
export async function processKPIData(payload: GHLLeadPayload) {
  const eventData: KPIEventData = {
    contact_id: payload.contact_id,
    location_id: payload.location_id,
    sales_id: payload.sales_id,
    event_type: payload.event_type,
    utm_source: payload.utm_source || null,
    utm_campaign: payload.utm_campaign || null,
    utm_medium: payload.utm_medium || null,
    utm_content: payload.utm_content || null,
    utm_term: payload.utm_term || null,
    source: payload.source,
    event_date: new Date(payload.timestamp).toISOString().split('T')[0],
    event_data: payload.data,
    created_at: new Date().toISOString()
  };

  // Add to buffer for batch processing
  dataBuffer.add('kpi_events', eventData);

  // Also update daily aggregates immediately for real-time dashboard
  await updateDailyAggregates(payload);

  // Update conversion rates with temporal logic
  await updateConversionRates(payload);
}

// Process Make.com Ads data
export async function processAdsData(payload: MakeComAdsPayload) {
  const adsData: AdsData = {
    location_id: payload.location_id,
    date: payload.date,
    platform: payload.platform,
    campaign_id: payload.campaign_data.campaign_id,
    campaign_name: payload.campaign_data.campaign_name,
    utm_source: payload.campaign_data.utm_source,
    utm_campaign: payload.campaign_data.utm_campaign,
    utm_medium: payload.campaign_data.utm_medium,
    utm_content: payload.campaign_data.utm_content || null,
    utm_term: payload.campaign_data.utm_term || null,
    impressions: payload.metrics.impressions,
    clicks: payload.metrics.clicks,
    spend: payload.metrics.spend,
    ctr: payload.metrics.ctr,
    cpc: payload.metrics.cpc,
    cpm: payload.metrics.cpm,
    created_at: new Date().toISOString()
  };

  // Add to buffer for batch processing
  dataBuffer.add('ads_data', adsData);

  // Update daily aggregates immediately
  await updateAdsAggregates(payload);
}

// Update daily KPI aggregates
async function updateDailyAggregates(payload: GHLLeadPayload) {
  const date = new Date(payload.timestamp).toISOString().split('T')[0];
  
  // Get existing daily aggregate or create new one
  const { data: existing } = await supabase
    .from('daily_kpi_aggregates')
    .select('*')
    .eq('location_id', payload.location_id)
    .eq('date', date)
    .eq('sales_id', payload.sales_id)
    .eq('source', payload.source)
    .single();

  if (existing) {
    // Update existing record
    const updated = {
      ...existing,
      [payload.event_type]: (existing[payload.event_type] || 0) + 1,
      updated_at: new Date().toISOString()
    };
    
    await supabase
      .from('daily_kpi_aggregates')
      .update(updated)
      .eq('id', existing.id);
  } else {
    // Create new record
    const newAggregate = {
      location_id: payload.location_id,
      date,
      sales_id: payload.sales_id,
      source: payload.source,
      utm_source: payload.utm_source,
      utm_campaign: payload.utm_campaign,
      utm_medium: payload.utm_medium,
      lead: payload.event_type === 'lead' ? 1 : 0,
      survey: payload.event_type === 'survey' ? 1 : 0,
      disco_inbound: payload.event_type === 'disco_inbound' ? 1 : 0,
      disco_outbound: payload.event_type === 'disco_outbound' ? 1 : 0,
      demo: payload.event_type === 'demo' ? 1 : 0,
      sale: payload.event_type === 'sale' ? 1 : 0,
      created_at: new Date().toISOString()
    };
    
    await supabase
      .from('daily_kpi_aggregates')
      .insert(newAggregate);
  }
}

// Update ads daily aggregates
async function updateAdsAggregates(payload: MakeComAdsPayload) {
  const { data: existing } = await supabase
    .from('daily_ads_aggregates')
    .select('*')
    .eq('location_id', payload.location_id)
    .eq('date', payload.date)
    .single();

  if (existing) {
    // Update existing record
    await supabase
      .from('daily_ads_aggregates')
      .update({
        impressions: existing.impressions + payload.metrics.impressions,
        clicks: existing.clicks + payload.metrics.clicks,
        spend: existing.spend + payload.metrics.spend,
        updated_at: new Date().toISOString()
      })
      .eq('id', existing.id);
  } else {
    // Create new record
    await supabase
      .from('daily_ads_aggregates')
      .insert({
        location_id: payload.location_id,
        date: payload.date,
        impressions: payload.metrics.impressions,
        clicks: payload.metrics.clicks,
        spend: payload.metrics.spend,
        created_at: new Date().toISOString()
      });
  }
}

// Update conversion rates with temporal logic
async function updateConversionRates(payload: GHLLeadPayload) {
  const today = new Date(payload.timestamp).toISOString().split('T')[0];
  
  // Only update conversion rates for the current day
  if (payload.event_type === 'disco_inbound' || payload.event_type === 'disco_outbound') {
    await calculateDiscoConversionRate(payload.location_id, payload.sales_id, today, payload.event_type);
  } else if (payload.event_type === 'demo') {
    await calculateDemoConversionRate(payload.location_id, payload.sales_id, today);
  } else if (payload.event_type === 'sale') {
    await calculateSaleConversionRate(payload.location_id, payload.sales_id, today);
  }
}

// Calculate disco conversion rate (7 days lookback)
async function calculateDiscoConversionRate(locationId: string, salesId: string, date: string, type: 'disco_inbound' | 'disco_outbound') {
  const sevenDaysAgo = new Date(date);
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
  
  // Get leads from last 7 days
  const { data: leads } = await supabase
    .from('daily_kpi_aggregates')
    .select('lead')
    .eq('location_id', locationId)
    .eq('sales_id', salesId)
    .gte('date', sevenDaysAgo.toISOString().split('T')[0])
    .lte('date', date);
  
  const totalLeads = leads?.reduce((sum, day) => sum + (day.lead || 0), 0) || 0;
  
  // Get existing discos from last 7 days (excluding today's new ones)
  const { data: existingDiscos } = await supabase
    .from('daily_kpi_aggregates')
    .select('disco_inbound, disco_outbound')
    .eq('location_id', locationId)
    .eq('sales_id', salesId)
    .gte('date', sevenDaysAgo.toISOString().split('T')[0])
    .lt('date', date);
  
  const existingDiscoCount = existingDiscos?.reduce((sum, day) => 
    sum + (day.disco_inbound || 0) + (day.disco_outbound || 0), 0) || 0;
  
  // Calculate conversion rate: (new discos) / (total leads - existing discos)
  const denominator = totalLeads - existingDiscoCount;
  const conversionRate = denominator > 0 ? (1 / denominator) * 100 : 0;
  
  // Update conversion rate for today
  await supabase
    .from('daily_conversion_rates')
    .upsert({
      location_id: locationId,
      sales_id: salesId,
      date,
      disco_inbound_rate: type === 'disco_inbound' ? conversionRate : undefined,
      disco_outbound_rate: type === 'disco_outbound' ? conversionRate : undefined,
      updated_at: new Date().toISOString()
    });
}

// Calculate demo conversion rate (30 days lookback)
async function calculateDemoConversionRate(locationId: string, salesId: string, date: string) {
  const thirtyDaysAgo = new Date(date);
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  
  // Get discos from last 30 days
  const { data: discos } = await supabase
    .from('daily_kpi_aggregates')
    .select('disco_inbound, disco_outbound')
    .eq('location_id', locationId)
    .eq('sales_id', salesId)
    .gte('date', thirtyDaysAgo.toISOString().split('T')[0])
    .lte('date', date);
  
  const totalDiscos = discos?.reduce((sum, day) => 
    sum + (day.disco_inbound || 0) + (day.disco_outbound || 0), 0) || 0;
  
  const conversionRate = totalDiscos > 0 ? (1 / totalDiscos) * 100 : 0;
  
  await supabase
    .from('daily_conversion_rates')
    .upsert({
      location_id: locationId,
      sales_id: salesId,
      date,
      demo_rate: conversionRate,
      updated_at: new Date().toISOString()
    });
}

// Calculate sale conversion rate (30 days lookback on demos)
async function calculateSaleConversionRate(locationId: string, salesId: string, date: string) {
  const thirtyDaysAgo = new Date(date);
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  
  // Get demos from last 30 days
  const { data: demos } = await supabase
    .from('daily_kpi_aggregates')
    .select('demo')
    .eq('location_id', locationId)
    .eq('sales_id', salesId)
    .gte('date', thirtyDaysAgo.toISOString().split('T')[0])
    .lte('date', date);
  
  const totalDemos = demos?.reduce((sum, day) => sum + (day.demo || 0), 0) || 0;
  const conversionRate = totalDemos > 0 ? (1 / totalDemos) * 100 : 0;
  
  await supabase
    .from('daily_conversion_rates')
    .upsert({
      location_id: locationId,
      sales_id: salesId,
      date,
      sale_rate: conversionRate,
      updated_at: new Date().toISOString()
    });
}

export { dataBuffer };