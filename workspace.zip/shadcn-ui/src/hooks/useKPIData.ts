import { useState, useEffect } from 'react';
import { supabaseAdmin } from '@/lib/supabase';

export interface KPIData {
  id: string;
  location_id: string;
  date: string;
  leads?: number;
  sales_count?: number;
  revenue?: number;
  ad_spend?: number;
  impressions?: number;
  clicks?: number;
  surveys?: number;
  demos?: number;
  contracts?: number;
  roas?: number;
  cost_per_lead?: number;
  conversion_rate?: number;
  created_at: string;
  updated_at: string;
}

export const useKPIData = (locationId?: string) => {
  const [kpiData, setKpiData] = useState<KPIData[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchKPIData = async (targetLocationId: string) => {
    try {
      setLoading(true);
      setError(null);
      
      console.log('📊 [KPI HOOK] Fetching KPI data for location:', targetLocationId);
      
      // Usa array query per evitare PGRST116
      const { data, error: kpiError } = await supabaseAdmin
        .from('daily_kpis')
        .select('*')
        .eq('location_id', targetLocationId)
        .order('date', { ascending: false })
        .limit(30);
      
      if (kpiError) {
        console.error('❌ [KPI HOOK] Error fetching KPI data:', kpiError.message);
        setError(kpiError.message);
        setKpiData([]);
        return;
      }
      
      if (!data || data.length === 0) {
        console.log('⚠️ [KPI HOOK] No KPI data found for location:', targetLocationId);
        setKpiData([]);
        return;
      }
      
      console.log('✅ [KPI HOOK] KPI data fetched successfully:', data.length, 'records');
      setKpiData(data);
      
    } catch (error) {
      console.error('❌ [KPI HOOK] Exception fetching KPI data:', error);
      setError('Errore durante il recupero dei dati KPI');
      setKpiData([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (locationId) {
      fetchKPIData(locationId);
    }
  }, [locationId]);

  const refreshData = () => {
    if (locationId) {
      fetchKPIData(locationId);
    }
  };

  return {
    kpiData,
    loading,
    error,
    refreshData
  };
};