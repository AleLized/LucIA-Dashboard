import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  TrendingUp, 
  Users, 
  Phone, 
  UserCheck, 
  ShoppingCart, 
  Package, 
  Settings,
  Building2
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface SidebarProps {
  userRole: 'admin' | 'sales' | 'agency';
}

const Sidebar: React.FC<SidebarProps> = ({ userRole }) => {
  const location = useLocation();

  const navigationItems = [
    {
      name: 'Dashboard',
      href: '/dashboard',
      icon: LayoutDashboard,
      roles: ['admin', 'sales', 'agency']
    },
    {
      name: 'ADS',
      href: '/ads',
      icon: TrendingUp,
      roles: ['admin', 'agency']
    },
    {
      name: 'Organic',
      href: '/organic',
      icon: Users,
      roles: ['admin', 'agency']
    },
    {
      name: 'Outbound',
      href: '/outbound',
      icon: Phone,
      roles: ['admin', 'agency']
    },
    {
      name: 'Sales',
      href: '/sales',
      icon: UserCheck,
      roles: ['admin', 'agency']
    },
    {
      name: 'Vendite',
      href: '/vendite',
      icon: ShoppingCart,
      roles: ['admin', 'agency']
    },
    {
      name: 'Prodotti',
      href: '/prodotti',
      icon: Package,
      roles: ['admin', 'agency']
    },
    {
      name: 'Settings',
      href: '/settings',
      icon: Settings,
      roles: ['admin', 'agency']
    }
  ];

  // Agency-specific items
  if (userRole === 'agency') {
    navigationItems.push({
      name: 'Agency Dashboard',
      href: '/agency',
      icon: Building2,
      roles: ['agency']
    });
  }

  const filteredItems = navigationItems.filter(item => 
    item.roles.includes(userRole)
  );

  return (
    <div className="flex h-screen w-64 flex-col bg-gray-900 text-white">
      {/* Logo */}
      <div className="flex h-16 items-center justify-center border-b border-gray-800">
        <div className="flex items-center space-x-2">
          <div className="h-8 w-8 rounded-lg bg-gradient-to-r from-blue-500 to-purple-600"></div>
          <span className="text-xl font-bold">LucIA KPI</span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-1 px-3 py-4">
        {filteredItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.href;
          
          return (
            <NavLink
              key={item.name}
              to={item.href}
              className={cn(
                'group flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200',
                isActive
                  ? 'bg-gray-800 text-white'
                  : 'text-gray-300 hover:bg-gray-800 hover:text-white'
              )}
            >
              <Icon
                className={cn(
                  'mr-3 h-5 w-5 flex-shrink-0',
                  isActive ? 'text-white' : 'text-gray-400 group-hover:text-white'
                )}
              />
              {item.name}
            </NavLink>
          );
        })}
      </nav>

      {/* User Info */}
      <div className="border-t border-gray-800 p-4">
        <div className="flex items-center space-x-3">
          <div className="h-8 w-8 rounded-full bg-gradient-to-r from-green-400 to-blue-500"></div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">
              {userRole === 'agency' ? 'Agency Admin' : userRole === 'admin' ? 'Admin' : 'Sales User'}
            </p>
            <p className="text-xs text-gray-400 truncate">
              {userRole.charAt(0).toUpperCase() + userRole.slice(1)} Role
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;