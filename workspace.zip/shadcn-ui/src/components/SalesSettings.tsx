import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase, Sales } from '@/lib/supabaseClient';
import { Plus, Edit, Trash2, CheckCircle, Clock, XCircle, Copy } from 'lucide-react';

const SalesSettings = () => {
  const [sales, setSales] = useState<Sales[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingSales, setEditingSales] = useState<Sales | null>(null);
  const [formData, setFormData] = useState({
    nome: '',
    cognome: '',
    email: '',
    telefono: '',
    ghl_contact_id: ''
  });

  useEffect(() => {
    fetchSales();
  }, []);

  const fetchSales = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('sales')
        .select('*')
        .eq('location_id', 'test_kpi_2025')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSales(data || []);
    } catch (error) {
      console.error('Error fetching sales:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const salesData = {
        ...formData,
        location_id: 'test_kpi_2025',
        status: 'confirmed' as const
      };

      if (editingSales) {
        const { error } = await supabase
          .from('sales')
          .update(salesData)
          .eq('id', editingSales.id);
        
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('sales')
          .insert(salesData);
        
        if (error) throw error;
      }

      setFormData({
        nome: '',
        cognome: '',
        email: '',
        telefono: '',
        ghl_contact_id: ''
      });
      setIsAddDialogOpen(false);
      setEditingSales(null);
      fetchSales();
    } catch (error) {
      console.error('Error saving sales:', error);
    }
  };

  const handleEdit = (sales: Sales) => {
    setFormData({
      nome: sales.nome,
      cognome: sales.cognome,
      email: sales.email,
      telefono: sales.telefono || '',
      ghl_contact_id: sales.ghl_contact_id || ''
    });
    setEditingSales(sales);
    setIsAddDialogOpen(true);
  };

  const handleDelete = async (salesId: string) => {
    if (!confirm('Sei sicuro di voler eliminare questo sales?')) return;

    try {
      const { error } = await supabase
        .from('sales')
        .delete()
        .eq('id', salesId);

      if (error) throw error;
      fetchSales();
    } catch (error) {
      console.error('Error deleting sales:', error);
    }
  };

  const handleStatusChange = async (salesId: string, newStatus: 'pending' | 'confirmed' | 'rejected') => {
    try {
      const { error } = await supabase
        .from('sales')
        .update({ status: newStatus })
        .eq('id', salesId);

      if (error) throw error;
      fetchSales();
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'confirmed':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-yellow-600" />;
      case 'rejected':
        return <XCircle className="h-4 w-4 text-red-600" />;
      default:
        return null;
    }
  };

  const getStatusVariant = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'default';
      case 'pending':
        return 'secondary';
      case 'rejected':
        return 'destructive';
      default:
        return 'outline';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Gestione Sales</h2>
          <p className="text-muted-foreground">
            Aggiungi, modifica e gestisci i sales del tuo team
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => {
              setEditingSales(null);
              setFormData({
                nome: '',
                cognome: '',
                email: '',
                telefono: '',
                ghl_contact_id: ''
              });
            }}>
              <Plus className="h-4 w-4 mr-2" />
              Aggiungi Sales
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingSales ? 'Modifica Sales' : 'Aggiungi Nuovo Sales'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="nome">Nome *</Label>
                  <Input
                    id="nome"
                    value={formData.nome}
                    onChange={(e) => setFormData(prev => ({ ...prev, nome: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="cognome">Cognome *</Label>
                  <Input
                    id="cognome"
                    value={formData.cognome}
                    onChange={(e) => setFormData(prev => ({ ...prev, cognome: e.target.value }))}
                    required
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="telefono">Telefono</Label>
                <Input
                  id="telefono"
                  value={formData.telefono}
                  onChange={(e) => setFormData(prev => ({ ...prev, telefono: e.target.value }))}
                  placeholder="+39 333 1234567"
                />
              </div>
              
              <div>
                <Label htmlFor="ghl_contact_id">GHL Contact ID</Label>
                <Input
                  id="ghl_contact_id"
                  value={formData.ghl_contact_id}
                  onChange={(e) => setFormData(prev => ({ ...prev, ghl_contact_id: e.target.value }))}
                  placeholder="ID contatto GoHighLevel"
                />
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Annulla
                </Button>
                <Button type="submit">
                  {editingSales ? 'Aggiorna' : 'Aggiungi'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Auto-detection Alert */}
      <Alert>
        <CheckCircle className="h-4 w-4" />
        <AlertDescription>
          <strong>Rilevamento Automatico:</strong> I sales sconosciuti che inviano dati tramite webhook 
          vengono automaticamente aggiunti con status "In attesa di conferma".
        </AlertDescription>
      </Alert>

      {/* Sales Table */}
      <Card>
        <CardHeader>
          <CardTitle>Sales Registrati ({sales.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Telefono</TableHead>
                  <TableHead>GHL ID</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Data Creazione</TableHead>
                  <TableHead>Azioni</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sales.map((salesItem) => (
                  <TableRow key={salesItem.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{salesItem.nome} {salesItem.cognome}</div>
                        <div className="text-sm text-muted-foreground flex items-center gap-1">
                          ID: {salesItem.id}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard(salesItem.id)}
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{salesItem.email}</TableCell>
                    <TableCell>{salesItem.telefono || '-'}</TableCell>
                    <TableCell>
                      {salesItem.ghl_contact_id ? (
                        <div className="flex items-center gap-1">
                          <code className="text-xs bg-muted px-2 py-1 rounded">
                            {salesItem.ghl_contact_id}
                          </code>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard(salesItem.ghl_contact_id!)}
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                      ) : (
                        '-'
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Badge variant={getStatusVariant(salesItem.status)} className="flex items-center gap-1">
                          {getStatusIcon(salesItem.status)}
                          {salesItem.status === 'confirmed' && 'Confermato'}
                          {salesItem.status === 'pending' && 'In Attesa'}
                          {salesItem.status === 'rejected' && 'Rifiutato'}
                        </Badge>
                        {salesItem.status === 'pending' && (
                          <div className="flex gap-1">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleStatusChange(salesItem.id, 'confirmed')}
                            >
                              <CheckCircle className="h-3 w-3" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleStatusChange(salesItem.id, 'rejected')}
                            >
                              <XCircle className="h-3 w-3" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {new Date(salesItem.created_at).toLocaleDateString('it-IT')}
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(salesItem)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDelete(salesItem.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          {sales.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Nessun sales registrato</p>
              <Button className="mt-4" onClick={() => setIsAddDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Aggiungi il primo sales
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default SalesSettings;