import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase, Product, ProductPrice } from '@/lib/supabaseClient';
import { Plus, Edit, Trash2, CheckCircle, Clock, XCircle, Copy, History, Euro } from 'lucide-react';

interface ProductWithPrices extends Product {
  current_price?: ProductPrice;
  price_history?: ProductPrice[];
}

const ProductSettings = () => {
  const [products, setProducts] = useState<ProductWithPrices[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isPriceDialogOpen, setIsPriceDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<ProductWithPrices | null>(null);
  
  const [productForm, setProductForm] = useState({
    nome: '',
    descrizione: '',
    categoria: 'pack' as 'pack' | 'upsell' | 'other'
  });

  const [priceForm, setPriceForm] = useState({
    prezzo: '',
    commissione_percentuale: '',
    commissione_fissa: '',
    valido_da: new Date().toISOString().split('T')[0]
  });

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    setLoading(true);
    try {
      // Fetch products
      const { data: productsData, error: productsError } = await supabase
        .from('prodotti')
        .select('*')
        .eq('location_id', 'test_kpi_2025')
        .order('created_at', { ascending: false });

      if (productsError) throw productsError;

      // Fetch current prices for each product
      const productsWithPrices: ProductWithPrices[] = [];
      
      for (const product of productsData || []) {
        const { data: pricesData, error: pricesError } = await supabase
          .from('prodotti_prezzi')
          .select('*')
          .eq('prodotto_id', product.id)
          .order('valido_da', { ascending: false });

        if (pricesError) {
          console.error('Error fetching prices for product', product.id, pricesError);
          continue;
        }

        const currentPrice = pricesData?.find(p => 
          !p.valido_fino || new Date(p.valido_fino) > new Date()
        );

        productsWithPrices.push({
          ...product,
          current_price: currentPrice,
          price_history: pricesData || []
        });
      }

      setProducts(productsWithPrices);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const productData = {
        ...productForm,
        location_id: 'test_kpi_2025',
        status: 'confirmed' as const
      };

      if (editingProduct) {
        const { error } = await supabase
          .from('prodotti')
          .update(productData)
          .eq('id', editingProduct.id);
        
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('prodotti')
          .insert(productData);
        
        if (error) throw error;
      }

      setProductForm({
        nome: '',
        descrizione: '',
        categoria: 'pack'
      });
      setIsAddDialogOpen(false);
      setEditingProduct(null);
      fetchProducts();
    } catch (error) {
      console.error('Error saving product:', error);
    }
  };

  const handlePriceSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedProduct) return;

    try {
      // End current price if exists
      if (selectedProduct.current_price) {
        const { error: updateError } = await supabase
          .from('prodotti_prezzi')
          .update({ valido_fino: new Date().toISOString() })
          .eq('id', selectedProduct.current_price.id);

        if (updateError) throw updateError;
      }

      // Add new price
      const { error: insertError } = await supabase
        .from('prodotti_prezzi')
        .insert({
          prodotto_id: selectedProduct.id,
          prezzo: parseFloat(priceForm.prezzo),
          commissione_percentuale: priceForm.commissione_percentuale ? parseFloat(priceForm.commissione_percentuale) : null,
          commissione_fissa: priceForm.commissione_fissa ? parseFloat(priceForm.commissione_fissa) : null,
          valido_da: priceForm.valido_da
        });

      if (insertError) throw insertError;

      setPriceForm({
        prezzo: '',
        commissione_percentuale: '',
        commissione_fissa: '',
        valido_da: new Date().toISOString().split('T')[0]
      });
      setIsPriceDialogOpen(false);
      setSelectedProduct(null);
      fetchProducts();
    } catch (error) {
      console.error('Error saving price:', error);
    }
  };

  const handleEdit = (product: Product) => {
    setProductForm({
      nome: product.nome,
      descrizione: product.descrizione || '',
      categoria: product.categoria
    });
    setEditingProduct(product);
    setIsAddDialogOpen(true);
  };

  const handleDelete = async (productId: string) => {
    if (!confirm('Sei sicuro di voler eliminare questo prodotto?')) return;

    try {
      const { error } = await supabase
        .from('prodotti')
        .delete()
        .eq('id', productId);

      if (error) throw error;
      fetchProducts();
    } catch (error) {
      console.error('Error deleting product:', error);
    }
  };

  const handleStatusChange = async (productId: string, newStatus: 'pending' | 'confirmed' | 'rejected') => {
    try {
      const { error } = await supabase
        .from('prodotti')
        .update({ status: newStatus })
        .eq('id', productId);

      if (error) throw error;
      fetchProducts();
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'confirmed':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-yellow-600" />;
      case 'rejected':
        return <XCircle className="h-4 w-4 text-red-600" />;
      default:
        return null;
    }
  };

  const getStatusVariant = (status: string): 'default' | 'secondary' | 'destructive' | 'outline' => {
    switch (status) {
      case 'confirmed':
        return 'default';
      case 'pending':
        return 'secondary';
      case 'rejected':
        return 'destructive';
      default:
        return 'outline';
    }
  };

  const getCategoryColor = (categoria: string) => {
    switch (categoria) {
      case 'pack':
        return 'bg-blue-100 text-blue-800';
      case 'upsell':
        return 'bg-green-100 text-green-800';
      case 'other':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Gestione Prodotti</h2>
          <p className="text-muted-foreground">
            Gestisci prodotti, prezzi e commissioni con storico completo
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => {
              setEditingProduct(null);
              setProductForm({
                nome: '',
                descrizione: '',
                categoria: 'pack'
              });
            }}>
              <Plus className="h-4 w-4 mr-2" />
              Aggiungi Prodotto
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingProduct ? 'Modifica Prodotto' : 'Aggiungi Nuovo Prodotto'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleProductSubmit} className="space-y-4">
              <div>
                <Label htmlFor="nome">Nome Prodotto *</Label>
                <Input
                  id="nome"
                  value={productForm.nome}
                  onChange={(e) => setProductForm(prev => ({ ...prev, nome: e.target.value }))}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="descrizione">Descrizione</Label>
                <Textarea
                  id="descrizione"
                  value={productForm.descrizione}
                  onChange={(e) => setProductForm(prev => ({ ...prev, descrizione: e.target.value }))}
                  rows={3}
                />
              </div>
              
              <div>
                <Label htmlFor="categoria">Categoria *</Label>
                <Select
                  value={productForm.categoria}
                  onValueChange={(value: 'pack' | 'upsell' | 'other') => setProductForm(prev => ({ ...prev, categoria: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pack">Pack</SelectItem>
                    <SelectItem value="upsell">Upsell</SelectItem>
                    <SelectItem value="other">Altro</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Annulla
                </Button>
                <Button type="submit">
                  {editingProduct ? 'Aggiorna' : 'Aggiungi'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Auto-detection Alert */}
      <Alert>
        <CheckCircle className="h-4 w-4" />
        <AlertDescription>
          <strong>Rilevamento Automatico:</strong> I prodotti sconosciuti che arrivano tramite webhook 
          vengono automaticamente aggiunti con status "In attesa di conferma".
        </AlertDescription>
      </Alert>

      {/* Products Table */}
      <Card>
        <CardHeader>
          <CardTitle>Prodotti Configurati ({products.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Prodotto</TableHead>
                  <TableHead>Categoria</TableHead>
                  <TableHead>Prezzo Attuale</TableHead>
                  <TableHead>Commissioni</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Data Creazione</TableHead>
                  <TableHead>Azioni</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {products.map((product) => (
                  <TableRow key={product.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{product.nome}</div>
                        <div className="text-sm text-muted-foreground">{product.descrizione}</div>
                        <div className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                          ID: {product.id}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard(product.id)}
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getCategoryColor(product.categoria)}>
                        {product.categoria.toUpperCase()}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {product.current_price ? (
                        <div>
                          <div className="font-medium">
                            {new Intl.NumberFormat('it-IT', {
                              style: 'currency',
                              currency: 'EUR'
                            }).format(product.current_price.prezzo)}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            dal {new Date(product.current_price.valido_da).toLocaleDateString('it-IT')}
                          </div>
                        </div>
                      ) : (
                        <Badge variant="outline">Nessun prezzo</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      {product.current_price ? (
                        <div className="text-sm">
                          {product.current_price.commissione_percentuale && (
                            <div>{product.current_price.commissione_percentuale}%</div>
                          )}
                          {product.current_price.commissione_fissa && (
                            <div>
                              {new Intl.NumberFormat('it-IT', {
                                style: 'currency',
                                currency: 'EUR'
                              }).format(product.current_price.commissione_fissa)}
                            </div>
                          )}
                          {!product.current_price.commissione_percentuale && !product.current_price.commissione_fissa && (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </div>
                      ) : (
                        '-'
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Badge variant={getStatusVariant(product.status)} className="flex items-center gap-1">
                          {getStatusIcon(product.status)}
                          {product.status === 'confirmed' && 'Confermato'}
                          {product.status === 'pending' && 'In Attesa'}
                          {product.status === 'rejected' && 'Rifiutato'}
                        </Badge>
                        {product.status === 'pending' && (
                          <div className="flex gap-1">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleStatusChange(product.id, 'confirmed')}
                            >
                              <CheckCircle className="h-3 w-3" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleStatusChange(product.id, 'rejected')}
                            >
                              <XCircle className="h-3 w-3" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {new Date(product.created_at).toLocaleDateString('it-IT')}
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(product)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedProduct(product);
                            setIsPriceDialogOpen(true);
                          }}
                        >
                          <Euro className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDelete(product.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          {products.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Nessun prodotto configurato</p>
              <Button className="mt-4" onClick={() => setIsAddDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Aggiungi il primo prodotto
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Price Management Dialog */}
      <Dialog open={isPriceDialogOpen} onOpenChange={setIsPriceDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              Gestione Prezzi - {selectedProduct?.nome}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Add New Price Form */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Nuovo Prezzo</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handlePriceSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="prezzo">Prezzo *</Label>
                      <Input
                        id="prezzo"
                        type="number"
                        step="0.01"
                        value={priceForm.prezzo}
                        onChange={(e) => setPriceForm(prev => ({ ...prev, prezzo: e.target.value }))}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="valido_da">Valido da *</Label>
                      <Input
                        id="valido_da"
                        type="date"
                        value={priceForm.valido_da}
                        onChange={(e) => setPriceForm(prev => ({ ...prev, valido_da: e.target.value }))}
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="commissione_percentuale">Commissione %</Label>
                      <Input
                        id="commissione_percentuale"
                        type="number"
                        step="0.01"
                        value={priceForm.commissione_percentuale}
                        onChange={(e) => setPriceForm(prev => ({ ...prev, commissione_percentuale: e.target.value }))}
                        placeholder="es. 15.5"
                      />
                    </div>
                    <div>
                      <Label htmlFor="commissione_fissa">Commissione Fissa €</Label>
                      <Input
                        id="commissione_fissa"
                        type="number"
                        step="0.01"
                        value={priceForm.commissione_fissa}
                        onChange={(e) => setPriceForm(prev => ({ ...prev, commissione_fissa: e.target.value }))}
                        placeholder="es. 100.00"
                      />
                    </div>
                  </div>
                  
                  <Button type="submit" className="w-full">
                    Aggiungi Prezzo
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Price History */}
            {selectedProduct?.price_history && selectedProduct.price_history.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <History className="h-5 w-5" />
                    Storico Prezzi
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {selectedProduct.price_history.map((price, index) => (
                      <div key={price.id} className="flex justify-between items-center p-3 border rounded">
                        <div>
                          <div className="font-medium">
                            {new Intl.NumberFormat('it-IT', {
                              style: 'currency',
                              currency: 'EUR'
                            }).format(price.prezzo)}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {new Date(price.valido_da).toLocaleDateString('it-IT')} - 
                            {price.valido_fino ? new Date(price.valido_fino).toLocaleDateString('it-IT') : 'Attuale'}
                          </div>
                        </div>
                        <div className="text-sm">
                          {price.commissione_percentuale && `${price.commissione_percentuale}%`}
                          {price.commissione_fissa && ` + €${price.commissione_fissa}`}
                        </div>
                        {index === 0 && !price.valido_fino && (
                          <Badge>Attuale</Badge>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ProductSettings;