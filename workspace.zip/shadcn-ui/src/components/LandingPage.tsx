import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Building2, 
  Users, 
  UserCheck, 
  ArrowRight, 
  Shield, 
  BarChart3,
  Zap
} from 'lucide-react';

const LandingPage: React.FC = () => {
  const navigate = useNavigate();

  const loginOptions = [
    {
      id: 'dashboard',
      title: 'Dashboard Login',
      description: 'Accesso per singola location con Location ID',
      icon: Building2,
      color: 'from-blue-600 to-indigo-600',
      hoverColor: 'hover:from-blue-700 hover:to-indigo-700',
      route: '/dashboard-login',
      features: ['KPI Dashboard', 'Performance Analytics', 'Real-time Data']
    },
    {
      id: 'agency',
      title: 'Agency Login',
      description: 'Accesso per agenzia con Agency ID (multiple locations)',
      icon: Users,
      color: 'from-purple-600 to-pink-600',
      hoverColor: 'hover:from-purple-700 hover:to-pink-700',
      route: '/agency-login',
      features: ['Multi-location View', 'Agency Dashboard', 'Consolidated Reports']
    },
    {
      id: 'sales',
      title: 'Sales Login',
      description: 'Accesso per singolo sales con Sales ID',
      icon: UserCheck,
      color: 'from-green-600 to-emerald-600',
      hoverColor: 'hover:from-green-700 hover:to-emerald-700',
      route: '/sales-login',
      features: ['Personal Performance', 'Sales Metrics', 'Individual KPIs']
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12 pt-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full shadow-xl mb-6">
            <BarChart3 className="h-10 w-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            LucIA KPI Platform
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
            Scegli il tipo di accesso per visualizzare le performance e analytics
          </p>
          
          {/* Status Indicators */}
          <div className="flex justify-center gap-4 mt-6">
            <div className="flex items-center gap-2 bg-green-50 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              Sistema Attivo
            </div>
            <div className="flex items-center gap-2 bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
              <Shield className="h-3 w-3" />
              Sicuro
            </div>
            <div className="flex items-center gap-2 bg-purple-50 text-purple-700 px-3 py-1 rounded-full text-sm font-medium">
              <Zap className="h-3 w-3" />
              Real-time
            </div>
          </div>
        </div>

        {/* Login Options Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {loginOptions.map((option) => {
            const IconComponent = option.icon;
            return (
              <Card 
                key={option.id} 
                className="relative overflow-hidden border-0 shadow-xl bg-white/90 backdrop-blur-sm hover:shadow-2xl transition-all duration-300 group"
              >
                <CardHeader className="pb-4">
                  <div className={`inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r ${option.color} rounded-2xl shadow-lg mb-4 group-hover:scale-110 transition-transform duration-300`}>
                    <IconComponent className="h-8 w-8 text-white" />
                  </div>
                  <CardTitle className="text-xl font-bold text-gray-900 mb-2">
                    {option.title}
                  </CardTitle>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {option.description}
                  </p>
                </CardHeader>
                
                <CardContent className="pt-0">
                  {/* Features List */}
                  <div className="space-y-2 mb-6">
                    {option.features.map((feature, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm text-gray-600">
                        <div className="w-1.5 h-1.5 bg-gray-400 rounded-full"></div>
                        {feature}
                      </div>
                    ))}
                  </div>
                  
                  {/* Action Button */}
                  <Button
                    onClick={() => navigate(option.route)}
                    className={`w-full h-12 text-base font-semibold bg-gradient-to-r ${option.color} ${option.hoverColor} transition-all duration-200 shadow-lg hover:shadow-xl group`}
                  >
                    <span>Accedi</span>
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform duration-200" />
                  </Button>
                </CardContent>
                
                {/* Decorative Element */}
                <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${option.color} opacity-5 rounded-full -translate-y-16 translate-x-16`}></div>
              </Card>
            );
          })}
        </div>

        {/* Test Info Section */}
        <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 shadow-lg">
          <CardContent className="p-6">
            <div className="text-center">
              <h3 className="text-lg font-semibold text-blue-900 mb-4">
                🧪 Informazioni per Testing
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div className="bg-white rounded-lg p-4 border border-blue-100">
                  <h4 className="font-semibold text-blue-800 mb-2">Dashboard Login</h4>
                  <p className="text-blue-700">
                    Location IDs: <code className="bg-blue-100 px-1 rounded">lucia_test_001</code>, <code className="bg-blue-100 px-1 rounded">lucia_test_002</code>
                  </p>
                </div>
                <div className="bg-white rounded-lg p-4 border border-purple-100">
                  <h4 className="font-semibold text-purple-800 mb-2">Agency Login</h4>
                  <p className="text-purple-700">
                    Agency ID: <code className="bg-purple-100 px-1 rounded">0-297-739</code>
                  </p>
                </div>
                <div className="bg-white rounded-lg p-4 border border-green-100">
                  <h4 className="font-semibold text-green-800 mb-2">Sales Login</h4>
                  <p className="text-green-700">
                    In sviluppo - Sales ID personalizzati
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-8 text-sm text-gray-500">
          <p>© 2024 LucIA KPI Platform • Powered by Supabase & React</p>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;