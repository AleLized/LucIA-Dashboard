import React from 'react';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import { cn } from '@/lib/utils';

export interface DateRange {
  from: Date;
  to: Date;
}

interface DateRangeFilterProps {
  dateRange: DateRange;
  onDateRangeChange: (range: DateRange) => void;
  compareRange?: DateRange;
  onCompareRangeChange?: (range: DateRange | undefined) => void;
  showCompare?: boolean;
  compact?: boolean;
}

export const DateRangeFilter: React.FC<DateRangeFilterProps> = ({
  dateRange,
  onDateRangeChange,
  compareRange,
  onCompareRangeChange,
  showCompare = false,
  compact = false
}) => {
  const [showComparison, setShowComparison] = React.useState(!!compareRange);

  const handleComparisonToggle = (enabled: boolean) => {
    setShowComparison(enabled);
    if (!enabled) {
      onCompareRangeChange?.(undefined);
    } else {
      // Set default comparison range (previous period)
      const daysDiff = Math.ceil((dateRange.to.getTime() - dateRange.from.getTime()) / (1000 * 60 * 60 * 24));
      const compareFrom = new Date(dateRange.from);
      compareFrom.setDate(compareFrom.getDate() - daysDiff);
      const compareTo = new Date(dateRange.from);
      compareTo.setDate(compareTo.getDate() - 1);
      
      onCompareRangeChange?.({ from: compareFrom, to: compareTo });
    }
  };

  return (
    <div className={cn("space-y-3", compact && "space-y-2")}>
      {/* Main Date Range */}
      <div className="space-y-2">
        <Label className="text-sm font-medium">Periodo Principale</Label>
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className={cn(
                "w-full justify-start text-left font-normal",
                !dateRange && "text-muted-foreground"
              )}
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {dateRange?.from ? (
                dateRange.to ? (
                  <>
                    {format(dateRange.from, "dd MMM yyyy", { locale: it })} -{" "}
                    {format(dateRange.to, "dd MMM yyyy", { locale: it })}
                  </>
                ) : (
                  format(dateRange.from, "dd MMM yyyy", { locale: it })
                )
              ) : (
                <span>Seleziona periodo</span>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              initialFocus
              mode="range"
              defaultMonth={dateRange?.from}
              selected={{ from: dateRange.from, to: dateRange.to }}
              onSelect={(range) => {
                if (range?.from && range?.to) {
                  onDateRangeChange({ from: range.from, to: range.to });
                }
              }}
              numberOfMonths={2}
            />
          </PopoverContent>
        </Popover>
      </div>

      {/* Comparison Toggle */}
      {showCompare && (
        <div className="flex items-center space-x-2">
          <Switch
            id="comparison"
            checked={showComparison}
            onCheckedChange={handleComparisonToggle}
          />
          <Label htmlFor="comparison" className="text-sm">
            Confronta con periodo precedente
          </Label>
        </div>
      )}

      {/* Comparison Date Range */}
      {showCompare && showComparison && (
        <div className="space-y-2">
          <Label className="text-sm font-medium">Periodo di Confronto</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  "w-full justify-start text-left font-normal",
                  !compareRange && "text-muted-foreground"
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {compareRange?.from ? (
                  compareRange.to ? (
                    <>
                      {format(compareRange.from, "dd MMM yyyy", { locale: it })} -{" "}
                      {format(compareRange.to, "dd MMM yyyy", { locale: it })}
                    </>
                  ) : (
                    format(compareRange.from, "dd MMM yyyy", { locale: it })
                  )
                ) : (
                  <span>Seleziona periodo confronto</span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                initialFocus
                mode="range"
                defaultMonth={compareRange?.from}
                selected={compareRange ? { from: compareRange.from, to: compareRange.to } : undefined}
                onSelect={(range) => {
                  if (range?.from && range?.to) {
                    onCompareRangeChange?.({ from: range.from, to: range.to });
                  }
                }}
                numberOfMonths={2}
              />
            </PopoverContent>
          </Popover>
        </div>
      )}
    </div>
  );
};