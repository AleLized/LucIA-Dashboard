import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Eye, 
  EyeOff, 
  LogIn, 
  MapPin, 
  Loader2, 
  CheckCircle, 
  AlertCircle,
  Database,
  Shield,
  Zap
} from 'lucide-react';

const LoginForm: React.FC = () => {
  const [locationId, setLocationId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { signIn, loading } = useAuth();

  // Clear messages after 5 seconds
  useEffect(() => {
    if (error || success) {
      const timer = setTimeout(() => {
        setError('');
        setSuccess('');
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [error, success]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setIsSubmitting(true);

    // Client-side validation
    if (!locationId.trim()) {
      setError('Location ID è obbligatorio');
      setIsSubmitting(false);
      return;
    }

    if (!password.trim()) {
      setError('Password è obbligatoria');
      setIsSubmitting(false);
      return;
    }

    try {
      const result = await signIn(locationId.trim(), password);
      
      if (result.error) {
        setError(result.error);
      } else {
        setSuccess('Login effettuato con successo! Reindirizzamento in corso...');
      }
    } catch (err) {
      setError('Errore imprevisto durante il login');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleTestLogin = async (testLocationId: string) => {
    setError('');
    setSuccess('');
    setLocationId(testLocationId);
    setPassword('test123');
    setIsSubmitting(true);
    
    try {
      const result = await signIn(testLocationId, 'test123');
      
      if (result.error) {
        setError(result.error);
      } else {
        setSuccess(`Accesso test completato per ${testLocationId}!`);
      }
    } catch (err) {
      setError('Errore durante l\'accesso test');
    } finally {
      setIsSubmitting(false);
    }
  };

  const isLoading = loading || isSubmitting;

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 p-4">
      <div className="w-full max-w-md">
        {/* Main Login Card */}
        <Card className="shadow-2xl border-0 bg-white/95 backdrop-blur-sm">
          <CardHeader className="space-y-4 pb-6">
            {/* Logo and Branding */}
            <div className="flex items-center justify-center">
              <div className="relative">
                <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-4 rounded-2xl shadow-lg">
                  <LogIn className="h-8 w-8 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 bg-green-500 rounded-full p-1">
                  <Shield className="h-3 w-3 text-white" />
                </div>
              </div>
            </div>
            
            <div className="text-center space-y-2">
              <CardTitle className="text-3xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
                LucIA KPI Platform
              </CardTitle>
              <p className="text-gray-600 text-sm leading-relaxed">
                Accedi con la tua <strong>Location ID</strong> per visualizzare<br />
                le performance e analytics in tempo reale
              </p>
            </div>

            {/* Features Pills */}
            <div className="flex justify-center gap-2 flex-wrap">
              <div className="flex items-center gap-1 bg-blue-50 text-blue-700 px-2 py-1 rounded-full text-xs font-medium">
                <Database className="h-3 w-3" />
                Real-time Data
              </div>
              <div className="flex items-center gap-1 bg-green-50 text-green-700 px-2 py-1 rounded-full text-xs font-medium">
                <Zap className="h-3 w-3" />
                Fast Analytics
              </div>
            </div>
          </CardHeader>

          <CardContent className="space-y-6 pb-8">
            {/* Success/Error Messages */}
            {error && (
              <Alert variant="destructive" className="border-red-200 bg-red-50">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="text-red-800">{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert className="border-green-200 bg-green-50">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">{success}</AlertDescription>
              </Alert>
            )}
            
            {/* Login Form */}
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label 
                  htmlFor="locationId" 
                  className="flex items-center gap-2 text-sm font-semibold text-gray-700"
                >
                  <MapPin className="h-4 w-4 text-blue-600" />
                  Location ID
                </Label>
                <Input
                  id="locationId"
                  type="text"
                  placeholder="es. lucia_test_001"
                  value={locationId}
                  onChange={(e) => setLocationId(e.target.value)}
                  required
                  disabled={isLoading}
                  className="h-12 text-base border-gray-200 focus:border-blue-500 focus:ring-blue-500 transition-all duration-200"
                  autoComplete="username"
                />
              </div>
              
              <div className="space-y-2">
                <Label 
                  htmlFor="password" 
                  className="text-sm font-semibold text-gray-700"
                >
                  Password
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Inserisci la tua password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    disabled={isLoading}
                    className="h-12 text-base border-gray-200 focus:border-blue-500 focus:ring-blue-500 pr-12 transition-all duration-200"
                    autoComplete="current-password"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-12 px-3 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                    disabled={isLoading}
                    tabIndex={-1}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 text-gray-400" />
                    ) : (
                      <Eye className="h-4 w-4 text-gray-400" />
                    )}
                  </Button>
                </div>
              </div>
              
              <Button 
                type="submit" 
                className="w-full h-12 text-base font-semibold bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 transition-all duration-200 shadow-lg hover:shadow-xl" 
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Accesso in corso...
                  </>
                ) : (
                  <>
                    <LogIn className="mr-2 h-4 w-4" />
                    Accedi alla Dashboard
                  </>
                )}
              </Button>
            </form>
            
            {/* Divider */}
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-gray-200" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white px-4 text-gray-500 font-medium">
                  Account di Test Disponibili
                </span>
              </div>
            </div>
            
            {/* Test Account Buttons */}
            <div className="grid grid-cols-1 gap-3">
              <Button 
                variant="outline" 
                onClick={() => handleTestLogin('lucia_test_001')}
                disabled={isLoading}
                className="h-11 border-blue-200 hover:bg-blue-50 hover:border-blue-300 transition-all duration-200 group"
              >
                <div className="flex items-center justify-between w-full">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="font-medium">Test Location 001</span>
                  </div>
                  <span className="text-xs text-gray-500 group-hover:text-blue-600">
                    Accesso rapido
                  </span>
                </div>
              </Button>
              
              <Button 
                variant="outline" 
                onClick={() => handleTestLogin('lucia_test_002')}
                disabled={isLoading}
                className="h-11 border-blue-200 hover:bg-blue-50 hover:border-blue-300 transition-all duration-200 group"
              >
                <div className="flex items-center justify-between w-full">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="font-medium">Test Location 002</span>
                  </div>
                  <span className="text-xs text-gray-500 group-hover:text-blue-600">
                    Accesso rapido
                  </span>
                </div>
              </Button>
            </div>
            
            {/* Info Section */}
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-4 border border-blue-100">
              <div className="text-center space-y-2">
                <h4 className="text-sm font-semibold text-blue-900">
                  🚀 Location di Test Disponibili
                </h4>
                <div className="text-xs text-blue-700 space-y-1">
                  <div className="flex items-center justify-center gap-2">
                    <span className="font-mono bg-white px-2 py-1 rounded border">lucia_test_001</span>
                    <span>•</span>
                    <span className="font-mono bg-white px-2 py-1 rounded border">lucia_test_002</span>
                  </div>
                  <p className="text-blue-600">
                    <strong>Password:</strong> test123 (o qualsiasi password)
                  </p>
                  <p className="text-blue-500 text-xs">
                    💡 Clicca sui pulsanti sopra per accesso automatico
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-6 text-xs text-gray-500">
          <p>© 2024 LucIA KPI Platform • Powered by Supabase & React</p>
        </div>
      </div>
    </div>
  );
};

export default LoginForm;