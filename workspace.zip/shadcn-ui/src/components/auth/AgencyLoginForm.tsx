import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Eye, 
  EyeOff, 
  Users, 
  Building, 
  CheckCircle, 
  AlertCircle, 
  Loader2,
  ArrowLeft,
  Zap
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const AgencyLoginForm: React.FC = () => {
  const [agencyId, setAgencyId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationErrors, setValidationErrors] = useState<{
    agencyId?: string;
    password?: string;
  }>({});
  const { signIn, loading } = useAuth();
  const navigate = useNavigate();

  // Clear errors when user starts typing
  useEffect(() => {
    if (error) setError('');
    if (validationErrors.agencyId || validationErrors.password) {
      setValidationErrors({});
    }
  }, [agencyId, password]);

  const validateForm = () => {
    const errors: { agencyId?: string; password?: string } = {};
    
    if (!agencyId.trim()) {
      errors.agencyId = 'Agency ID è richiesto';
    } else if (agencyId.length < 3) {
      errors.agencyId = 'Agency ID deve essere di almeno 3 caratteri';
    }
    
    if (!password.trim()) {
      errors.password = 'Password è richiesta';
    } else if (password.length < 3) {
      errors.password = 'Password deve essere di almeno 3 caratteri';
    }
    
    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setError('');
    setIsSubmitting(true);

    try {
      // For now, simulate agency login with location_id fallback
      // In production, this would use a different auth method
      const result = await signIn(`agency_${agencyId.trim()}`, password);
      
      if (result.error) {
        setError(result.error);
      }
    } catch (err) {
      setError('Errore imprevisto durante il login agency');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleTestLogin = async () => {
    setError('');
    setValidationErrors({});
    setAgencyId('0-297-739');
    setIsSubmitting(true);
    
    try {
      // For test agency, use lucia_test_001 as primary location
      const result = await signIn('lucia_test_001', 'agency123');
      
      if (result.error) {
        setError(result.error);
      }
    } catch (err) {
      setError('Errore durante l\'accesso agency di test');
    } finally {
      setIsSubmitting(false);
    }
  };

  const isLoading = loading || isSubmitting;

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 via-pink-50 to-indigo-50 p-4">
      <div className="w-full max-w-md">
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={() => navigate('/')}
          className="mb-6 text-purple-600 hover:text-purple-700 hover:bg-purple-50"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Torna alla selezione
        </Button>

        {/* Header Section */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full shadow-lg mb-4">
            <Users className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Agency Login</h1>
          <p className="text-gray-600">
            Accedi con il tuo Agency ID per gestire multiple locations
          </p>
        </div>

        {/* Main Login Card */}
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader className="space-y-1 pb-6">
            <CardTitle className="text-xl font-semibold text-center text-gray-800">
              Accesso Agency
            </CardTitle>
            <p className="text-center text-sm text-gray-600">
              Gestisci performance di multiple locations
            </p>
          </CardHeader>
          
          <CardContent className="space-y-6">
            {/* Error Alert */}
            {error && (
              <Alert variant="destructive" className="border-red-200 bg-red-50">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="text-red-700">
                  {error}
                </AlertDescription>
              </Alert>
            )}
            
            {/* Login Form */}
            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Agency ID Field */}
              <div className="space-y-2">
                <Label 
                  htmlFor="agencyId" 
                  className="flex items-center gap-2 text-sm font-medium text-gray-700"
                >
                  <Building className="h-4 w-4 text-purple-600" />
                  Agency ID
                </Label>
                <div className="relative">
                  <Input
                    id="agencyId"
                    type="text"
                    placeholder="es. 0-297-739"
                    value={agencyId}
                    onChange={(e) => setAgencyId(e.target.value)}
                    disabled={isLoading}
                    className={`pl-4 pr-4 h-12 text-base transition-all duration-200 ${
                      validationErrors.agencyId 
                        ? 'border-red-300 focus:border-red-500 focus:ring-red-200' 
                        : 'border-gray-200 focus:border-purple-500 focus:ring-purple-200'
                    }`}
                    aria-describedby={validationErrors.agencyId ? 'agencyId-error' : undefined}
                  />
                  {agencyId && !validationErrors.agencyId && (
                    <CheckCircle className="absolute right-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-green-500" />
                  )}
                </div>
                {validationErrors.agencyId && (
                  <p id="agencyId-error" className="text-sm text-red-600 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" />
                    {validationErrors.agencyId}
                  </p>
                )}
              </div>
              
              {/* Password Field */}
              <div className="space-y-2">
                <Label 
                  htmlFor="password" 
                  className="text-sm font-medium text-gray-700"
                >
                  Password
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Inserisci la password agency"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    disabled={isLoading}
                    className={`pl-4 pr-12 h-12 text-base transition-all duration-200 ${
                      validationErrors.password 
                        ? 'border-red-300 focus:border-red-500 focus:ring-red-200' 
                        : 'border-gray-200 focus:border-purple-500 focus:ring-purple-200'
                    }`}
                    aria-describedby={validationErrors.password ? 'password-error' : undefined}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-1 top-1/2 transform -translate-y-1/2 h-10 w-10 hover:bg-gray-100"
                    onClick={() => setShowPassword(!showPassword)}
                    disabled={isLoading}
                    aria-label={showPassword ? 'Nascondi password' : 'Mostra password'}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 text-gray-500" />
                    ) : (
                      <Eye className="h-4 w-4 text-gray-500" />
                    )}
                  </Button>
                </div>
                {validationErrors.password && (
                  <p id="password-error" className="text-sm text-red-600 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" />
                    {validationErrors.password}
                  </p>
                )}
              </div>
              
              {/* Submit Button */}
              <Button 
                type="submit" 
                className="w-full h-12 text-base font-medium bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 transition-all duration-200 shadow-lg hover:shadow-xl"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Accesso in corso...
                  </>
                ) : (
                  <>
                    <Users className="mr-2 h-4 w-4" />
                    Accedi come Agency
                  </>
                )}
              </Button>
            </form>
            
            {/* Divider */}
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-gray-200" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white px-3 text-gray-500 font-medium">
                  Account di Test
                </span>
              </div>
            </div>
            
            {/* Test Account Button */}
            <Button 
              variant="outline" 
              className="w-full h-11 text-sm font-medium border-2 border-purple-200 text-purple-700 hover:bg-purple-50 hover:border-purple-300 transition-all duration-200"
              onClick={handleTestLogin}
              disabled={isLoading}
            >
              <Zap className="mr-2 h-4 w-4" />
              Accesso Rapido - Agency Test
            </Button>
            
            {/* Info Section */}
            <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
              <div className="text-xs text-purple-800 space-y-2">
                <p className="font-semibold flex items-center gap-2">
                  <CheckCircle className="h-3 w-3" />
                  Agency di Test Disponibile:
                </p>
                <div className="ml-5 space-y-1">
                  <p>• <span className="font-mono bg-purple-100 px-1 rounded">0-297-739</span> - Agency con accesso a multiple locations</p>
                  <p>• Password: <span className="font-mono bg-purple-100 px-1 rounded">agency123</span></p>
                </div>
                <p className="text-purple-600 font-medium mt-3">
                  💡 Usa il pulsante "Accesso Rapido" per login immediato
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-6 text-xs text-gray-500">
          <p>Agency Management • Multi-location Access</p>
        </div>
      </div>
    </div>
  );
};

export default AgencyLoginForm;