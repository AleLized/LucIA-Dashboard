import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend,
  PieChart,
  Pie,
  Cell,
  TooltipProps
} from 'recharts';
import { TrendingUp, BarChart3, PieChart as PieChartIcon, Activity } from 'lucide-react';
import { differenceInDays, differenceInMonths, format } from 'date-fns';
import { it } from 'date-fns/locale';

interface ChartDataPoint {
  date: string;
  [key: string]: string | number;
}

interface ChartMetric {
  key: string;
  label: string;
  color: string;
  format?: 'number' | 'currency' | 'percentage';
}

interface DateRange {
  from: Date;
  to: Date;
}

interface ModernKPIChartProps {
  data: ChartDataPoint[];
  title: string;
  availableMetrics: ChartMetric[];
  defaultMetrics?: string[];
  chartType?: 'line' | 'area' | 'bar' | 'pie';
  height?: number;
  showComparison?: boolean;
  dateRange?: DateRange;
}

interface CustomTooltipProps extends TooltipProps<number, string> {
  availableMetrics: ChartMetric[];
}

const CHART_COLORS = [
  '#3B82F6', // Blue
  '#10B981', // Green
  '#F59E0B', // Yellow
  '#EF4444', // Red
  '#8B5CF6', // Purple
  '#06B6D4', // Cyan
  '#F97316', // Orange
  '#84CC16', // Lime
  '#EC4899', // Pink
  '#6B7280'  // Gray
];

const ModernKPIChart: React.FC<ModernKPIChartProps> = ({
  data,
  title,
  availableMetrics,
  defaultMetrics = [],
  chartType = 'line',
  height = 400,
  showComparison = false,
  dateRange
}) => {
  const [selectedMetrics, setSelectedMetrics] = useState<string[]>(
    defaultMetrics.length > 0 ? defaultMetrics : availableMetrics.slice(0, 3).map(m => m.key)
  );
  const [currentChartType, setCurrentChartType] = useState<'line' | 'area' | 'bar' | 'pie'>(chartType);
  const [timeframe, setTimeframe] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [processedData, setProcessedData] = useState<ChartDataPoint[]>([]);

  // Determine available timeframes based on date range
  const getAvailableTimeframes = () => {
    if (!dateRange) return ['daily'];
    
    const daysDiff = differenceInDays(dateRange.to, dateRange.from) + 1;
    const monthsDiff = differenceInMonths(dateRange.to, dateRange.from);
    
    const available: string[] = [];
    
    // Daily available for ranges < 6 months
    if (monthsDiff < 6) {
      available.push('daily');
    }
    
    // Weekly available for ranges between 30 days and 6 months
    if (daysDiff > 30 && monthsDiff < 6) {
      available.push('weekly');
    }
    
    // Monthly available for ranges > 6 months OR full year ranges
    if (monthsDiff >= 6) {
      available.push('monthly');
    }
    
    // If no timeframes available, default to daily
    return available.length > 0 ? available : ['daily'];
  };

  const availableTimeframes = getAvailableTimeframes();

  // Reset timeframe if not available and set appropriate default
  useEffect(() => {
    if (!availableTimeframes.includes(timeframe)) {
      // Set appropriate default based on date range
      if (!dateRange) {
        setTimeframe('daily');
        return;
      }
      
      const monthsDiff = differenceInMonths(dateRange.to, dateRange.from);
      
      if (monthsDiff >= 6) {
        setTimeframe('monthly');
      } else {
        setTimeframe(availableTimeframes[0] as 'daily' | 'weekly' | 'monthly');
      }
    }
  }, [dateRange, availableTimeframes, timeframe]);

  // Process data based on timeframe
  useEffect(() => {
    if (!data || data.length === 0) {
      setProcessedData([]);
      return;
    }

    let processed = [...data];

    if (timeframe === 'monthly') {
      // Group data by month
      const monthlyData: { [key: string]: ChartDataPoint } = {};
      
      data.forEach(item => {
        // Try to parse the date - handle different formats
        let itemDate: Date;
        
        if (typeof item.date === 'string') {
          // Handle formats like "dic 29", "29 dic", "29/12", etc.
          const parts = item.date.toLowerCase().split(/[\s\-.]/);;
          const currentYear = new Date().getFullYear();
          
          if (parts.length >= 2) {
            // Try month name format
            const monthNames = ['gen', 'feb', 'mar', 'apr', 'mag', 'giu', 'lug', 'ago', 'set', 'ott', 'nov', 'dic'];
            const monthIndex = monthNames.findIndex(m => parts.includes(m));
            
            if (monthIndex !== -1) {
              const day = parseInt(parts.find(p => !isNaN(parseInt(p))) || '1');
              itemDate = new Date(currentYear, monthIndex, day);
            } else {
              // Try numeric format
              const [first, second] = parts.map(p => parseInt(p));
              if (!isNaN(first) && !isNaN(second)) {
                // Assume day/month format
                itemDate = new Date(currentYear, second - 1, first);
              } else {
                itemDate = new Date();
              }
            }
          } else {
            itemDate = new Date();
          }
        } else {
          itemDate = new Date();
        }
        
        const monthKey = format(itemDate, 'MMM yyyy', { locale: it });
        
        if (!monthlyData[monthKey]) {
          monthlyData[monthKey] = {
            date: monthKey,
            ...Object.keys(item).reduce((acc, key) => {
              if (key !== 'date' && typeof item[key] === 'number') {
                acc[key] = 0;
              }
              return acc;
            }, {} as Record<string, number>)
          };
        }
        
        // Sum up values for the month
        Object.keys(item).forEach(key => {
          if (key !== 'date' && typeof item[key] === 'number') {
            monthlyData[monthKey][key] = (monthlyData[monthKey][key] as number) + (item[key] as number);
          }
        });
      });
      
      processed = Object.values(monthlyData).sort((a, b) => {
        const dateA = new Date(a.date);
        const dateB = new Date(b.date);
        return dateA.getTime() - dateB.getTime();
      });
    }
    
    setProcessedData(processed);
  }, [data, timeframe]);

  const formatValue = (value: number, format?: string) => {
    switch (format) {
      case 'currency':
        return new Intl.NumberFormat('it-IT', {
          style: 'currency',
          currency: 'EUR',
          minimumFractionDigits: 0
        }).format(value);
      case 'percentage':
        return `${value.toFixed(1)}%`;
      default:
        return new Intl.NumberFormat('it-IT').format(value);
    }
  };

  const CustomTooltip: React.FC<CustomTooltipProps> = ({ active, payload, label, availableMetrics }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium text-gray-900 mb-2">{label}</p>
          {payload.map((entry, index) => {
            const metric = availableMetrics.find(m => m.key === entry.dataKey);
            return (
              <div key={index} className="flex items-center gap-2 text-sm">
                <div 
                  className="w-3 h-3 rounded-full" 
                  style={{ backgroundColor: entry.color }}
                />
                <span className="text-gray-600">{metric?.label}:</span>
                <span className="font-medium">
                  {formatValue(entry.value || 0, metric?.format)}
                </span>
              </div>
            );
          })}
        </div>
      );
    }
    return null;
  };

  const toggleMetric = (metricKey: string) => {
    setSelectedMetrics(prev => 
      prev.includes(metricKey)
        ? prev.filter(k => k !== metricKey)
        : [...prev, metricKey]
    );
  };

  const getTimeframeLabel = (tf: string) => {
    switch (tf) {
      case 'daily': return 'Giornaliero';
      case 'weekly': return 'Settimanale';
      case 'monthly': return 'Mensile';
      default: return tf;
    }
  };

  const getTimeframeDescription = () => {
    if (!dateRange) return '';
    
    const daysDiff = differenceInDays(dateRange.to, dateRange.from) + 1;
    const monthsDiff = differenceInMonths(dateRange.to, dateRange.from);
    
    switch (timeframe) {
      case 'daily':
        return `Vista giornaliera (${daysDiff} giorni)`;
      case 'weekly':
        return 'Vista settimanale (disponibile per 30 giorni - 6 mesi)';
      case 'monthly':
        return `Vista mensile (${monthsDiff} mesi)`;
      default:
        return '';
    }
  };

  const renderChart = () => {
    const chartProps = {
      data: processedData,
      height,
      margin: { top: 5, right: 30, left: 20, bottom: 5 }
    };

    switch (currentChartType) {
      case 'area': {
        return (
          <ResponsiveContainer width="100%" height={height}>
            <AreaChart {...chartProps}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis 
                dataKey="date" 
                stroke="#6B7280"
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <YAxis 
                stroke="#6B7280"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => formatValue(value)}
              />
              <Tooltip content={(props) => <CustomTooltip {...props} availableMetrics={availableMetrics} />} />
              <Legend />
              {selectedMetrics.map((metricKey, index) => {
                const metric = availableMetrics.find(m => m.key === metricKey);
                return (
                  <Area
                    key={metricKey}
                    type="monotone"
                    dataKey={metricKey}
                    stackId="1"
                    stroke={metric?.color || CHART_COLORS[index]}
                    fill={metric?.color || CHART_COLORS[index]}
                    fillOpacity={0.6}
                    name={metric?.label}
                  />
                );
              })}
            </AreaChart>
          </ResponsiveContainer>
        );
      }

      case 'bar':
        return (
          <ResponsiveContainer width="100%" height={height}>
            <BarChart {...chartProps}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis 
                dataKey="date" 
                stroke="#6B7280"
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <YAxis 
                stroke="#6B7280"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => formatValue(value)}
              />
              <Tooltip content={(props) => <CustomTooltip {...props} availableMetrics={availableMetrics} />} />
              <Legend />
              {selectedMetrics.map((metricKey, index) => {
                const metric = availableMetrics.find(m => m.key === metricKey);
                return (
                  <Bar
                    key={metricKey}
                    dataKey={metricKey}
                    fill={metric?.color || CHART_COLORS[index]}
                    name={metric?.label}
                    radius={[2, 2, 0, 0]}
                  />
                );
              })}
            </BarChart>
          </ResponsiveContainer>
        );

      case 'pie': {
        const pieData = selectedMetrics.map((metricKey, index) => {
          const metric = availableMetrics.find(m => m.key === metricKey);
          const total = processedData.reduce((sum, item) => sum + (Number(item[metricKey]) || 0), 0);
          return {
            name: metric?.label || metricKey,
            value: total,
            color: metric?.color || CHART_COLORS[index]
          };
        });

        return (
          <ResponsiveContainer width="100%" height={height}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => formatValue(Number(value))} />
            </PieChart>
          </ResponsiveContainer>
        );
      }

      default: // line
        return (
          <ResponsiveContainer width="100%" height={height}>
            <LineChart {...chartProps}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis 
                dataKey="date" 
                stroke="#6B7280"
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <YAxis 
                stroke="#6B7280"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => formatValue(value)}
              />
              <Tooltip content={(props) => <CustomTooltip {...props} availableMetrics={availableMetrics} />} />
              <Legend />
              {selectedMetrics.map((metricKey, index) => {
                const metric = availableMetrics.find(m => m.key === metricKey);
                return (
                  <Line
                    key={metricKey}
                    type="monotone"
                    dataKey={metricKey}
                    stroke={metric?.color || CHART_COLORS[index]}
                    strokeWidth={3}
                    dot={{ fill: metric?.color || CHART_COLORS[index], strokeWidth: 2, r: 4 }}
                    activeDot={{ r: 6, stroke: metric?.color || CHART_COLORS[index], strokeWidth: 2 }}
                    name={metric?.label}
                  />
                );
              })}
            </LineChart>
          </ResponsiveContainer>
        );
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            {title}
          </CardTitle>
          
          <div className="flex items-center gap-2">
            {/* Chart Type Selector */}
            <div className="flex items-center gap-1">
              <Button
                variant={currentChartType === 'line' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setCurrentChartType('line')}
              >
                <Activity className="h-4 w-4" />
              </Button>
              <Button
                variant={currentChartType === 'bar' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setCurrentChartType('bar')}
              >
                <BarChart3 className="h-4 w-4" />
              </Button>
              <Button
                variant={currentChartType === 'pie' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setCurrentChartType('pie')}
              >
                <PieChartIcon className="h-4 w-4" />
              </Button>
            </div>

            {/* Timeframe Selector */}
            <Select 
              value={timeframe} 
              onValueChange={(value: 'daily' | 'weekly' | 'monthly') => setTimeframe(value)}
            >
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {availableTimeframes.map(tf => (
                  <SelectItem key={tf} value={tf}>
                    {getTimeframeLabel(tf)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Timeframe Info */}
        <div className="text-sm text-gray-500">
          {getTimeframeDescription()}
        </div>

        {/* Metric Selector */}
        <div className="flex flex-wrap gap-2 mt-4">
          {availableMetrics.map((metric) => (
            <Badge
              key={metric.key}
              variant={selectedMetrics.includes(metric.key) ? 'default' : 'outline'}
              className="cursor-pointer hover:bg-opacity-80 transition-colors"
              style={{
                backgroundColor: selectedMetrics.includes(metric.key) ? metric.color : undefined,
                borderColor: metric.color
              }}
              onClick={() => toggleMetric(metric.key)}
            >
              {metric.label}
            </Badge>
          ))}
        </div>
      </CardHeader>

      <CardContent>
        {processedData.length > 0 ? renderChart() : (
          <div className="flex items-center justify-center h-64 text-gray-500">
            <div className="text-center">
              <p className="text-lg font-medium">Nessun dato disponibile</p>
              <p className="text-sm">per il periodo selezionato</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ModernKPIChart;