import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { DateRange } from '@/types/database';

interface SalesPerformanceData {
  sales_name: string;
  revenue: number;
  budget_allocated: number;
  demos_assigned: number;
}

interface SalesPerformanceChartProps {
  data: SalesPerformanceData[];
  dateRange: DateRange;
}

interface TooltipPayload {
  color: string;
  dataKey: string;
  name: string;
  value: number;
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: TooltipPayload[];
  label?: string;
}

const SalesPerformanceChart: React.FC<SalesPerformanceChartProps> = ({ data, dateRange }) => {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0
    }).format(value);
  };

  const formatNumber = (value: number) => {
    return new Intl.NumberFormat('it-IT').format(value);
  };

  // Custom tooltip
  const CustomTooltip: React.FC<CustomTooltipProps> = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border rounded-lg shadow-lg">
          <p className="font-medium">{`Sales: ${label}`}</p>
          {payload.map((entry, index) => (
            <p key={index} style={{ color: entry.color }}>
              {entry.dataKey === 'demos_assigned' 
                ? `${entry.name}: ${formatNumber(entry.value)}`
                : `${entry.name}: ${formatCurrency(entry.value)}`
              }
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  // Calculate max values for scaling
  const maxFinancial = Math.max(...data.map(d => Math.max(d.revenue, d.budget_allocated)));
  const maxDemos = Math.max(...data.map(d => d.demos_assigned));
  
  // Scale demos to be proportional to financial data
  const scaledData = data.map(item => ({
    ...item,
    demos_scaled: maxFinancial > 0 ? (item.demos_assigned / maxDemos) * (maxFinancial * 0.3) : 0
  }));

  return (
    <Card>
      <CardHeader>
        <CardTitle>Performance Commerciali - Sales Revenue & Budget</CardTitle>
        <p className="text-sm text-gray-600">
          Revenue, Budget Allocato e Demo Assegnate per Sales
        </p>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={400}>
          <BarChart
            data={scaledData}
            margin={{
              top: 20,
              right: 30,
              left: 20,
              bottom: 60,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              dataKey="sales_name" 
              angle={-45}
              textAnchor="end"
              height={80}
              fontSize={12}
            />
            <YAxis 
              yAxisId="financial"
              orientation="left"
              tickFormatter={formatCurrency}
              fontSize={12}
            />
            <YAxis 
              yAxisId="demos"
              orientation="right"
              tickFormatter={(value) => formatNumber((value / (maxFinancial * 0.3)) * maxDemos)}
              fontSize={12}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            <Bar 
              yAxisId="financial"
              dataKey="revenue" 
              name="Revenue" 
              fill="#10B981" 
              radius={[2, 2, 0, 0]}
            />
            <Bar 
              yAxisId="financial"
              dataKey="budget_allocated" 
              name="Budget Allocato" 
              fill="#3B82F6" 
              radius={[2, 2, 0, 0]}
            />
            <Bar 
              yAxisId="demos"
              dataKey="demos_scaled" 
              name="Demo Assegnate" 
              fill="#F59E0B" 
              radius={[2, 2, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
        
        <div className="mt-4 text-xs text-gray-500">
          <p>• Revenue e Budget Allocato: scala in Euro (asse sinistro)</p>
          <p>• Demo Assegnate: scala numerica proporzionale (asse destro)</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default SalesPerformanceChart;