import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Minus, Euro, Target, Users, Phone, Calendar, ShoppingCart } from 'lucide-react';
import { cn } from '@/lib/utils';

interface KPICardProps {
  title: string;
  value: number | string;
  previousValue?: number;
  change?: number;
  changeType?: 'percentage' | 'absolute';
  format?: 'number' | 'currency' | 'percentage';
  icon?: 'euro' | 'target' | 'users' | 'phone' | 'calendar' | 'cart' | 'trending';
  trend?: 'up' | 'down' | 'neutral';
  subtitle?: string;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

const ICONS = {
  euro: Euro,
  target: Target,
  users: Users,
  phone: Phone,
  calendar: Calendar,
  cart: ShoppingCart,
  trending: TrendingUp
};

const KPICard: React.FC<KPICardProps> = ({
  title,
  value,
  previousValue,
  change,
  changeType = 'percentage',
  format = 'number',
  icon = 'target',
  trend,
  subtitle,
  className,
  size = 'md'
}) => {
  const Icon = ICONS[icon];

  const formatValue = (val: number | string) => {
    if (typeof val === 'string') return val;
    
    switch (format) {
      case 'currency':
        return new Intl.NumberFormat('it-IT', {
          style: 'currency',
          currency: 'EUR',
          minimumFractionDigits: val < 100 ? 2 : 0
        }).format(val);
      case 'percentage':
        return `${val.toFixed(1)}%`;
      default:
        return new Intl.NumberFormat('it-IT').format(val);
    }
  };

  const getTrendColor = () => {
    if (!change) return 'text-gray-500';
    
    if (trend) {
      switch (trend) {
        case 'up': return 'text-green-600';
        case 'down': return 'text-red-600';
        default: return 'text-gray-500';
      }
    }
    
    return change > 0 ? 'text-green-600' : change < 0 ? 'text-red-600' : 'text-gray-500';
  };

  const getTrendIcon = () => {
    if (!change) return Minus;
    
    if (trend) {
      switch (trend) {
        case 'up': return TrendingUp;
        case 'down': return TrendingDown;
        default: return Minus;
      }
    }
    
    return change > 0 ? TrendingUp : change < 0 ? TrendingDown : Minus;
  };

  const TrendIcon = getTrendIcon();

  const sizeClasses = {
    sm: 'p-3',
    md: 'p-4',
    lg: 'p-6'
  };

  const titleSizes = {
    sm: 'text-sm',
    md: 'text-base',
    lg: 'text-lg'
  };

  const valueSizes = {
    sm: 'text-lg',
    md: 'text-2xl',
    lg: 'text-3xl'
  };

  return (
    <Card className={cn('hover:shadow-md transition-shadow', className)}>
      <CardContent className={sizeClasses[size]}>
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Icon className="h-4 w-4 text-gray-500" />
              <h3 className={cn('font-medium text-gray-700', titleSizes[size])}>
                {title}
              </h3>
            </div>
            
            <div className={cn('font-bold text-gray-900', valueSizes[size])}>
              {formatValue(value)}
            </div>
            
            {subtitle && (
              <p className="text-xs text-gray-500 mt-1">{subtitle}</p>
            )}
          </div>

          {/* Trend Indicator */}
          {change !== undefined && (
            <div className="flex flex-col items-end">
              <div className={cn('flex items-center gap-1 text-sm font-medium', getTrendColor())}>
                <TrendIcon className="h-3 w-3" />
                <span>
                  {changeType === 'percentage' ? `${Math.abs(change).toFixed(1)}%` : formatValue(Math.abs(change))}
                </span>
              </div>
              {previousValue && (
                <div className="text-xs text-gray-400 mt-1">
                  vs {formatValue(previousValue)}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Progress Bar (optional) */}
        {previousValue && typeof value === 'number' && (
          <div className="mt-3">
            <div className="w-full bg-gray-200 rounded-full h-1.5">
              <div 
                className={cn(
                  'h-1.5 rounded-full transition-all duration-300',
                  change && change > 0 ? 'bg-green-500' : change && change < 0 ? 'bg-red-500' : 'bg-gray-400'
                )}
                style={{ 
                  width: `${Math.min(100, Math.max(0, (value / (previousValue * 1.5)) * 100))}%` 
                }}
              />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default KPICard;