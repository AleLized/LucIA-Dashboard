import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Settings, Save } from 'lucide-react';
import { AVAILABLE_KPIS } from '@/types/database';

interface KPIConfigModalProps {
  selectedKPIs: string[];
  onKPIChange: (kpis: string[]) => void;
  source: 'ads' | 'organic' | 'outbound' | 'sales' | 'vendite' | 'prodotti';
}

const KPIConfigModal: React.FC<KPIConfigModalProps> = ({
  selectedKPIs,
  onKPIChange,
  source
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [tempSelectedKPIs, setTempSelectedKPIs] = useState<string[]>(selectedKPIs);

  useEffect(() => {
    setTempSelectedKPIs(selectedKPIs);
  }, [selectedKPIs]);

  const handleKPIToggle = (kpiKey: string) => {
    setTempSelectedKPIs(prev => 
      prev.includes(kpiKey)
        ? prev.filter(k => k !== kpiKey)
        : [...prev, kpiKey]
    );
  };

  const handleSave = () => {
    onKPIChange(tempSelectedKPIs);
    setIsOpen(false);
    
    // Save to localStorage for persistence
    localStorage.setItem(`kpi_config_${source}`, JSON.stringify(tempSelectedKPIs));
  };

  const handleCancel = () => {
    setTempSelectedKPIs(selectedKPIs);
    setIsOpen(false);
  };

  const handleSelectAll = () => {
    setTempSelectedKPIs(AVAILABLE_KPIS.map(kpi => kpi.key));
  };

  const handleDeselectAll = () => {
    setTempSelectedKPIs([]);
  };

  // Load saved config on mount
  useEffect(() => {
    const savedConfig = localStorage.getItem(`kpi_config_${source}`);
    if (savedConfig) {
      try {
        const parsedConfig = JSON.parse(savedConfig);
        onKPIChange(parsedConfig);
      } catch (error) {
        console.error('Error loading saved KPI config:', error);
      }
    }
  }, [source, onKPIChange]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="h-5 w-5" />
          Configurazione KPI
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <p className="text-sm text-gray-600">
            KPI selezionati: {selectedKPIs.length}/{AVAILABLE_KPIS.length}
          </p>
          
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full">
                <Settings className="h-4 w-4 mr-2" />
                Configura KPI da Mostrare
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px] max-h-[600px] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  Configurazione KPI - {source.toUpperCase()}
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-4">
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleSelectAll}
                  >
                    Seleziona Tutti
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleDeselectAll}
                  >
                    Deseleziona Tutti
                  </Button>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {AVAILABLE_KPIS.map((kpi) => (
                    <div key={kpi.key} className="flex items-center space-x-2">
                      <Checkbox
                        id={kpi.key}
                        checked={tempSelectedKPIs.includes(kpi.key)}
                        onCheckedChange={() => handleKPIToggle(kpi.key)}
                      />
                      <Label 
                        htmlFor={kpi.key} 
                        className="text-sm cursor-pointer flex-1"
                      >
                        {kpi.label}
                        <span className="text-xs text-gray-500 block">
                          {kpi.format === 'currency' ? '€' : 
                           kpi.format === 'percentage' ? '%' : '#'}
                        </span>
                      </Label>
                    </div>
                  ))}
                </div>

                <div className="flex justify-end gap-2 pt-4 border-t">
                  <Button variant="outline" onClick={handleCancel}>
                    Annulla
                  </Button>
                  <Button onClick={handleSave}>
                    <Save className="h-4 w-4 mr-2" />
                    Salva Configurazione
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <div className="text-xs text-gray-500">
            Personalizza quali KPI visualizzare nelle tabelle e nei grafici
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default KPIConfigModal;