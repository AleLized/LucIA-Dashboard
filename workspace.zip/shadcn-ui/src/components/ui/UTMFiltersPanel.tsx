import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Filter, RotateCcw } from 'lucide-react';
import { Sales } from '@/types/database';

interface UTMFiltersPanelProps {
  selectedSource: string;
  selectedSales: string;
  onSourceChange: (source: string) => void;
  onSalesChange: (sales: string) => void;
  onReset: () => void;
  salesOptions: Sales[];
}

const UTMFiltersPanel: React.FC<UTMFiltersPanelProps> = ({
  selectedSource,
  selectedSales,
  onSourceChange,
  onSalesChange,
  onReset,
  salesOptions
}) => {
  const activeFiltersCount = [
    selectedSource !== 'all',
    selectedSales !== 'all'
  ].filter(Boolean).length;

  const trafficSources = [
    { value: 'all', label: 'Tutte le Fonti' },
    { value: 'ads', label: 'ADS' },
    { value: 'organic', label: 'Organico' },
    { value: 'outbound', label: 'Outbound' }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filtri Avanzati
            {activeFiltersCount > 0 && (
              <Badge variant="secondary" className="ml-2">
                {activeFiltersCount} attivi
              </Badge>
            )}
          </div>
          {activeFiltersCount > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={onReset}
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset
            </Button>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Traffic Source Filter */}
          <div>
            <label className="text-sm font-medium text-gray-700 mb-2 block">
              Fonte di Traffico
            </label>
            <Select value={selectedSource} onValueChange={onSourceChange}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {trafficSources.map((source) => (
                  <SelectItem key={source.value} value={source.value}>
                    {source.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Sales Filter */}
          <div>
            <label className="text-sm font-medium text-gray-700 mb-2 block">
              Sales
            </label>
            <Select value={selectedSales} onValueChange={onSalesChange}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tutti i Sales</SelectItem>
                {salesOptions.map((sales) => (
                  <SelectItem key={sales.id} value={sales.id}>
                    {sales.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Active Filters Summary */}
          {activeFiltersCount > 0 && (
            <div className="pt-3 border-t">
              <div className="text-sm text-gray-600 mb-2">Filtri attivi:</div>
              <div className="flex flex-wrap gap-2">
                {selectedSource !== 'all' && (
                  <Badge variant="outline">
                    Fonte: {trafficSources.find(s => s.value === selectedSource)?.label}
                  </Badge>
                )}
                {selectedSales !== 'all' && (
                  <Badge variant="outline">
                    Sales: {salesOptions.find(s => s.id === selectedSales)?.name || 'Sconosciuto'}
                  </Badge>
                )}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default UTMFiltersPanel;