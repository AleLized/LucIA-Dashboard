import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon, ChevronDown } from 'lucide-react';
import { format, subDays, startOfMonth, endOfMonth, startOfYear, endOfYear } from 'date-fns';
import { it } from 'date-fns/locale';
import { cn } from '@/lib/utils';

interface DateRange {
  from: Date;
  to: Date;
}

interface MetaAdsDatePickerProps {
  dateRange: DateRange;
  onDateRangeChange: (range: DateRange) => void;
  className?: string;
}

const MetaAdsDatePicker: React.FC<MetaAdsDatePickerProps> = ({
  dateRange,
  onDateRangeChange,
  className
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [tempRange, setTempRange] = useState<DateRange>(dateRange);

  const presetRanges = [
    {
      label: 'Oggi',
      getValue: () => ({
        from: new Date(),
        to: new Date()
      })
    },
    {
      label: 'Ieri',
      getValue: () => ({
        from: subDays(new Date(), 1),
        to: subDays(new Date(), 1)
      })
    },
    {
      label: 'Ultimi 7 giorni',
      getValue: () => ({
        from: subDays(new Date(), 6),
        to: new Date()
      })
    },
    {
      label: 'Ultimi 14 giorni',
      getValue: () => ({
        from: subDays(new Date(), 13),
        to: new Date()
      })
    },
    {
      label: 'Ultimi 30 giorni',
      getValue: () => ({
        from: subDays(new Date(), 29),
        to: new Date()
      })
    },
    {
      label: 'Questo mese',
      getValue: () => ({
        from: startOfMonth(new Date()),
        to: endOfMonth(new Date())
      })
    },
    {
      label: 'Mese scorso',
      getValue: () => {
        const lastMonth = subDays(startOfMonth(new Date()), 1);
        return {
          from: startOfMonth(lastMonth),
          to: endOfMonth(lastMonth)
        };
      }
    },
    {
      label: 'Ultimi 3 mesi',
      getValue: () => ({
        from: subDays(new Date(), 89),
        to: new Date()
      })
    },
    {
      label: 'Quest\'anno',
      getValue: () => ({
        from: startOfYear(new Date()),
        to: endOfYear(new Date())
      })
    }
  ];

  const handlePresetClick = (preset: typeof presetRanges[0]) => {
    const newRange = preset.getValue();
    setTempRange(newRange);
    onDateRangeChange(newRange);
    setIsOpen(false);
  };

  const handleApply = () => {
    onDateRangeChange(tempRange);
    setIsOpen(false);
  };

  const handleCancel = () => {
    setTempRange(dateRange);
    setIsOpen(false);
  };

  const formatDateRange = (range: DateRange) => {
    if (format(range.from, 'yyyy-MM-dd') === format(range.to, 'yyyy-MM-dd')) {
      return format(range.from, 'dd MMM yyyy', { locale: it });
    }
    return `${format(range.from, 'dd MMM', { locale: it })} - ${format(range.to, 'dd MMM yyyy', { locale: it })}`;
  };

  return (
    <Card className={cn("w-full", className)}>
      <CardContent className="p-4">
        <div className="flex items-center gap-2">
          <CalendarIcon className="h-4 w-4 text-gray-500" />
          <span className="text-sm font-medium text-gray-700">Periodo:</span>
          
          <Popover open={isOpen} onOpenChange={setIsOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className="justify-between min-w-[200px] bg-white hover:bg-gray-50"
              >
                <span className="text-sm">{formatDateRange(dateRange)}</span>
                <ChevronDown className="h-4 w-4 opacity-50" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <div className="flex">
                {/* Preset Ranges */}
                <div className="w-48 border-r border-gray-200 p-3">
                  <div className="space-y-1">
                    {presetRanges.map((preset, index) => (
                      <Button
                        key={index}
                        variant="ghost"
                        size="sm"
                        className="w-full justify-start text-sm hover:bg-blue-50 hover:text-blue-600"
                        onClick={() => handlePresetClick(preset)}
                      >
                        {preset.label}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Calendar */}
                <div className="p-3">
                  <div className="flex gap-4">
                    <div>
                      <div className="text-sm font-medium mb-2 text-gray-700">Da</div>
                      <Calendar
                        mode="single"
                        selected={tempRange.from}
                        onSelect={(date) => date && setTempRange(prev => ({ ...prev, from: date }))}
                        initialFocus
                        locale={it}
                        className="rounded-md border"
                      />
                    </div>
                    <div>
                      <div className="text-sm font-medium mb-2 text-gray-700">A</div>
                      <Calendar
                        mode="single"
                        selected={tempRange.to}
                        onSelect={(date) => date && setTempRange(prev => ({ ...prev, to: date }))}
                        locale={it}
                        className="rounded-md border"
                      />
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex justify-end gap-2 mt-4 pt-3 border-t border-gray-200">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleCancel}
                    >
                      Annulla
                    </Button>
                    <Button
                      size="sm"
                      onClick={handleApply}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      Applica
                    </Button>
                  </div>
                </div>
              </div>
            </PopoverContent>
          </Popover>
        </div>
      </CardContent>
    </Card>
  );
};

export default MetaAdsDatePicker;