import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { CalendarDays, ChevronLeft, ChevronRight } from 'lucide-react';
import { format, addMonths, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, isToday, subDays, startOfWeek, endOfWeek, startOfYear, endOfYear } from 'date-fns';
import { it } from 'date-fns/locale';
import { DateRange } from '@/types/database';

interface CustomDatePickerProps {
  dateRange: DateRange;
  onDateRangeChange: (range: DateRange) => void;
}

interface DatePreset {
  label: string;
  value: string;
  range: DateRange;
}

interface PopupPosition {
  left: number | 'auto';
  right: number | 'auto';
}

const CustomDatePicker: React.FC<CustomDatePickerProps> = ({ dateRange, onDateRangeChange }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedPreset, setSelectedPreset] = useState<string>('');
  const [tempRange, setTempRange] = useState<DateRange>(dateRange);
  const [popupPosition, setPopupPosition] = useState<PopupPosition>({ left: 0, right: 'auto' });
  const buttonRef = useRef<HTMLButtonElement>(null);

  const currentYear = new Date().getFullYear();
  
  const presets: DatePreset[] = [
    { label: 'Today', value: 'today', range: { from: new Date(), to: new Date() } },
    { label: 'Yesterday', value: 'yesterday', range: { from: subDays(new Date(), 1), to: subDays(new Date(), 1) } },
    { label: 'Last 7 days', value: 'last7', range: { from: subDays(new Date(), 6), to: new Date() } },
    { label: 'Last 14 days', value: 'last14', range: { from: subDays(new Date(), 13), to: new Date() } },
    { label: 'Last 28 days', value: 'last28', range: { from: subDays(new Date(), 27), to: new Date() } },
    { label: 'Last 30 days', value: 'last30', range: { from: subDays(new Date(), 29), to: new Date() } },
    { label: 'This week', value: 'thisweek', range: { from: startOfWeek(new Date(), { weekStartsOn: 1 }), to: endOfWeek(new Date(), { weekStartsOn: 1 }) } },
    { label: 'Last week', value: 'lastweek', range: { from: startOfWeek(subDays(new Date(), 7), { weekStartsOn: 1 }), to: endOfWeek(subDays(new Date(), 7), { weekStartsOn: 1 }) } },
    { label: 'This month', value: 'thismonth', range: { from: startOfMonth(new Date()), to: endOfMonth(new Date()) } },
    { label: 'Last month', value: 'lastmonth', range: { from: startOfMonth(subMonths(new Date(), 1)), to: endOfMonth(subMonths(new Date(), 1)) } },
    { label: 'Quarter 1', value: 'q1', range: { from: new Date(currentYear, 0, 1), to: new Date(currentYear, 2, 31) } },
    { label: 'Quarter 2', value: 'q2', range: { from: new Date(currentYear, 3, 1), to: new Date(currentYear, 5, 30) } },
    { label: 'Quarter 3', value: 'q3', range: { from: new Date(currentYear, 6, 1), to: new Date(currentYear, 8, 30) } },
    { label: 'Quarter 4', value: 'q4', range: { from: new Date(currentYear, 9, 1), to: new Date(currentYear, 11, 31) } },
    { label: 'Quest\'anno', value: 'thisyear', range: { from: startOfYear(new Date()), to: endOfYear(new Date()) } },
    { label: 'Scorso anno', value: 'lastyear', range: { from: startOfYear(new Date(currentYear - 1, 0, 1)), to: endOfYear(new Date(currentYear - 1, 11, 31)) } },
  ];

  useEffect(() => {
    const calculatePosition = () => {
      if (buttonRef.current && isOpen) {
        const buttonRect = buttonRef.current.getBoundingClientRect();
        const windowWidth = window.innerWidth;
        const popupWidth = 800; // Width of the popup
        
        // Check if popup would go off-screen on the right
        if (buttonRect.left + popupWidth > windowWidth) {
          // Position popup to the right edge of the screen with some margin
          setPopupPosition({ 
            left: 'auto', 
            right: 20 
          });
        } else {
          // Normal left positioning
          setPopupPosition({ 
            left: 0, 
            right: 'auto' 
          });
        }
      }
    };

    calculatePosition();
    window.addEventListener('resize', calculatePosition);
    return () => window.removeEventListener('resize', calculatePosition);
  }, [isOpen]);

  const handlePresetClick = (preset: DatePreset) => {
    setSelectedPreset(preset.value);
    setTempRange(preset.range);
  };

  const handleDateClick = (date: Date) => {
    if (!tempRange.from || (tempRange.from && tempRange.to)) {
      setTempRange({ from: date, to: date });
    } else if (tempRange.from && !tempRange.to) {
      if (date < tempRange.from) {
        setTempRange({ from: date, to: tempRange.from });
      } else {
        setTempRange({ from: tempRange.from, to: date });
      }
    }
    setSelectedPreset('custom');
  };

  const handleUpdate = () => {
    onDateRangeChange(tempRange);
    setIsOpen(false);
  };

  const handleCancel = () => {
    setTempRange(dateRange);
    setIsOpen(false);
  };

  const renderCalendar = (month: Date) => {
    const monthStart = startOfMonth(month);
    const monthEnd = endOfMonth(month);
    const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

    return (
      <div className="grid grid-cols-7 gap-1">
        {days.map((day) => {
          const isSelected = tempRange.from && tempRange.to && 
            day >= tempRange.from && day <= tempRange.to;
          const isRangeStart = tempRange.from && isSameDay(day, tempRange.from);
          const isRangeEnd = tempRange.to && isSameDay(day, tempRange.to);
          const isInRange = tempRange.from && tempRange.to && 
            day > tempRange.from && day < tempRange.to;

          return (
            <button
              key={day.toISOString()}
              onClick={() => handleDateClick(day)}
              className={`
                h-8 w-8 text-sm rounded-md hover:bg-blue-100 transition-colors
                ${isToday(day) ? 'bg-blue-500 text-white' : ''}
                ${isRangeStart || isRangeEnd ? 'bg-blue-500 text-white' : ''}
                ${isInRange ? 'bg-blue-100' : ''}
                ${!isSameMonth(day, month) ? 'text-gray-300' : 'text-gray-900'}
              `}
            >
              {format(day, 'd')}
            </button>
          );
        })}
      </div>
    );
  };

  return (
    <div className="relative">
      <Button
        ref={buttonRef}
        variant="outline"
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 min-w-[200px] justify-start"
      >
        <CalendarDays className="h-4 w-4" />
        {format(dateRange.from, 'MMM d, yyyy', { locale: it })} - {format(dateRange.to, 'MMM d, yyyy', { locale: it })}
      </Button>

      {isOpen && (
        <div 
          className="absolute top-full mt-2 z-50"
          style={{
            left: popupPosition.left,
            right: popupPosition.right
          }}
        >
          <Card className="w-[800px] shadow-lg">
            <CardContent className="p-4">
              <div className="flex gap-4">
                {/* Presets */}
                <div className="w-48 border-r pr-4">
                  <h3 className="font-medium mb-3 text-sm">Recently used</h3>
                  <div className="space-y-1 max-h-80 overflow-y-auto">
                    {presets.map((preset) => (
                      <button
                        key={preset.value}
                        onClick={() => handlePresetClick(preset)}
                        className={`
                          w-full text-left px-2 py-1.5 text-sm rounded hover:bg-gray-100 transition-colors
                          ${selectedPreset === preset.value ? 'bg-blue-50 text-blue-600' : 'text-gray-700'}
                        `}
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Calendar */}
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-4">
                    <button
                      onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
                      className="p-1 hover:bg-gray-100 rounded"
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </button>
                    <div className="flex gap-8">
                      <h3 className="font-medium">
                        {format(currentMonth, 'MMM yyyy', { locale: it })}
                      </h3>
                      <h3 className="font-medium">
                        {format(addMonths(currentMonth, 1), 'MMM yyyy', { locale: it })}
                      </h3>
                    </div>
                    <button
                      onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
                      className="p-1 hover:bg-gray-100 rounded"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-8">
                    {renderCalendar(currentMonth)}
                    {renderCalendar(addMonths(currentMonth, 1))}
                  </div>

                  <div className="flex items-center justify-between mt-4 pt-4 border-t">
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="compare"
                        className="rounded"
                      />
                      <label htmlFor="compare" className="text-sm text-gray-600">
                        Compare
                      </label>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" onClick={handleCancel}>
                        Cancel
                      </Button>
                      <Button onClick={handleUpdate}>
                        Update
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default CustomDatePicker;