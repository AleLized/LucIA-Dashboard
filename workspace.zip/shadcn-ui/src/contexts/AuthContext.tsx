import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { verifyLocationCredentials, createTestAccountsIfMissing } from '@/lib/supabase';

export interface UserProfile {
  id: string;
  location_id: string;
  role: 'location_admin' | 'agency_admin' | 'sales';
  name: string;
  email?: string;
  agency_id?: string;
  isAuthenticated: boolean;
}

interface AuthContextType {
  userProfile: UserProfile | null;
  loading: boolean;
  signIn: (locationId: string, password: string) => Promise<{ error?: string }>;
  signOut: () => void;
  getCurrentLocationId: () => string | null;
  hasAccessToLocation: (locationId: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Ripristina profilo utente da localStorage
    const savedProfile = localStorage.getItem('lucia_user_profile');
    if (savedProfile) {
      try {
        const profile = JSON.parse(savedProfile);
        setUserProfile(profile);
        console.log('🔄 [AUTH] Restored user profile:', profile.location_id);
      } catch (error) {
        console.error('❌ [AUTH] Error parsing saved profile:', error);
        localStorage.removeItem('lucia_user_profile');
      }
    }

    // Inizializza account di test per prevenire PGRST116
    createTestAccountsIfMissing().catch(console.error);
  }, []);

  const signIn = async (locationId: string, password: string) => {
    try {
      setLoading(true);
      console.log('🔐 [AUTH] Starting PGRST116-safe login for location:', locationId);

      // Validazione input
      if (!locationId || !password) {
        return { error: 'Location ID e password sono obbligatori' };
      }

      if (password.length < 3) {
        return { error: 'Password deve essere di almeno 3 caratteri' };
      }

      // Usa la funzione di verifica robusta che evita PGRST116
      console.log('🔍 [AUTH] Using PGRST116-resistant authentication...');
      const verificationResult = await verifyLocationCredentials(locationId.trim(), password);
      
      if (!verificationResult.success) {
        console.error('❌ [AUTH] Authentication failed:', verificationResult.error);
        return { error: verificationResult.error || 'Credenziali non valide' };
      }

      console.log('✅ [AUTH] Authentication successful with PGRST116 protection!');
      
      // Crea profilo utente autenticato
      const profile: UserProfile = {
        id: verificationResult.location!.id,
        location_id: verificationResult.location!.location_id,
        role: 'location_admin',
        name: verificationResult.location!.name,
        isAuthenticated: true
      };

      setUserProfile(profile);
      localStorage.setItem('lucia_user_profile', JSON.stringify(profile));
      
      console.log('✅ [AUTH] Login successful - PGRST116 error avoided');
      return {};

    } catch (error) {
      console.error('❌ [AUTH] Login error:', error);
      return { error: 'Errore durante il login. Riprova.' };
    } finally {
      setLoading(false);
    }
  };

  const signOut = () => {
    setUserProfile(null);
    localStorage.removeItem('lucia_user_profile');
    console.log('🚪 [AUTH] User signed out');
  };

  const getCurrentLocationId = () => {
    return userProfile?.location_id || null;
  };

  const hasAccessToLocation = (locationId: string) => {
    if (!userProfile) return false;
    
    // Agency admin può accedere a più location
    if (userProfile.role === 'agency_admin') {
      return true;
    }
    
    // Location admin può accedere solo alla propria location
    return userProfile.location_id === locationId;
  };

  const value: AuthContextType = {
    userProfile,
    loading,
    signIn,
    signOut,
    getCurrentLocationId,
    hasAccessToLocation
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};