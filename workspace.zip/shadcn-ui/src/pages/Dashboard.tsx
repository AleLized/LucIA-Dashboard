import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import Header from '@/components/layout/Header';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Users, 
  Package, 
  BarChart3,
  AlertCircle,
  CheckCircle,
  Loader2,
  Calendar,
  MapPin
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';

interface DailyKPI {
  id: string;
  location_id: string;
  date: string;
  revenue: number;
  transactions: number;
  avg_transaction_value: number;
  customer_count: number;
  created_at: string;
}

interface Sale {
  id: string;
  location_id: string;
  product_name: string;
  quantity: number;
  unit_price: number;
  total_amount: number;
  created_at: string;
  created_at: string;
}

const Dashboard: React.FC = () => {
  const { userProfile, getCurrentLocationId } = useAuth();
  const [kpiData, setKpiData] = useState<DailyKPI[]>([]);
  const [salesData, setSalesData] = useState<Sale[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const currentLocationId = getCurrentLocationId();

  useEffect(() => {
    if (currentLocationId) {
      fetchDashboardData();
    }
  }, [currentLocationId]);

  const fetchDashboardData = async () => {
    if (!currentLocationId) {
      setError('Location ID non disponibile');
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      console.log('📊 Fetching dashboard data for location:', currentLocationId);

      // Fetch KPI data with detailed logging
      console.log('🔍 Querying daily_kpis table...');
      const { data: kpiResult, error: kpiError } = await supabase
        .from('daily_kpis')
        .select('*')
        .eq('location_id', currentLocationId)
        .order('date', { ascending: false })
        .limit(30);

      console.log('📊 KPI query result:', JSON.stringify(kpiResult, null, 2));
      console.log('📊 KPI query error:', JSON.stringify(kpiError, null, 2));

      if (kpiError) {
        console.error('❌ Error fetching KPI data:', kpiError);
        throw new Error(`Errore KPI: ${kpiError.message}`);
      }

      // Fetch sales data with detailed logging
      console.log('🔍 Querying sales table...');
      const { data: salesResult, error: salesError } = await supabase
        .from('sales')
        .select('*')
        .eq('location_id', currentLocationId)
        .order('created_at', { ascending: false })
        .limit(100);

      console.log('💰 Sales query result:', JSON.stringify(salesResult, null, 2));
      console.log('💰 Sales query error:', JSON.stringify(salesError, null, 2));

      if (salesError) {
        console.error('❌ Error fetching sales data:', salesError);
        throw new Error(`Errore Sales: ${salesError.message}`);
      }

      // Set data only if we have real data from database
      if (kpiResult && kpiResult.length > 0) {
        setKpiData(kpiResult);
        console.log('✅ KPI data loaded:', kpiResult.length, 'records');
      } else {
        console.warn('⚠️ No KPI data found for location:', currentLocationId);
        setKpiData([]);
      }

      if (salesResult && salesResult.length > 0) {
        setSalesData(salesResult);
        console.log('✅ Sales data loaded:', salesResult.length, 'records');
      } else {
        console.warn('⚠️ No sales data found for location:', currentLocationId);
        setSalesData([]);
      }

      // Show error if no data at all
      if ((!kpiResult || kpiResult.length === 0) && (!salesResult || salesResult.length === 0)) {
        setError(`Nessun dato trovato nel database per location: ${currentLocationId}`);
      }

    } catch (err) {
      console.error('❌ Dashboard data fetch error:', err);
      setError(err instanceof Error ? err.message : 'Errore durante il caricamento dei dati');
    } finally {
      setLoading(false);
    }
  };

  // Calculate metrics from REAL data only
  const calculateMetrics = () => {
    if (!kpiData || kpiData.length === 0) {
      return {
        totalRevenue: 0,
        totalTransactions: 0,
        avgTransactionValue: 0,
        totalCustomers: 0,
        revenueChange: 0,
        transactionChange: 0
      };
    }

    const totalRevenue = kpiData.reduce((sum, item) => sum + (item.revenue || 0), 0);
    const totalTransactions = kpiData.reduce((sum, item) => sum + (item.transactions || 0), 0);
    const totalCustomers = kpiData.reduce((sum, item) => sum + (item.customer_count || 0), 0);
    const avgTransactionValue = totalTransactions > 0 ? totalRevenue / totalTransactions : 0;

    // Calculate changes (comparing first half vs second half of data)
    const midPoint = Math.floor(kpiData.length / 2);
    const recentData = kpiData.slice(0, midPoint);
    const olderData = kpiData.slice(midPoint);

    const recentRevenue = recentData.reduce((sum, item) => sum + (item.revenue || 0), 0);
    const olderRevenue = olderData.reduce((sum, item) => sum + (item.revenue || 0), 0);
    const recentTransactions = recentData.reduce((sum, item) => sum + (item.transactions || 0), 0);
    const olderTransactions = olderData.reduce((sum, item) => sum + (item.transactions || 0), 0);

    const revenueChange = olderRevenue > 0 ? ((recentRevenue - olderRevenue) / olderRevenue) * 100 : 0;
    const transactionChange = olderTransactions > 0 ? ((recentTransactions - olderTransactions) / olderTransactions) * 100 : 0;

    return {
      totalRevenue,
      totalTransactions,
      avgTransactionValue,
      totalCustomers,
      revenueChange,
      transactionChange
    };
  };

  const metrics = calculateMetrics();

  // Prepare chart data from REAL data only
  const chartData = kpiData.slice(0, 7).reverse().map(item => ({
    date: new Date(item.date).toLocaleDateString('it-IT', { month: 'short', day: 'numeric' }),
    revenue: item.revenue || 0,
    transactions: item.transactions || 0,
    customers: item.customer_count || 0
  }));

  // Top products from REAL sales data only
  const getTopProducts = () => {
    if (!salesData || salesData.length === 0) return [];

    const productSales = salesData.reduce((acc, sale) => {
      const product = sale.product_name || 'Prodotto Sconosciuto';
      if (!acc[product]) {
        acc[product] = { name: product, quantity: 0, revenue: 0 };
      }
      acc[product].quantity += sale.quantity || 0;
      acc[product].revenue += sale.total_amount || 0;
      return acc;
    }, {} as Record<string, { name: string; quantity: number; revenue: number }>);

    return Object.values(productSales)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);
  };

  const topProducts = getTopProducts();

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="flex items-center justify-center h-96">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-600" />
            <p className="text-gray-600">Caricamento dati dashboard...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      
      <div className="container mx-auto px-4 py-8">
        {/* Location Info */}
        <div className="mb-8">
          <div className="flex items-center gap-2 text-gray-600 mb-2">
            <MapPin className="h-4 w-4" />
            <span className="text-sm">Location ID: {currentLocationId}</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard Performance</h1>
          <p className="text-gray-600 mt-2">
            Panoramica delle performance per {userProfile?.name || 'la tua location'}
          </p>
        </div>

        {/* Error Alert */}
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Data Status Info */}
        <div className="mb-6">
          <Alert className={kpiData.length > 0 || salesData.length > 0 ? "border-green-200 bg-green-50" : "border-yellow-200 bg-yellow-50"}>
            <CheckCircle className={`h-4 w-4 ${kpiData.length > 0 || salesData.length > 0 ? "text-green-600" : "text-yellow-600"}`} />
            <AlertDescription className={kpiData.length > 0 || salesData.length > 0 ? "text-green-800" : "text-yellow-800"}>
              {kpiData.length > 0 || salesData.length > 0 
                ? `✅ Dati caricati dal database: ${kpiData.length} record KPI, ${salesData.length} vendite`
                : `⚠️ Nessun dato trovato nel database per location: ${currentLocationId}`
              }
            </AlertDescription>
          </Alert>
        </div>

        {/* KPI Cards - Show only if we have real data */}
        {(kpiData.length > 0 || salesData.length > 0) && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Fatturato Totale</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">€{metrics.totalRevenue.toLocaleString('it-IT')}</div>
                  <p className="text-xs text-muted-foreground flex items-center">
                    {metrics.revenueChange >= 0 ? (
                      <TrendingUp className="h-3 w-3 mr-1 text-green-500" />
                    ) : (
                      <TrendingDown className="h-3 w-3 mr-1 text-red-500" />
                    )}
                    {Math.abs(metrics.revenueChange).toFixed(1)}% dal periodo precedente
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Transazioni</CardTitle>
                  <BarChart3 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{metrics.totalTransactions.toLocaleString('it-IT')}</div>
                  <p className="text-xs text-muted-foreground flex items-center">
                    {metrics.transactionChange >= 0 ? (
                      <TrendingUp className="h-3 w-3 mr-1 text-green-500" />
                    ) : (
                      <TrendingDown className="h-3 w-3 mr-1 text-red-500" />
                    )}
                    {Math.abs(metrics.transactionChange).toFixed(1)}% dal periodo precedente
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Valore Medio Transazione</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">€{metrics.avgTransactionValue.toFixed(2)}</div>
                  <p className="text-xs text-muted-foreground">
                    Calcolato su {metrics.totalTransactions} transazioni
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Clienti Totali</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{metrics.totalCustomers.toLocaleString('it-IT')}</div>
                  <p className="text-xs text-muted-foreground">
                    Ultimi {kpiData.length} giorni
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Charts - Show only if we have chart data */}
            {chartData.length > 0 && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                <Card>
                  <CardHeader>
                    <CardTitle>Trend Fatturato (Ultimi 7 giorni)</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" />
                        <YAxis />
                        <Tooltip formatter={(value) => [`€${Number(value).toLocaleString('it-IT')}`, 'Fatturato']} />
                        <Legend />
                        <Line type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Transazioni e Clienti</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="transactions" fill="#10b981" />
                        <Bar dataKey="customers" fill="#f59e0b" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Top Products - Show only if we have sales data */}
            {topProducts.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Package className="h-5 w-5" />
                    Top Prodotti per Fatturato
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {topProducts.map((product, index) => (
                      <div key={product.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-semibold">
                            {index + 1}
                          </div>
                          <div>
                            <p className="font-medium">{product.name}</p>
                            <p className="text-sm text-gray-600">{product.quantity} unità vendute</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">€{product.revenue.toLocaleString('it-IT')}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </>
        )}

        {/* No Data State */}
        {kpiData.length === 0 && salesData.length === 0 && !loading && (
          <div className="text-center py-12">
            <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Nessun dato disponibile</h3>
            <p className="text-gray-600 mb-6">
              Non sono stati trovati dati nel database per la location: <strong>{currentLocationId}</strong>
            </p>
            <Button onClick={fetchDashboardData} variant="outline">
              <Calendar className="h-4 w-4 mr-2" />
              Ricarica Dati
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;