import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import MetaAdsDatePicker from '@/components/ui/MetaAdsDatePicker';
import KPICards from '@/components/ui/KPICards';
import { Plus, Edit, Trash2, Users, Mail, Phone, TrendingUp, Euro, Award, Target } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Sales as SalesType, DailyKPI, DateRange } from '@/types/database';
import { subDays, format } from 'date-fns';

const Sales: React.FC = () => {
  const [salesList, setSalesList] = useState<SalesType[]>([]);
  const [salesKpis, setSalesKpis] = useState<DailyKPI[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingSales, setEditingSales] = useState<SalesType | null>(null);
  const [dateRange, setDateRange] = useState<DateRange>({
    from: subDays(new Date(), 30),
    to: new Date()
  });
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    location_id: '',
    ghl_sales_id: '',
    status: 'active',
    commission_percent: 0,
    commission_fixed: 0,
    is_active: true
  });

  useEffect(() => {
    fetchSales();
    fetchSalesKpis();
  }, [dateRange]);

  const fetchSales = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('sales')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSalesList(data || []);
    } catch (error) {
      console.error('Error fetching sales:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchSalesKpis = async () => {
    try {
      const { data, error } = await supabase
        .from('daily_kpis')
        .select('*')
        .gte('date', format(dateRange.from, 'yyyy-MM-dd'))
        .lte('date', format(dateRange.to, 'yyyy-MM-dd'));

      if (error) throw error;
      setSalesKpis(data || []);
    } catch (error) {
      console.error('Error fetching sales KPIs:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (editingSales) {
        // Update existing sales
        const { error } = await supabase
          .from('sales')
          .update({
            name: formData.name,
            email: formData.email,
            location_id: formData.location_id,
            ghl_sales_id: formData.ghl_sales_id,
            status: formData.status,
            commission_percent: formData.commission_percent,
            commission_fixed: formData.commission_fixed,
            is_active: formData.is_active,
            updated_at: new Date().toISOString()
          })
          .eq('id', editingSales.id);

        if (error) throw error;
      } else {
        // Create new sales
        const { error } = await supabase
          .from('sales')
          .insert([{
            name: formData.name,
            email: formData.email,
            location_id: formData.location_id,
            ghl_sales_id: formData.ghl_sales_id,
            status: formData.status,
            commission_percent: formData.commission_percent,
            commission_fixed: formData.commission_fixed,
            is_active: formData.is_active,
            password_hash: '' // This should be handled by your auth system
          }]);

        if (error) throw error;
      }

      // Reset form and close dialog
      resetForm();
      setIsDialogOpen(false);
      fetchSales();
    } catch (error) {
      console.error('Error saving sales:', error);
    }
  };

  const handleEdit = (sales: SalesType) => {
    setEditingSales(sales);
    setFormData({
      name: sales.name,
      email: sales.email,
      location_id: sales.location_id,
      ghl_sales_id: sales.ghl_sales_id,
      status: sales.status,
      commission_percent: sales.commission_percent,
      commission_fixed: sales.commission_fixed,
      is_active: sales.is_active
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async (salesId: string) => {
    if (!confirm('Sei sicuro di voler eliminare questo sales?')) return;

    try {
      const { error } = await supabase
        .from('sales')
        .delete()
        .eq('id', salesId);

      if (error) throw error;
      fetchSales();
    } catch (error) {
      console.error('Error deleting sales:', error);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      location_id: '',
      ghl_sales_id: '',
      status: 'active',
      commission_percent: 0,
      commission_fixed: 0,
      is_active: true
    });
    setEditingSales(null);
  };

  const handleDialogClose = () => {
    setIsDialogOpen(false);
    resetForm();
  };

  // Calculate KPI totals safely
  const kpiTotals = salesKpis && salesKpis.length > 0 ? salesKpis.reduce((acc, kpi) => ({
    leads: acc.leads + (kpi.leads || 0),
    sales_count: acc.sales_count + (kpi.sales_count || 0),
    revenue: acc.revenue + (kpi.revenue || 0),
    contracts: acc.contracts + (kpi.contracts || 0)
  }), { leads: 0, sales_count: 0, revenue: 0, contracts: 0 }) :
  { leads: 0, sales_count: 0, revenue: 0, contracts: 0 };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0
    }).format(value);
  };

  // KPI Cards Data - First Row
  const kpiCardsRow1 = [
    {
      title: 'Totale Sales',
      value: salesList.length,
      icon: Users,
      color: '#3B82F6'
    },
    {
      title: 'Sales Attivi',
      value: salesList.filter(s => s.is_active && s.status === 'active').length,
      icon: Users,
      color: '#10B981'
    },
    {
      title: 'Lead Totali',
      value: kpiTotals.leads,
      icon: Target,
      color: '#F59E0B'
    },
    {
      title: 'Vendite Totali',
      value: kpiTotals.sales_count,
      icon: TrendingUp,
      color: '#8B5CF6'
    }
  ];

  // KPI Cards Data - Second Row
  const kpiCardsRow2 = [
    {
      title: 'Revenue Totale',
      value: formatCurrency(kpiTotals.revenue),
      icon: Euro,
      color: '#059669'
    },
    {
      title: 'Contratti Firmati',
      value: kpiTotals.contracts,
      icon: Award,
      color: '#DC2626'
    },
    {
      title: 'Sales Inattivi',
      value: salesList.filter(s => !s.is_active || s.status !== 'active').length,
      icon: Users,
      color: '#F97316'
    },
    {
      title: 'Tasso Conversione',
      value: `${kpiTotals.leads > 0 ? ((kpiTotals.sales_count / kpiTotals.leads) * 100).toFixed(1) : '0.0'}%`,
      icon: TrendingUp,
      color: '#7C3AED'
    }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gestione Sales</h1>
          <p className="text-gray-600 mt-1">
            Gestisci il team di vendita e le loro performance
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setIsDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Nuovo Sales
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>
                {editingSales ? 'Modifica Sales' : 'Nuovo Sales'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Nome Completo</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    required
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="location_id">Location ID</Label>
                  <Input
                    id="location_id"
                    value={formData.location_id}
                    onChange={(e) => setFormData(prev => ({ ...prev, location_id: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="ghl_sales_id">GHL Sales ID</Label>
                  <Input
                    id="ghl_sales_id"
                    value={formData.ghl_sales_id}
                    onChange={(e) => setFormData(prev => ({ ...prev, ghl_sales_id: e.target.value }))}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="commission_percent">Commissione %</Label>
                  <Input
                    id="commission_percent"
                    type="number"
                    step="0.1"
                    value={formData.commission_percent}
                    onChange={(e) => setFormData(prev => ({ ...prev, commission_percent: parseFloat(e.target.value) || 0 }))}
                  />
                </div>
                <div>
                  <Label htmlFor="commission_fixed">Commissione Fissa €</Label>
                  <Input
                    id="commission_fixed"
                    type="number"
                    step="0.01"
                    value={formData.commission_fixed}
                    onChange={(e) => setFormData(prev => ({ ...prev, commission_fixed: parseFloat(e.target.value) || 0 }))}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="status">Status</Label>
                <Select value={formData.status} onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Attivo</SelectItem>
                    <SelectItem value="inactive">Inattivo</SelectItem>
                    <SelectItem value="suspended">Sospeso</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={handleDialogClose}>
                  Annulla
                </Button>
                <Button type="submit">
                  {editingSales ? 'Aggiorna' : 'Crea'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Date Picker */}
      <MetaAdsDatePicker 
        dateRange={dateRange}
        onDateRangeChange={setDateRange}
      />

      {/* First Row KPI Cards */}
      <KPICards data={kpiCardsRow1} />

      {/* Second Row KPI Cards */}
      <KPICards data={kpiCardsRow2} />

      {/* Sales Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Lista Sales ({salesList.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>GHL ID</TableHead>
                  <TableHead>Commissione</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Creato</TableHead>
                  <TableHead>Azioni</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {salesList && salesList.length > 0 ? salesList.map((sales) => (
                  <TableRow key={sales.id}>
                    <TableCell>
                      <div className="font-medium">{sales.name}</div>
                      <div className="text-sm text-muted-foreground">ID: {sales.id.slice(0, 8)}...</div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Mail className="h-4 w-4 text-gray-400" />
                        {sales.email}
                      </div>
                    </TableCell>
                    <TableCell>{sales.location_id}</TableCell>
                    <TableCell>{sales.ghl_sales_id}</TableCell>
                    <TableCell>
                      <div>
                        {sales.commission_percent > 0 && (
                          <div className="text-sm">{sales.commission_percent}%</div>
                        )}
                        {sales.commission_fixed > 0 && (
                          <div className="text-sm">€{sales.commission_fixed}</div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={
                          sales.is_active && sales.status === 'active' 
                            ? 'default' 
                            : sales.status === 'suspended' 
                            ? 'destructive' 
                            : 'secondary'
                        }
                      >
                        {sales.status === 'active' && sales.is_active ? 'Attivo' : 
                         sales.status === 'suspended' ? 'Sospeso' : 'Inattivo'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {new Date(sales.created_at).toLocaleDateString('it-IT')}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(sales)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDelete(sales.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )) : (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8">
                      <p className="text-muted-foreground">Nessun sales trovato</p>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Sales;