import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Settings as SettingsIcon, 
  User, 
  Bell, 
  Webhook, 
  Palette,
  Save,
  AlertCircle,
  CheckCircle,
  Target,
  TrendingUp,
  TrendingDown,
  Minus
} from 'lucide-react';

interface UserSettings {
  name: string;
  email: string;
  company: string;
  role: string;
  timezone: string;
  language: string;
}

interface NotificationSettings {
  emailNotifications: boolean;
  pushNotifications: boolean;
  weeklyReports: boolean;
  monthlyReports: boolean;
  alertThreshold: number;
}

interface WebhookSettings {
  url: string;
  enabled: boolean;
  events: string[];
  secret: string;
}

interface KPIThresholds {
  excellent: number;
  good: number;
  warning: number;
  critical: number;
}

interface ThresholdColors {
  excellent_color: string;
  good_color: string;
  warning_color: string;
  critical_color: string;
}

const Settings: React.FC = () => {
  const [userSettings, setUserSettings] = useState<UserSettings>({
    name: 'Marco Rossi',
    email: 'marco.rossi@company.com',
    company: 'LucIA Analytics',
    role: 'Admin',
    timezone: 'Europe/Rome',
    language: 'it'
  });

  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>({
    emailNotifications: true,
    pushNotifications: false,
    weeklyReports: true,
    monthlyReports: true,
    alertThreshold: 80
  });

  const [webhookSettings, setWebhookSettings] = useState<WebhookSettings>({
    url: '',
    enabled: false,
    events: ['kpi_alert', 'daily_report'],
    secret: ''
  });

  const [kpiThresholds, setKpiThresholds] = useState<KPIThresholds>({
    excellent: 70,
    good: 50,
    warning: 30,
    critical: 10
  });

  const [thresholdColors, setThresholdColors] = useState<ThresholdColors>({
    excellent_color: '#10B981',
    good_color: '#3B82F6', 
    warning_color: '#F59E0B',
    critical_color: '#EF4444'
  });

  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleSaveSettings = async () => {
    setIsSaving(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSaving(false);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    }, 1000);
  };

  const getThresholdIcon = (type: string) => {
    switch (type) {
      case 'excellent':
        return <TrendingUp className="h-4 w-4 text-green-600" />;
      case 'good':
        return <TrendingUp className="h-4 w-4 text-blue-600" />;
      case 'warning':
        return <Minus className="h-4 w-4 text-yellow-600" />;
      case 'critical':
        return <TrendingDown className="h-4 w-4 text-red-600" />;
      default:
        return <Target className="h-4 w-4" />;
    }
  };

  const getThresholdLabel = (type: string) => {
    switch (type) {
      case 'excellent':
        return 'Eccellente (maggiore di 70%)';
      case 'good':
        return 'Buono (50-70%)';
      case 'warning':
        return 'Attenzione (30-50%)';
      case 'critical':
        return 'Critico (minore di 30%)';
      default:
        return type;
    }
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <SettingsIcon className="h-8 w-8" />
            Impostazioni
          </h1>
          <p className="text-gray-600 mt-1">
            Configura le impostazioni del tuo account e delle notifiche
          </p>
        </div>
        
        <Button onClick={handleSaveSettings} disabled={isSaving}>
          {isSaving ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              Salvataggio...
            </>
          ) : (
            <>
              <Save className="h-4 w-4 mr-2" />
              Salva Modifiche
            </>
          )}
        </Button>
      </div>

      {/* Success Alert */}
      {saveSuccess && (
        <Alert className="border-green-200 bg-green-50">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">
            Impostazioni salvate con successo!
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="account" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="account" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            Account
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            Notifiche
          </TabsTrigger>
          <TabsTrigger value="webhooks" className="flex items-center gap-2">
            <Webhook className="h-4 w-4" />
            Webhook
          </TabsTrigger>
          <TabsTrigger value="kpi" className="flex items-center gap-2">
            <Palette className="h-4 w-4" />
            KPI e Colori
          </TabsTrigger>
        </TabsList>

        {/* Account Settings */}
        <TabsContent value="account">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Informazioni Account
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Nome Completo</Label>
                  <Input
                    id="name"
                    value={userSettings.name}
                    onChange={(e) => setUserSettings({...userSettings, name: e.target.value})}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={userSettings.email}
                    onChange={(e) => setUserSettings({...userSettings, email: e.target.value})}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="company">Azienda</Label>
                  <Input
                    id="company"
                    value={userSettings.company}
                    onChange={(e) => setUserSettings({...userSettings, company: e.target.value})}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="role">Ruolo</Label>
                  <Input
                    id="role"
                    value={userSettings.role}
                    onChange={(e) => setUserSettings({...userSettings, role: e.target.value})}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="timezone">Fuso Orario</Label>
                  <Input
                    id="timezone"
                    value={userSettings.timezone}
                    onChange={(e) => setUserSettings({...userSettings, timezone: e.target.value})}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="language">Lingua</Label>
                  <Input
                    id="language"
                    value={userSettings.language}
                    onChange={(e) => setUserSettings({...userSettings, language: e.target.value})}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notification Settings */}
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Impostazioni Notifiche
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="email-notifications">Notifiche Email</Label>
                    <p className="text-sm text-gray-500">Ricevi notifiche via email per eventi importanti</p>
                  </div>
                  <Switch
                    id="email-notifications"
                    checked={notificationSettings.emailNotifications}
                    onCheckedChange={(checked) => 
                      setNotificationSettings({...notificationSettings, emailNotifications: checked})
                    }
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="push-notifications">Notifiche Push</Label>
                    <p className="text-sm text-gray-500">Ricevi notifiche push nel browser</p>
                  </div>
                  <Switch
                    id="push-notifications"
                    checked={notificationSettings.pushNotifications}
                    onCheckedChange={(checked) => 
                      setNotificationSettings({...notificationSettings, pushNotifications: checked})
                    }
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="weekly-reports">Report Settimanali</Label>
                    <p className="text-sm text-gray-500">Ricevi un riepilogo settimanale delle performance</p>
                  </div>
                  <Switch
                    id="weekly-reports"
                    checked={notificationSettings.weeklyReports}
                    onCheckedChange={(checked) => 
                      setNotificationSettings({...notificationSettings, weeklyReports: checked})
                    }
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="monthly-reports">Report Mensili</Label>
                    <p className="text-sm text-gray-500">Ricevi un riepilogo mensile delle performance</p>
                  </div>
                  <Switch
                    id="monthly-reports"
                    checked={notificationSettings.monthlyReports}
                    onCheckedChange={(checked) => 
                      setNotificationSettings({...notificationSettings, monthlyReports: checked})
                    }
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="alert-threshold">Soglia Allarme (%)</Label>
                  <Input
                    id="alert-threshold"
                    type="number"
                    min="0"
                    max="100"
                    value={notificationSettings.alertThreshold}
                    onChange={(e) => 
                      setNotificationSettings({...notificationSettings, alertThreshold: parseInt(e.target.value)})
                    }
                  />
                  <p className="text-sm text-gray-500">
                    Ricevi un allarme quando le performance scendono sotto questa soglia
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Webhook Settings */}
        <TabsContent value="webhooks">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Webhook className="h-5 w-5" />
                Configurazione Webhook
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="webhook-enabled">Abilita Webhook</Label>
                  <p className="text-sm text-gray-500">Invia dati a un endpoint esterno</p>
                </div>
                <Switch
                  id="webhook-enabled"
                  checked={webhookSettings.enabled}
                  onCheckedChange={(checked) => 
                    setWebhookSettings({...webhookSettings, enabled: checked})
                  }
                />
              </div>
              
              {webhookSettings.enabled && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="webhook-url">URL Webhook</Label>
                    <Input
                      id="webhook-url"
                      type="url"
                      placeholder="https://your-endpoint.com/webhook"
                      value={webhookSettings.url}
                      onChange={(e) => 
                        setWebhookSettings({...webhookSettings, url: e.target.value})
                      }
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="webhook-secret">Secret Key</Label>
                    <Input
                      id="webhook-secret"
                      type="password"
                      placeholder="Chiave segreta per la verifica"
                      value={webhookSettings.secret}
                      onChange={(e) => 
                        setWebhookSettings({...webhookSettings, secret: e.target.value})
                      }
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Eventi da Inviare</Label>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary">Allarmi KPI</Badge>
                      <Badge variant="secondary">Report Giornalieri</Badge>
                      <Badge variant="secondary">Nuove Vendite</Badge>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* KPI and Colors Settings */}
        <TabsContent value="kpi">
          <div className="space-y-6">
            {/* KPI Thresholds */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Soglie KPI
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <Label htmlFor="excellent_threshold">Eccellente (maggiore di 70%)</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        id="excellent_threshold"
                        type="number"
                        min="0"
                        max="100"
                        value={kpiThresholds.excellent}
                        onChange={(e) => 
                          setKpiThresholds({...kpiThresholds, excellent: parseInt(e.target.value)})
                        }
                      />
                      <span className="text-sm text-gray-500">%</span>
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="good_threshold">Buono (50-70%)</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        id="good_threshold"
                        type="number"
                        min="0"
                        max="100"
                        value={kpiThresholds.good}
                        onChange={(e) => 
                          setKpiThresholds({...kpiThresholds, good: parseInt(e.target.value)})
                        }
                      />
                      <span className="text-sm text-gray-500">%</span>
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="warning_threshold">Attenzione (30-50%)</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        id="warning_threshold"
                        type="number"
                        min="0"
                        max="100"
                        value={kpiThresholds.warning}
                        onChange={(e) => 
                          setKpiThresholds({...kpiThresholds, warning: parseInt(e.target.value)})
                        }
                      />
                      <span className="text-sm text-gray-500">%</span>
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="critical_threshold">Critico (minore di 30%)</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        id="critical_threshold"
                        type="number"
                        min="0"
                        max="100"
                        value={kpiThresholds.critical}
                        onChange={(e) => 
                          setKpiThresholds({...kpiThresholds, critical: parseInt(e.target.value)})
                        }
                      />
                      <span className="text-sm text-gray-500">%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Color Configuration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="h-5 w-5" />
                  Configurazione Colori
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <Label htmlFor="excellent_color">Eccellente (maggiore di 70%)</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        id="excellent_color"
                        type="color"
                        value={thresholdColors.excellent_color}
                        onChange={(e) => 
                          setThresholdColors({...thresholdColors, excellent_color: e.target.value})
                        }
                        className="w-16 h-10 p-1 border rounded"
                      />
                      <Input
                        type="text"
                        value={thresholdColors.excellent_color}
                        onChange={(e) => 
                          setThresholdColors({...thresholdColors, excellent_color: e.target.value})
                        }
                        className="flex-1"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="good_color">Buono (50-70%)</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        id="good_color"
                        type="color"
                        value={thresholdColors.good_color}
                        onChange={(e) => 
                          setThresholdColors({...thresholdColors, good_color: e.target.value})
                        }
                        className="w-16 h-10 p-1 border rounded"
                      />
                      <Input
                        type="text"
                        value={thresholdColors.good_color}
                        onChange={(e) => 
                          setThresholdColors({...thresholdColors, good_color: e.target.value})
                        }
                        className="flex-1"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="warning_color">Attenzione (30-50%)</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        id="warning_color"
                        type="color"
                        value={thresholdColors.warning_color}
                        onChange={(e) => 
                          setThresholdColors({...thresholdColors, warning_color: e.target.value})
                        }
                        className="w-16 h-10 p-1 border rounded"
                      />
                      <Input
                        type="text"
                        value={thresholdColors.warning_color}
                        onChange={(e) => 
                          setThresholdColors({...thresholdColors, warning_color: e.target.value})
                        }
                        className="flex-1"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="critical_color">Critico (minore di 30%)</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        id="critical_color"
                        type="color"
                        value={thresholdColors.critical_color}
                        onChange={(e) => 
                          setThresholdColors({...thresholdColors, critical_color: e.target.value})
                        }
                        className="w-16 h-10 p-1 border rounded"
                      />
                      <Input
                        type="text"
                        value={thresholdColors.critical_color}
                        onChange={(e) => 
                          setThresholdColors({...thresholdColors, critical_color: e.target.value})
                        }
                        className="flex-1"
                      />
                    </div>
                  </div>
                </div>
                
                {/* Preview */}
                <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                  <h4 className="text-sm font-semibold mb-3">Anteprima Colori</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {Object.entries(thresholdColors).map(([key, color]) => {
                      const type = key.replace('_color', '');
                      return (
                        <div key={key} className="flex items-center gap-2 p-2 bg-white rounded border">
                          {getThresholdIcon(type)}
                          <div 
                            className="w-4 h-4 rounded-full border"
                            style={{ backgroundColor: color }}
                          />
                          <span className="text-xs font-medium">
                            {getThresholdLabel(type)}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Settings;