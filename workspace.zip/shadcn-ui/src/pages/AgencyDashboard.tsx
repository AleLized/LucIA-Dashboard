import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import MetaAdsDatePicker from '@/components/ui/MetaAdsDatePicker';
import ModernKPIChart from '@/components/charts/ModernKPIChart';
import { RefreshCw, Download, TrendingUp, Users, Euro, Eye, Target, Award, Building, BarChart3 } from 'lucide-react';
import { subDays, format } from 'date-fns';
import { it } from 'date-fns/locale';
import { supabase } from '@/lib/supabase';
import { DailyKPI, Sales, Location, DateRange } from '@/types/database';

const AgencyDashboard: React.FC = () => {
  const [dateRange, setDateRange] = useState<DateRange>({
    from: subDays(new Date(), 30),
    to: new Date()
  });
  const [selectedLocation, setSelectedLocation] = useState<string>('all');
  const [selectedTrafficSource, setSelectedTrafficSource] = useState<string>('all');
  const [isLoading, setIsLoading] = useState(false);
  const [kpiData, setKpiData] = useState<DailyKPI[]>([]);
  const [salesList, setSalesList] = useState<Sales[]>([]);
  const [locationsList, setLocationsList] = useState<Location[]>([]);

  useEffect(() => {
    loadDashboardData();
    loadSalesList();
    loadLocationsList();
  }, [dateRange, selectedLocation, selectedTrafficSource]);

  const loadDashboardData = async () => {
    setIsLoading(true);
    
    try {
      let query = supabase
        .from('daily_kpis')
        .select('*')
        .gte('date', format(dateRange.from, 'yyyy-MM-dd'))
        .lte('date', format(dateRange.to, 'yyyy-MM-dd'))
        .order('date', { ascending: false });

      if (selectedLocation !== 'all') {
        query = query.eq('location_id', selectedLocation);
      }

      if (selectedTrafficSource !== 'all') {
        query = query.eq('traffic_source', selectedTrafficSource);
      }

      const { data, error } = await query;

      if (error) {
        console.error('Error fetching dashboard data:', error);
        setKpiData([]);
      } else {
        setKpiData(data || []);
      }
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      setKpiData([]);
    } finally {
      setIsLoading(false);
    }
  };

  const loadSalesList = async () => {
    try {
      const { data, error } = await supabase
        .from('sales')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setSalesList(data || []);
    } catch (error) {
      console.error('Error loading sales list:', error);
      setSalesList([]);
    }
  };

  const loadLocationsList = async () => {
    try {
      const { data, error } = await supabase
        .from('locations')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setLocationsList(data || []);
    } catch (error) {
      console.error('Error loading locations list:', error);
      setLocationsList([]);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0
    }).format(value);
  };

  // Calculate totals safely from real data only
  const totals = kpiData && kpiData.length > 0 ? kpiData.reduce((acc, day) => ({
    impressions: acc.impressions + (day.impressions || 0),
    clicks: acc.clicks + (day.clicks || 0),
    leads: acc.leads + (day.leads || 0),
    sales_count: acc.sales_count + (day.sales_count || 0),
    revenue: acc.revenue + (day.revenue || 0),
    ad_spend: acc.ad_spend + (day.ad_spend || 0),
    contracts: acc.contracts + (day.contracts || 0),
    demos: acc.demos + (day.demos || 0),
    surveys: acc.surveys + (day.surveys || 0)
  }), { impressions: 0, clicks: 0, leads: 0, sales_count: 0, revenue: 0, ad_spend: 0, contracts: 0, demos: 0, surveys: 0 }) :
  { impressions: 0, clicks: 0, leads: 0, sales_count: 0, revenue: 0, ad_spend: 0, contracts: 0, demos: 0, surveys: 0 };

  // Group data by sales for performance analysis - real data only
  const salesPerformance = salesList.map(sales => {
    const salesKpis = kpiData.filter(kpi => kpi.sales_id === sales.id);
    const salesTotals = salesKpis.reduce((acc, kpi) => ({
      leads: acc.leads + (kpi.leads || 0),
      sales_count: acc.sales_count + (kpi.sales_count || 0),
      revenue: acc.revenue + (kpi.revenue || 0),
      ad_spend: acc.ad_spend + (kpi.ad_spend || 0)
    }), { leads: 0, sales_count: 0, revenue: 0, ad_spend: 0 });

    return {
      sales,
      totals: salesTotals,
      roas: salesTotals.ad_spend > 0 ? salesTotals.revenue / salesTotals.ad_spend : 0,
      conversion_rate: salesTotals.leads > 0 ? (salesTotals.sales_count / salesTotals.leads) * 100 : 0
    };
  });

  // Chart data from real database only
  const chartData = kpiData && kpiData.length > 0 ? kpiData.map(day => ({
    date: format(new Date(day.date), 'dd/MM', { locale: it }),
    leads: day.leads || 0,
    sales_count: day.sales_count || 0,
    revenue: day.revenue || 0,
    ad_spend: day.ad_spend || 0
  })) : [];

  const chartMetrics = [
    { key: 'leads', label: 'Lead', color: '#10B981', format: 'number' },
    { key: 'sales_count', label: 'Vendite', color: '#8B5CF6', format: 'number' },
    { key: 'revenue', label: 'Revenue', color: '#059669', format: 'currency' },
    { key: 'ad_spend', label: 'Spesa ADS', color: '#DC2626', format: 'currency' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Agency Dashboard</h1>
          <p className="text-gray-600 mt-1">
            Panoramica completa delle performance dell'agenzia
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" onClick={loadDashboardData} disabled={isLoading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Aggiorna
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Esporta
          </Button>
        </div>
      </div>

      {/* Date Picker */}
      <MetaAdsDatePicker 
        dateRange={dateRange}
        onDateRangeChange={setDateRange}
      />

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building className="h-5 w-5" />
              Filtri
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  Location
                </label>
                <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tutte le Location</SelectItem>
                    {locationsList.map((location) => (
                      <SelectItem key={location.id} value={location.location_id}>
                        {location.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  Fonte di Traffico
                </label>
                <Select value={selectedTrafficSource} onValueChange={setSelectedTrafficSource}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tutte le Fonti</SelectItem>
                    <SelectItem value="ads">ADS</SelectItem>
                    <SelectItem value="organic">Organico</SelectItem>
                    <SelectItem value="outbound">Outbound</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Summary Stats - Real Data Only */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Statistiche Generali
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{salesList.length}</div>
                <div className="text-sm text-gray-600">Sales Attivi</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{locationsList.length}</div>
                <div className="text-sm text-gray-600">Location</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">
                  {totals.ad_spend > 0 ? (totals.revenue / totals.ad_spend).toFixed(2) : '0.00'}x
                </div>
                <div className="text-sm text-gray-600">ROAS Medio</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600">
                  {totals.leads > 0 ? ((totals.sales_count / totals.leads) * 100).toFixed(1) : '0.0'}%
                </div>
                <div className="text-sm text-gray-600">Conv. Rate</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Chart */}
      <ModernKPIChart
        data={chartData}
        title="Trend Performance Agenzia"
        availableMetrics={chartMetrics}
        defaultMetrics={['leads', 'sales_count', 'revenue']}
        height={300}
        dateRange={dateRange}
      />

      {/* Sales Performance Table - Real Data Only */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Performance Sales ({salesPerformance.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Sales</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Lead</TableHead>
                  <TableHead>Vendite</TableHead>
                  <TableHead>Revenue</TableHead>
                  <TableHead>Spesa ADS</TableHead>
                  <TableHead>ROAS</TableHead>
                  <TableHead>Conv. Rate</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {salesPerformance && salesPerformance.length > 0 ? salesPerformance.map((performance) => (
                  <TableRow key={performance.sales.id}>
                    <TableCell>
                      <div className="font-medium">{performance.sales.name}</div>
                      <div className="text-sm text-muted-foreground">ID: {performance.sales.id.slice(0, 8)}...</div>
                    </TableCell>
                    <TableCell>{performance.sales.email}</TableCell>
                    <TableCell>{performance.totals.leads}</TableCell>
                    <TableCell>{performance.totals.sales_count}</TableCell>
                    <TableCell>{formatCurrency(performance.totals.revenue)}</TableCell>
                    <TableCell>{formatCurrency(performance.totals.ad_spend)}</TableCell>
                    <TableCell>
                      <Badge variant={performance.roas > 3 ? "default" : "secondary"}>
                        {performance.roas.toFixed(2)}x
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={performance.conversion_rate > 10 ? "default" : "secondary"}>
                        {performance.conversion_rate.toFixed(1)}%
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={performance.sales.is_active ? "default" : "secondary"}>
                        {performance.sales.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                )) : (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-8">
                      <p className="text-muted-foreground">
                        {isLoading ? 'Caricamento dati...' : 'Nessun sales trovato'}
                      </p>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          
          {isLoading && (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AgencyDashboard;