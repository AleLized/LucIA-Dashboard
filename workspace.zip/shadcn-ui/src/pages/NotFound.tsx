import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Home, ArrowLeft } from 'lucide-react';

const NotFound: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md text-center">
        <CardHeader>
          <div className="mx-auto w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
            <span className="text-2xl">🚫</span>
          </div>
          <CardTitle className="text-2xl font-bold">Pagina Non Trovata</CardTitle>
          <p className="text-gray-600">
            La pagina che stai cercando non esiste o è stata spostata.
          </p>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div className="text-6xl font-bold text-gray-300">404</div>
          
          <div className="space-y-2">
            <Link to="/login">
              <Button className="w-full">
                <Home className="h-4 w-4 mr-2" />
                Torna alla Home
              </Button>
            </Link>
            
            <Button variant="outline" onClick={() => window.history.back()}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Torna Indietro
            </Button>
          </div>
          
          <p className="text-sm text-gray-500">
            Se pensi che questo sia un errore, contatta il supporto tecnico.
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default NotFound;