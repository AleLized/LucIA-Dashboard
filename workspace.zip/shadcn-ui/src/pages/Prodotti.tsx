import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import MetaAdsDatePicker from '@/components/ui/MetaAdsDatePicker';
import KPICards from '@/components/ui/KPICards';
import ModernKPIChart from '@/components/charts/ModernKPIChart';
import { Plus, Edit, Trash2, Package, Euro, TrendingUp, ShoppingCart, Target, Award, Users, BarChart3 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Product, DailyKPI, DateRange, ProductFormData, Location } from '@/types/database';
import { subDays, format } from 'date-fns';
import { it } from 'date-fns/locale';

const Prodotti: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [productKpis, setProductKpis] = useState<DailyKPI[]>([]);
  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [dateRange, setDateRange] = useState<DateRange>({
    from: subDays(new Date(), 30),
    to: new Date()
  });
  const [formData, setFormData] = useState<ProductFormData>({
    name: '',
    description: '',
    price: 0,
    currency: 'EUR',
    is_active: true
  });

  useEffect(() => {
    fetchLocations();
    fetchProducts();
    fetchProductKpis();
  }, [dateRange]);

  const fetchLocations = async () => {
    try {
      const { data, error } = await supabase
        .from('locations')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setLocations(data || []);
    } catch (error) {
      console.error('Error fetching locations:', error);
      setLocations([]);
    }
  };

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
      setProducts([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchProductKpis = async () => {
    try {
      const { data, error } = await supabase
        .from('daily_kpis')
        .select('*')
        .gte('date', format(dateRange.from, 'yyyy-MM-dd'))
        .lte('date', format(dateRange.to, 'yyyy-MM-dd'));

      if (error) throw error;
      setProductKpis(data || []);
    } catch (error) {
      console.error('Error fetching product KPIs:', error);
      setProductKpis([]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Get the first available location ID, or use a default
      const defaultLocationId = locations.length > 0 ? locations[0].location_id : 'default_location';
      
      if (editingProduct) {
        // Update existing product
        const { error } = await supabase
          .from('products')
          .update({
            name: formData.name,
            description: formData.description,
            price: formData.price,
            currency: formData.currency,
            is_active: formData.is_active,
            updated_at: new Date().toISOString()
          })
          .eq('id', editingProduct.id);

        if (error) throw error;
      } else {
        // Create new product
        const { error } = await supabase
          .from('products')
          .insert([{
            location_id: defaultLocationId,
            name: formData.name,
            description: formData.description,
            price: formData.price,
            currency: formData.currency,
            is_active: formData.is_active
          }]);

        if (error) throw error;
      }

      // Reset form and close dialog
      resetForm();
      setIsDialogOpen(false);
      fetchProducts();
    } catch (error) {
      console.error('Error saving product:', error);
    }
  };

  const handleEdit = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      description: product.description || '',
      price: product.price,
      currency: product.currency,
      is_active: product.is_active
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async (productId: string) => {
    if (!confirm('Sei sicuro di voler eliminare questo prodotto?')) return;

    try {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', productId);

      if (error) throw error;
      fetchProducts();
    } catch (error) {
      console.error('Error deleting product:', error);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      price: 0,
      currency: 'EUR',
      is_active: true
    });
    setEditingProduct(null);
  };

  const handleDialogClose = () => {
    setIsDialogOpen(false);
    resetForm();
  };

  // Calculate KPI totals safely
  const kpiTotals = productKpis && productKpis.length > 0 ? productKpis.reduce((acc, kpi) => ({
    sales_count: acc.sales_count + (kpi.sales_count || 0),
    revenue: acc.revenue + (kpi.revenue || 0),
    leads: acc.leads + (kpi.leads || 0),
    contracts: acc.contracts + (kpi.contracts || 0)
  }), { sales_count: 0, revenue: 0, leads: 0, contracts: 0 }) :
  { sales_count: 0, revenue: 0, leads: 0, contracts: 0 };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0
    }).format(value);
  };

  // KPI Cards Data - First Row
  const kpiCardsRow1 = [
    {
      title: 'Prodotti Totali',
      value: products.length,
      icon: Package,
      color: '#3B82F6'
    },
    {
      title: 'Prodotti Attivi',
      value: products.filter(p => p.is_active).length,
      icon: Package,
      color: '#10B981'
    },
    {
      title: 'Vendite Totali',
      value: kpiTotals.sales_count,
      icon: ShoppingCart,
      color: '#F59E0B'
    },
    {
      title: 'Revenue Totale',
      value: formatCurrency(kpiTotals.revenue),
      icon: Euro,
      color: '#8B5CF6'
    }
  ];

  // KPI Cards Data - Second Row
  const kpiCardsRow2 = [
    {
      title: 'Prezzo Medio',
      value: formatCurrency(products.length > 0 ? products.reduce((sum, p) => sum + p.price, 0) / products.length : 0),
      icon: TrendingUp,
      color: '#059669'
    },
    {
      title: 'Lead Totali',
      value: kpiTotals.leads,
      icon: Target,
      color: '#DC2626'
    },
    {
      title: 'Contratti',
      value: kpiTotals.contracts,
      icon: Award,
      color: '#7C3AED'
    },
    {
      title: 'Tasso Conversione',
      value: `${kpiTotals.leads > 0 ? ((kpiTotals.sales_count / kpiTotals.leads) * 100).toFixed(1) : '0.0'}%`,
      icon: BarChart3,
      color: '#F97316'
    }
  ];

  // Chart data
  const chartData = productKpis && productKpis.length > 0 ? productKpis.map(day => ({
    date: format(new Date(day.date), 'dd/MM', { locale: it }),
    sales_count: day.sales_count || 0,
    revenue: day.revenue || 0,
    leads: day.leads || 0,
    contracts: day.contracts || 0
  })) : [];

  const chartMetrics = [
    { key: 'sales_count', label: 'Vendite', color: '#3B82F6', format: 'number' },
    { key: 'revenue', label: 'Revenue', color: '#059669', format: 'currency' },
    { key: 'leads', label: 'Lead', color: '#F59E0B', format: 'number' },
    { key: 'contracts', label: 'Contratti', color: '#DC2626', format: 'number' }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gestione Prodotti</h1>
          <p className="text-gray-600 mt-1">
            Gestisci il catalogo prodotti e analizza le performance di vendita
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setIsDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Nuovo Prodotto
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>
                {editingProduct ? 'Modifica Prodotto' : 'Nuovo Prodotto'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">Nome Prodotto</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="description">Descrizione</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="price">Prezzo</Label>
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    value={formData.price}
                    onChange={(e) => setFormData(prev => ({ ...prev, price: parseFloat(e.target.value) || 0 }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="currency">Valuta</Label>
                  <Input
                    id="currency"
                    value={formData.currency}
                    onChange={(e) => setFormData(prev => ({ ...prev, currency: e.target.value }))}
                    placeholder="EUR"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={handleDialogClose}>
                  Annulla
                </Button>
                <Button type="submit">
                  {editingProduct ? 'Aggiorna' : 'Crea'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Date Picker */}
      <MetaAdsDatePicker 
        dateRange={dateRange}
        onDateRangeChange={setDateRange}
      />

      {/* First Row KPI Cards */}
      <KPICards data={kpiCardsRow1} />

      {/* Second Row KPI Cards */}
      <KPICards data={kpiCardsRow2} />

      {/* Performance Chart */}
      <ModernKPIChart
        data={chartData}
        title="Performance Prodotti nel Tempo"
        availableMetrics={chartMetrics}
        defaultMetrics={['sales_count', 'revenue']}
        height={300}
        dateRange={dateRange}
      />

      {/* Products Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Catalogo Prodotti ({products.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Descrizione</TableHead>
                  <TableHead>Prezzo</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Creato</TableHead>
                  <TableHead>Azioni</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {products && products.length > 0 ? products.map((product) => (
                  <TableRow key={product.id}>
                    <TableCell>
                      <div className="font-medium">{product.name}</div>
                      <div className="text-sm text-muted-foreground">ID: {product.id.slice(0, 8)}...</div>
                    </TableCell>
                    <TableCell>
                      <div className="max-w-xs truncate">
                        {product.description || 'Nessuna descrizione'}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">
                        {formatCurrency(product.price)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={product.is_active ? 'default' : 'secondary'}>
                        {product.is_active ? 'Attivo' : 'Inattivo'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {new Date(product.created_at).toLocaleDateString('it-IT')}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(product)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDelete(product.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      <p className="text-muted-foreground">
                        {loading ? 'Caricamento dati...' : 'Nessun prodotto trovato'}
                      </p>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Prodotti;