import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import KPIConfigModal from '@/components/ui/KPIConfigModal';
import UTMFiltersPanel from '@/components/ui/UTMFiltersPanel';
import MetaAdsDatePicker from '@/components/ui/MetaAdsDatePicker';
import ModernKPIChart from '@/components/charts/ModernKPIChart';
import KPICards from '@/components/ui/KPICards';
import { RefreshCw, Download, TrendingUp, MousePointer, Users, Euro, Eye, Target, Award, Zap } from 'lucide-react';
import { subDays, format } from 'date-fns';
import { it } from 'date-fns/locale';
import { supabase } from '@/lib/supabase';
import { DailyKPI, Sales, DateRange } from '@/types/database';

const ADS: React.FC = () => {
  const [selectedKPIs, setSelectedKPIs] = useState<string[]>([
    'impressions', 'clicks', 'leads', 'sales_count', 'revenue', 'ad_spend'
  ]);
  const [dateRange, setDateRange] = useState<DateRange>({
    from: subDays(new Date(), 30),
    to: new Date()
  });
  const [selectedSource, setSelectedSource] = useState<string>('all');
  const [selectedSales, setSelectedSales] = useState<string>('all');
  const [isLoading, setIsLoading] = useState(false);
  const [adsData, setAdsData] = useState<DailyKPI[]>([]);
  const [salesList, setSalesList] = useState<Sales[]>([]);

  useEffect(() => {
    loadAdsData();
    loadSalesList();
  }, [dateRange, selectedSource, selectedSales]);

  const loadAdsData = async () => {
    setIsLoading(true);
    
    try {
      let query = supabase
        .from('daily_kpis')
        .select('*')
        .eq('traffic_source', 'ads')
        .gte('date', format(dateRange.from, 'yyyy-MM-dd'))
        .lte('date', format(dateRange.to, 'yyyy-MM-dd'))
        .order('date', { ascending: false });

      if (selectedSales !== 'all') {
        query = query.eq('sales_id', selectedSales);
      }

      const { data, error } = await query;

      if (error) {
        console.error('Error fetching ads data:', error);
        setAdsData([]);
      } else {
        setAdsData(data || []);
      }
    } catch (error) {
      console.error('Error loading ads data:', error);
      setAdsData([]);
    } finally {
      setIsLoading(false);
    }
  };

  const loadSalesList = async () => {
    try {
      const { data, error } = await supabase
        .from('sales')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setSalesList(data || []);
    } catch (error) {
      console.error('Error loading sales list:', error);
    }
  };

  const getROASColor = (roas: number) => {
    if (roas >= 4) return 'bg-green-100 text-green-800';
    if (roas >= 3) return 'bg-yellow-100 text-yellow-800';
    if (roas >= 2) return 'bg-orange-100 text-orange-800';
    return 'bg-red-100 text-red-800';
  };

  const getCTRColor = (ctr: number) => {
    if (ctr >= 2) return 'bg-green-100 text-green-800';
    if (ctr >= 1.5) return 'bg-yellow-100 text-yellow-800';
    if (ctr >= 1) return 'bg-orange-100 text-orange-800';
    return 'bg-red-100 text-red-800';
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0
    }).format(value);
  };

  const handleReset = () => {
    setSelectedSource('all');
    setSelectedSales('all');
  };

  // Calculate totals safely
  const totals = adsData && adsData.length > 0 ? adsData.reduce((acc, day) => ({
    impressions: acc.impressions + (day.impressions || 0),
    clicks: acc.clicks + (day.clicks || 0),
    leads: acc.leads + (day.leads || 0),
    sales_count: acc.sales_count + (day.sales_count || 0),
    revenue: acc.revenue + (day.revenue || 0),
    ad_spend: acc.ad_spend + (day.ad_spend || 0),
    contracts: acc.contracts + (day.contracts || 0),
    demos: acc.demos + (day.demos || 0)
  }), { impressions: 0, clicks: 0, leads: 0, sales_count: 0, revenue: 0, ad_spend: 0, contracts: 0, demos: 0 }) :
  { impressions: 0, clicks: 0, leads: 0, sales_count: 0, revenue: 0, ad_spend: 0, contracts: 0, demos: 0 };

  // KPI Cards Data - First Row
  const kpiCardsRow1 = [
    {
      title: 'Impressioni Totali',
      value: totals.impressions,
      icon: Eye,
      color: '#3B82F6'
    },
    {
      title: 'Click Totali',
      value: totals.clicks,
      icon: MousePointer,
      color: '#10B981'
    },
    {
      title: 'Lead Generati',
      value: totals.leads,
      icon: Users,
      color: '#F59E0B'
    },
    {
      title: 'Vendite Totali',
      value: totals.sales_count,
      icon: TrendingUp,
      color: '#8B5CF6'
    }
  ];

  // KPI Cards Data - Second Row
  const kpiCardsRow2 = [
    {
      title: 'Revenue Totale',
      value: formatCurrency(totals.revenue),
      icon: Euro,
      color: '#059669'
    },
    {
      title: 'Spesa ADS',
      value: formatCurrency(totals.ad_spend),
      icon: Target,
      color: '#DC2626'
    },
    {
      title: 'ROAS',
      value: `${totals.ad_spend > 0 ? (totals.revenue / totals.ad_spend).toFixed(2) : '0.00'}x`,
      icon: Award,
      color: '#7C3AED'
    },
    {
      title: 'CTR',
      value: `${totals.impressions > 0 ? ((totals.clicks / totals.impressions) * 100).toFixed(2) : '0.00'}%`,
      icon: Zap,
      color: '#F97316'
    }
  ];

  // Chart data
  const chartData = adsData && adsData.length > 0 ? adsData.map(day => ({
    date: format(new Date(day.date), 'dd/MM', { locale: it }),
    impressions: day.impressions || 0,
    clicks: day.clicks || 0,
    leads: day.leads || 0,
    sales_count: day.sales_count || 0,
    revenue: day.revenue || 0,
    ad_spend: day.ad_spend || 0
  })) : [];

  const chartMetrics = [
    { key: 'impressions', label: 'Impressioni', color: '#3B82F6', format: 'number' },
    { key: 'clicks', label: 'Click', color: '#10B981', format: 'number' },
    { key: 'leads', label: 'Lead', color: '#F59E0B', format: 'number' },
    { key: 'sales_count', label: 'Vendite', color: '#8B5CF6', format: 'number' },
    { key: 'revenue', label: 'Revenue', color: '#059669', format: 'currency' },
    { key: 'ad_spend', label: 'Spesa ADS', color: '#DC2626', format: 'currency' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Performance ADS</h1>
          <p className="text-gray-600 mt-1">
            Analisi dettagliata delle campagne pubblicitarie e ROAS
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" onClick={loadAdsData} disabled={isLoading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Aggiorna
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Esporta
          </Button>
        </div>
      </div>

      {/* Date Picker */}
      <MetaAdsDatePicker 
        dateRange={dateRange}
        onDateRangeChange={setDateRange}
      />

      {/* First Row KPI Cards */}
      <KPICards data={kpiCardsRow1} />

      {/* Second Row KPI Cards */}
      <KPICards data={kpiCardsRow2} />

      {/* Filters */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <KPIConfigModal
          selectedKPIs={selectedKPIs}
          onKPIChange={setSelectedKPIs}
          source="ads"
        />
        
        <UTMFiltersPanel
          selectedSource={selectedSource}
          selectedSales={selectedSales}
          onSourceChange={setSelectedSource}
          onSalesChange={setSelectedSales}
          onReset={handleReset}
          salesOptions={salesList}
        />
      </div>

      {/* Performance Chart */}
      <ModernKPIChart
        data={chartData}
        title="Trend Performance ADS"
        availableMetrics={chartMetrics}
        defaultMetrics={['impressions', 'clicks', 'leads', 'revenue']}
        height={300}
        dateRange={dateRange}
      />

      {/* Detailed ADS Grid */}
      <Card>
        <CardHeader>
          <CardTitle>Griglia KPI Dettagliata - Giorno per Giorno</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="sticky left-0 bg-white">Data</TableHead>
                  {selectedKPIs.includes('impressions') && <TableHead>Impressioni</TableHead>}
                  {selectedKPIs.includes('clicks') && <TableHead>Click</TableHead>}
                  {selectedKPIs.includes('leads') && <TableHead>Lead</TableHead>}
                  {selectedKPIs.includes('sales_count') && <TableHead>Vendite</TableHead>}
                  {selectedKPIs.includes('revenue') && <TableHead>Revenue</TableHead>}
                  {selectedKPIs.includes('ad_spend') && <TableHead>Spesa ADS</TableHead>}
                  <TableHead>CTR</TableHead>
                  <TableHead>ROAS</TableHead>
                  <TableHead>CPL</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {adsData && adsData.length > 0 ? adsData.map((day) => {
                  const ctr = (day.impressions || 0) > 0 ? ((day.clicks || 0) / (day.impressions || 0)) * 100 : 0;
                  const roas = (day.ad_spend || 0) > 0 ? (day.revenue || 0) / (day.ad_spend || 0) : 0;
                  const cpl = (day.leads || 0) > 0 ? (day.ad_spend || 0) / (day.leads || 0) : 0;
                  
                  return (
                    <TableRow key={day.id}>
                      <TableCell className="sticky left-0 bg-white font-medium">
                        {format(new Date(day.date), 'dd/MM/yyyy', { locale: it })}
                      </TableCell>
                      {selectedKPIs.includes('impressions') && (
                        <TableCell>{(day.impressions || 0).toLocaleString('it-IT')}</TableCell>
                      )}
                      {selectedKPIs.includes('clicks') && (
                        <TableCell>{day.clicks || 0}</TableCell>
                      )}
                      {selectedKPIs.includes('leads') && (
                        <TableCell>{day.leads || 0}</TableCell>
                      )}
                      {selectedKPIs.includes('sales_count') && (
                        <TableCell>{day.sales_count || 0}</TableCell>
                      )}
                      {selectedKPIs.includes('revenue') && (
                        <TableCell>{formatCurrency(day.revenue || 0)}</TableCell>
                      )}
                      {selectedKPIs.includes('ad_spend') && (
                        <TableCell>{formatCurrency(day.ad_spend || 0)}</TableCell>
                      )}
                      <TableCell>
                        <Badge className={getCTRColor(ctr)}>
                          {ctr.toFixed(2)}%
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={getROASColor(roas)}>
                          {roas.toFixed(2)}x
                        </Badge>
                      </TableCell>
                      <TableCell>{formatCurrency(cpl)}</TableCell>
                    </TableRow>
                  );
                }) : (
                  <TableRow>
                    <TableCell colSpan={10} className="text-center py-8">
                      <p className="text-muted-foreground">
                        Nessun dato ADS trovato per il periodo selezionato
                      </p>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          
          {isLoading && (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ADS;