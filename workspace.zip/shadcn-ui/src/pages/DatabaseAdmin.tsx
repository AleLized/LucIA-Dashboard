import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase';
import { DailyKPI, Sales, TrafficSource } from '@/types/database';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import { Plus, Edit, Trash2, Save, X } from 'lucide-react';

const DatabaseAdmin: React.FC = () => {
  const [dailyKpis, setDailyKpis] = useState<DailyKPI[]>([]);
  const [sales, setSales] = useState<Sales[]>([]);
  const [trafficSources, setTrafficSources] = useState<TrafficSource[]>([]);
  const [loading, setLoading] = useState(false);
  const [editingItem, setEditingItem] = useState<string | null>(null);

  useEffect(() => {
    loadAllData();
  }, []);

  const loadAllData = async () => {
    setLoading(true);
    try {
      // Load daily KPIs
      const { data: kpiData, error: kpiError } = await supabase
        .from('daily_kpis')
        .select('*')
        .order('date', { ascending: false })
        .limit(50);

      if (kpiError) throw kpiError;
      setDailyKpis(kpiData || []);

      // Load sales
      const { data: salesData, error: salesError } = await supabase
        .from('sales')
        .select('*')
        .order('name');

      if (salesError) throw salesError;
      setSales(salesData || []);

      // Load traffic sources
      const { data: trafficData, error: trafficError } = await supabase
        .from('traffic_sources')
        .select('*')
        .order('name');

      if (trafficError) throw trafficError;
      setTrafficSources(trafficData || []);

    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0
    }).format(value);
  };

  const formatNumber = (value: number) => {
    return new Intl.NumberFormat('it-IT').format(value);
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Database Admin</h1>
        <Button onClick={loadAllData} disabled={loading}>
          {loading ? 'Caricamento...' : 'Ricarica Dati'}
        </Button>
      </div>

      {/* Daily KPIs Table */}
      <Card>
        <CardHeader>
          <CardTitle>Daily KPIs (Ultimi 50 record)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">Data</th>
                  <th className="text-left p-2">Sales</th>
                  <th className="text-left p-2">Fonte</th>
                  <th className="text-left p-2">Lead</th>
                  <th className="text-left p-2">Disco In</th>
                  <th className="text-left p-2">Disco Out</th>
                  <th className="text-left p-2">Demo</th>
                  <th className="text-left p-2">Vendite</th>
                  <th className="text-left p-2">Revenue</th>
                  <th className="text-left p-2">Spesa ADS</th>
                </tr>
              </thead>
              <tbody>
                {dailyKpis.map((kpi) => (
                  <tr key={kpi.id} className="border-b hover:bg-gray-50">
                    <td className="p-2">{format(new Date(kpi.date), 'dd/MM/yyyy', { locale: it })}</td>
                    <td className="p-2">{kpi.sales_id?.slice(0, 8) || 'N/A'}</td>
                    <td className="p-2">{kpi.traffic_source_id?.slice(0, 8) || 'N/A'}</td>
                    <td className="p-2">{formatNumber(kpi.leads || 0)}</td>
                    <td className="p-2">{formatNumber(kpi.disco_inbound || 0)}</td>
                    <td className="p-2">{formatNumber(kpi.disco_outbound || 0)}</td>
                    <td className="p-2">{formatNumber(kpi.demos || 0)}</td>
                    <td className="p-2">{formatNumber(kpi.sales_count || 0)}</td>
                    <td className="p-2">{formatCurrency(kpi.revenue || 0)}</td>
                    <td className="p-2">{formatCurrency(kpi.ad_spend || 0)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Sales Table */}
      <Card>
        <CardHeader>
          <CardTitle>Sales Team</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">ID</th>
                  <th className="text-left p-2">Nome</th>
                  <th className="text-left p-2">Email</th>
                  <th className="text-left p-2">Attivo</th>
                  <th className="text-left p-2">Creato</th>
                </tr>
              </thead>
              <tbody>
                {sales.map((sale) => (
                  <tr key={sale.id} className="border-b hover:bg-gray-50">
                    <td className="p-2 font-mono text-xs">{sale.id.slice(0, 8)}</td>
                    <td className="p-2 font-medium">{sale.name}</td>
                    <td className="p-2">{sale.email || 'N/A'}</td>
                    <td className="p-2">
                      <span className={`px-2 py-1 rounded text-xs ${
                        sale.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {sale.is_active ? 'Attivo' : 'Inattivo'}
                      </span>
                    </td>
                    <td className="p-2">{format(new Date(sale.created_at), 'dd/MM/yyyy', { locale: it })}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Traffic Sources Table */}
      <Card>
        <CardHeader>
          <CardTitle>Fonti di Traffico</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">ID</th>
                  <th className="text-left p-2">Nome</th>
                  <th className="text-left p-2">Tipo</th>
                  <th className="text-left p-2">Attivo</th>
                  <th className="text-left p-2">Creato</th>
                </tr>
              </thead>
              <tbody>
                {trafficSources.map((source) => (
                  <tr key={source.id} className="border-b hover:bg-gray-50">
                    <td className="p-2 font-mono text-xs">{source.id.slice(0, 8)}</td>
                    <td className="p-2 font-medium">{source.name}</td>
                    <td className="p-2">
                      <span className={`px-2 py-1 rounded text-xs ${
                        source.source_type === 'ADS' ? 'bg-blue-100 text-blue-800' :
                        source.source_type === 'Organic' ? 'bg-green-100 text-green-800' :
                        'bg-orange-100 text-orange-800'
                      }`}>
                        {source.source_type}
                      </span>
                    </td>
                    <td className="p-2">
                      <span className={`px-2 py-1 rounded text-xs ${
                        source.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {source.is_active ? 'Attivo' : 'Inattivo'}
                      </span>
                    </td>
                    <td className="p-2">{format(new Date(source.created_at), 'dd/MM/yyyy', { locale: it })}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {loading && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg flex items-center gap-3">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
            <p>Caricamento dati dal database...</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default DatabaseAdmin;