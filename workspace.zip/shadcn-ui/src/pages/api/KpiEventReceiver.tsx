import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Textarea } from '@/components/ui/textarea';
import { supabase } from '@/lib/supabaseClient';
import { 
  Activity, 
  AlertCircle, 
  CheckCircle, 
  Clock, 
  RefreshCw, 
  Zap,
  Database,
  Send,
  Code
} from 'lucide-react';
import { toast } from 'sonner';

interface KpiEvent {
  id: string;
  location_id: string;
  event_type: string;
  event_data: KpiEventData;
  processed: boolean;
  error_message?: string;
  created_at: string;
  processed_at?: string;
}

interface KpiEventData {
  date: string;
  traffic_source: 'ads' | 'organic' | 'outbound';
  impressions?: number;
  clicks?: number;
  leads?: number;
  surveys?: number;
  demos?: number;
  sales?: number;
  revenue?: number;
  cost?: number;
  utm_source?: string;
  utm_medium?: string;
  utm_campaign?: string;
  utm_content?: string;
  utm_term?: string;
}

const KpiEventReceiver: React.FC = () => {
  const [events, setEvents] = useState<KpiEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [testPayload, setTestPayload] = useState('');
  const [sendingTest, setSendingTest] = useState(false);

  useEffect(() => {
    fetchEvents();
    // Auto-refresh every 10 seconds
    const interval = setInterval(fetchEvents, 10000);
    return () => clearInterval(interval);
  }, []);

  const fetchEvents = async () => {
    try {
      const { data, error } = await supabase
        .from('webhook_events')
        .select('*')
        .eq('event_type', 'kpi_update')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setEvents(data || []);
    } catch (error) {
      console.error('Error fetching KPI events:', error);
      toast.error('Errore nel caricamento degli eventi KPI');
    } finally {
      setLoading(false);
    }
  };

  const processEvent = async (eventId: string) => {
    try {
      const event = events.find(e => e.id === eventId);
      if (!event) return;

      // Simulate processing the KPI event
      const kpiData = event.event_data;
      
      // Insert or update daily KPI record
      const { error } = await supabase
        .from('daily_kpis')
        .upsert({
          location_id: event.location_id,
          date: kpiData.date,
          traffic_source: kpiData.traffic_source,
          impressions: kpiData.impressions || 0,
          clicks: kpiData.clicks || 0,
          leads: kpiData.leads || 0,
          surveys: kpiData.surveys || 0,
          demos: kpiData.demos || 0,
          vendita: kpiData.sales || 0,
          incassato: kpiData.revenue || 0,
          spesa_ads: kpiData.cost || 0,
          utm_source: kpiData.utm_source,
          utm_medium: kpiData.utm_medium,
          utm_campaign: kpiData.utm_campaign,
          utm_content: kpiData.utm_content,
          utm_term: kpiData.utm_term,
          updated_at: new Date().toISOString()
        }, {
          onConflict: 'location_id,date,traffic_source'
        });

      if (error) throw error;

      // Mark event as processed
      await supabase
        .from('webhook_events')
        .update({
          processed: true,
          processed_at: new Date().toISOString()
        })
        .eq('id', eventId);

      toast.success('Evento KPI elaborato con successo');
      fetchEvents();
    } catch (error) {
      console.error('Error processing KPI event:', error);
      toast.error('Errore nell\'elaborazione dell\'evento KPI');
      
      // Mark event as failed
      await supabase
        .from('webhook_events')
        .update({
          processed: false,
          error_message: error instanceof Error ? error.message : 'Unknown error',
          processed_at: new Date().toISOString()
        })
        .eq('eventId');
    }
  };

  const sendTestEvent = async () => {
    if (!testPayload.trim()) {
      toast.error('Inserisci un payload di test');
      return;
    }

    try {
      setSendingTest(true);
      const payload = JSON.parse(testPayload);
      
      // Validate payload structure
      if (!payload.location_id || !payload.event_data) {
        throw new Error('Payload deve contenere location_id e event_data');
      }

      // Insert test event
      const { error } = await supabase
        .from('webhook_events')
        .insert({
          location_id: payload.location_id,
          event_type: 'kpi_update',
          event_data: payload.event_data,
          processed: false
        });

      if (error) throw error;
      
      toast.success('Evento di test inviato con successo');
      setTestPayload('');
      fetchEvents();
    } catch (error) {
      console.error('Error sending test event:', error);
      toast.error('Errore nell\'invio dell\'evento di test: ' + (error instanceof Error ? error.message : 'Unknown error'));
    } finally {
      setSendingTest(false);
    }
  };

  const getStatusColor = (event: KpiEvent) => {
    if (event.processed) return 'text-green-600';
    if (event.error_message) return 'text-red-600';
    return 'text-yellow-600';
  };

  const getStatusIcon = (event: KpiEvent) => {
    if (event.processed) return <CheckCircle className="h-4 w-4" />;
    if (event.error_message) return <AlertCircle className="h-4 w-4" />;
    return <Clock className="h-4 w-4" />;
  };

  const getStatusText = (event: KpiEvent) => {
    if (event.processed) return 'Elaborato';
    if (event.error_message) return 'Fallito';
    return 'In attesa';
  };

  const defaultTestPayload = `{
  "location_id": "test_location_123",
  "event_data": {
    "date": "${new Date().toISOString().split('T')[0]}",
    "traffic_source": "ads",
    "impressions": 1000,
    "clicks": 50,
    "leads": 5,
    "surveys": 3,
    "demos": 2,
    "sales": 1,
    "revenue": 2000,
    "cost": 100,
    "utm_source": "google",
    "utm_medium": "cpc",
    "utm_campaign": "test_campaign"
  }
}`;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">KPI Event Receiver</h1>
          <p className="text-gray-600 mt-1">
            Monitoraggio e gestione degli eventi KPI in tempo reale
          </p>
        </div>
        
        <Button onClick={fetchEvents} disabled={loading} variant="outline">
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Aggiorna
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Eventi Totali</p>
                <p className="text-2xl font-bold">{events.length}</p>
              </div>
              <Activity className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Elaborati</p>
                <p className="text-2xl font-bold text-green-600">
                  {events.filter(e => e.processed).length}
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Falliti</p>
                <p className="text-2xl font-bold text-red-600">
                  {events.filter(e => e.error_message).length}
                </p>
              </div>
              <AlertCircle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">In Attesa</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {events.filter(e => !e.processed && !e.error_message).length}
                </p>
              </div>
              <Clock className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Test Event Sender */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Code className="h-5 w-5" />
            Test Event Sender
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">
              Payload JSON (Evento di Test)
            </label>
            <Textarea
              value={testPayload}
              onChange={(e) => setTestPayload(e.target.value)}
              placeholder={defaultTestPayload}
              rows={12}
              className="font-mono text-sm"
            />
          </div>
          
          <div className="flex gap-2">
            <Button onClick={sendTestEvent} disabled={sendingTest}>
              <Send className="h-4 w-4 mr-2" />
              {sendingTest ? 'Invio...' : 'Invia Evento Test'}
            </Button>
            <Button 
              variant="outline" 
              onClick={() => setTestPayload(defaultTestPayload)}
            >
              Usa Template
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Events Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Eventi KPI Recenti
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Timestamp</TableHead>
                <TableHead>Location ID</TableHead>
                <TableHead>Traffic Source</TableHead>
                <TableHead>Dati</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Errore</TableHead>
                <TableHead>Azioni</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {events.map((event) => (
                <TableRow key={event.id}>
                  <TableCell className="font-mono text-sm">
                    {new Date(event.created_at).toLocaleString('it-IT')}
                  </TableCell>
                  <TableCell className="font-mono text-sm">
                    {event.location_id}
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">
                      {event.event_data.traffic_source}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm space-y-1">
                      {event.event_data.leads && (
                        <div>Leads: {event.event_data.leads}</div>
                      )}
                      {event.event_data.revenue && (
                        <div>Revenue: €{event.event_data.revenue}</div>
                      )}
                      {event.event_data.cost && (
                        <div>Cost: €{event.event_data.cost}</div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className={`flex items-center gap-2 ${getStatusColor(event)}`}>
                      {getStatusIcon(event)}
                      <span>{getStatusText(event)}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    {event.error_message && (
                      <span className="text-red-600 text-sm">
                        {event.error_message.substring(0, 30)}...
                      </span>
                    )}
                  </TableCell>
                  <TableCell>
                    {!event.processed && !event.error_message && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => processEvent(event.id)}
                      >
                        <Zap className="h-4 w-4 mr-1" />
                        Elabora
                      </Button>
                    )}
                    {event.error_message && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => processEvent(event.id)}
                      >
                        Retry
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {events.length === 0 && !loading && (
            <div className="text-center py-8">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Nessun evento KPI trovato. Invia un evento di test per iniziare.
                </AlertDescription>
              </Alert>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default KpiEventReceiver;