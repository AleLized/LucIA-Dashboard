import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/lib/supabaseClient';
import { 
  Building, 
  TrendingUp, 
  Users, 
  Euro, 
  BarChart3,
  Calendar,
  RefreshCw
} from 'lucide-react';

interface LocationSummary {
  location_id: string;
  location_name: string;
  total_leads: number;
  total_sales: number;
  total_revenue: number;
  ads_spend: number;
  roas: number;
  active_sales_count: number;
}

const AgencyDashboard: React.FC = () => {
  const [locationSummaries, setLocationSummaries] = useState<LocationSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState('7');

  useEffect(() => {
    fetchAgencyData();
  }, [dateRange]);

  const fetchAgencyData = async () => {
    setLoading(true);
    try {
      const daysAgo = parseInt(dateRange);
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - daysAgo);

      // Fetch locations
      const { data: locations, error: locationsError } = await supabase
        .from('locations')
        .select('*');

      if (locationsError) throw locationsError;

      // Fetch KPI data for all locations
      const { data: kpiData, error: kpiError } = await supabase
        .from('daily_kpis')
        .select('*')
        .gte('date', startDate.toISOString().split('T')[0]);

      if (kpiError) throw kpiError;

      // Fetch sales count per location
      const { data: salesData, error: salesError } = await supabase
        .from('sales')
        .select('location_id')
        .eq('status', 'confirmed');

      if (salesError) throw salesError;

      // Process data by location
      const summaries: LocationSummary[] = locations?.map(location => {
        const locationKpis = kpiData?.filter(kpi => kpi.location_id === location.location_id) || [];
        const locationSalesCount = salesData?.filter(sale => sale.location_id === location.location_id).length || 0;

        const totals = locationKpis.reduce((acc, kpi) => {
          acc.leads += kpi.lead_generati || 0;
          acc.sales += kpi.vendita || 0;
          acc.revenue += kpi.totale_incassato || 0;
          acc.spend += kpi.spesa_ads || 0;
          return acc;
        }, { leads: 0, sales: 0, revenue: 0, spend: 0 });

        const roas = totals.spend > 0 ? totals.revenue / totals.spend : 0;

        return {
          location_id: location.location_id,
          location_name: location.name || location.location_id,
          total_leads: totals.leads,
          total_sales: totals.sales,
          total_revenue: totals.revenue,
          ads_spend: totals.spend,
          roas,
          active_sales_count: locationSalesCount
        };
      }) || [];

      setLocationSummaries(summaries);
    } catch (error) {
      console.error('Error fetching agency data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR'
    }).format(value);
  };

  const formatNumber = (value: number) => {
    return new Intl.NumberFormat('it-IT').format(value);
  };

  // Calculate totals across all locations
  const grandTotals = locationSummaries.reduce((acc, location) => {
    acc.leads += location.total_leads;
    acc.sales += location.total_sales;
    acc.revenue += location.total_revenue;
    acc.spend += location.ads_spend;
    acc.activeSales += location.active_sales_count;
    return acc;
  }, { leads: 0, sales: 0, revenue: 0, spend: 0, activeSales: 0 });

  const grandRoas = grandTotals.spend > 0 ? grandTotals.revenue / grandTotals.spend : 0;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <Building className="h-8 w-8 text-blue-600" />
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Agency Overview</h1>
            <p className="text-gray-600">Panoramica performance di tutte le location</p>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-40">
              <Calendar className="h-4 w-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Ultimi 7 giorni</SelectItem>
              <SelectItem value="14">Ultimi 14 giorni</SelectItem>
              <SelectItem value="30">Ultimi 30 giorni</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={fetchAgencyData}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Aggiorna
          </Button>
        </div>
      </div>

      {/* Global Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Totale Location</CardTitle>
            <Building className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{locationSummaries.length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Totale Lead</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(grandTotals.leads)}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Totale Vendite</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(grandTotals.sales)}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Fatturato Totale</CardTitle>
            <Euro className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(grandTotals.revenue)}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">ROAS Medio</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              <Badge variant={grandRoas > 3 ? "default" : "secondary"}>
                {grandRoas.toFixed(2)}x
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Location Performance Table */}
      <Card>
        <CardHeader>
          <CardTitle>Performance per Location</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-3">Location</th>
                  <th className="text-left p-3">Sales Attivi</th>
                  <th className="text-left p-3">Lead Generati</th>
                  <th className="text-left p-3">Vendite</th>
                  <th className="text-left p-3">Fatturato</th>
                  <th className="text-left p-3">Spesa ADS</th>
                  <th className="text-left p-3">ROAS</th>
                  <th className="text-left p-3">Conv. Rate</th>
                  <th className="text-left p-3">Status</th>
                </tr>
              </thead>
              <tbody>
                {locationSummaries.map((location) => {
                  const conversionRate = location.total_leads > 0 ? (location.total_sales / location.total_leads) * 100 : 0;
                  
                  return (
                    <tr key={location.location_id} className="border-b hover:bg-gray-50">
                      <td className="p-3">
                        <div>
                          <div className="font-medium">{location.location_name}</div>
                          <div className="text-xs text-gray-500">{location.location_id}</div>
                        </div>
                      </td>
                      <td className="p-3">
                        <Badge variant="outline">
                          {location.active_sales_count} sales
                        </Badge>
                      </td>
                      <td className="p-3 font-medium">{formatNumber(location.total_leads)}</td>
                      <td className="p-3 font-medium">{formatNumber(location.total_sales)}</td>
                      <td className="p-3 font-medium">{formatCurrency(location.total_revenue)}</td>
                      <td className="p-3">{formatCurrency(location.ads_spend)}</td>
                      <td className="p-3">
                        <Badge variant={location.roas > 3 ? "default" : "secondary"}>
                          {location.roas.toFixed(2)}x
                        </Badge>
                      </td>
                      <td className="p-3">
                        <Badge variant={conversionRate > 5 ? "default" : "secondary"}>
                          {conversionRate.toFixed(1)}%
                        </Badge>
                      </td>
                      <td className="p-3">
                        <Badge variant={location.total_leads > 0 ? "default" : "secondary"}>
                          {location.total_leads > 0 ? 'Attiva' : 'Inattiva'}
                        </Badge>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          
          {locationSummaries.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Nessuna location configurata</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AgencyDashboard;