import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { supabase, Location } from '@/lib/supabaseClient';
import { Plus, Edit, Trash2, MapPin, Settings, Globe, Key, AlertCircle, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

interface LocationFormData {
  name: string;
  location_id: string;
  account_type: 'sub_account' | 'agency';
  parent_agency_id?: string;
  ghl_location_id?: string;
  webhook_url?: string;
  webhook_secret?: string;
  password_hash: string;
  settings: LocationSettings;
}

interface LocationSettings {
  timezone: string;
  currency: string;
  conversion_lookback_days: number;
  auto_sync_enabled: boolean;
  webhook_enabled: boolean;
}

const LocationsManagement: React.FC = () => {
  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingLocation, setEditingLocation] = useState<Location | null>(null);
  const [formData, setFormData] = useState<LocationFormData>({
    name: '',
    location_id: '',
    account_type: 'sub_account',
    parent_agency_id: '',
    ghl_location_id: '',
    webhook_url: '',
    webhook_secret: '',
    password_hash: '',
    settings: {
      timezone: 'Europe/Rome',
      currency: 'EUR',
      conversion_lookback_days: 30,
      auto_sync_enabled: true,
      webhook_enabled: true
    }
  });

  useEffect(() => {
    fetchLocations();
  }, []);

  const fetchLocations = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('locations')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setLocations(data || []);
    } catch (error) {
      console.error('Error fetching locations:', error);
      toast.error('Errore nel caricamento delle location');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (editingLocation) {
        // Update existing location
        const { error } = await supabase
          .from('locations')
          .update({
            name: formData.name,
            account_type: formData.account_type,
            parent_agency_id: formData.parent_agency_id || null,
            ghl_location_id: formData.ghl_location_id || null,
            webhook_url: formData.webhook_url || null,
            webhook_secret: formData.webhook_secret || null,
            settings: formData.settings,
            updated_at: new Date().toISOString()
          })
          .eq('id', editingLocation.id);

        if (error) throw error;
        toast.success('Location aggiornata con successo');
      } else {
        // Create new location
        const { error } = await supabase
          .from('locations')
          .insert({
            name: formData.name,
            location_id: formData.location_id,
            password_hash: formData.password_hash,
            account_type: formData.account_type,
            parent_agency_id: formData.parent_agency_id || null,
            ghl_location_id: formData.ghl_location_id || null,
            webhook_url: formData.webhook_url || null,
            webhook_secret: formData.webhook_secret || null,
            is_active: true,
            settings: formData.settings
          });

        if (error) throw error;
        toast.success('Location creata con successo');
      }

      setIsDialogOpen(false);
      setEditingLocation(null);
      resetForm();
      fetchLocations();
    } catch (error) {
      console.error('Error saving location:', error);
      toast.error('Errore nel salvataggio della location');
    }
  };

  const handleEdit = (location: Location) => {
    setEditingLocation(location);
    setFormData({
      name: location.name,
      location_id: location.location_id,
      account_type: location.account_type,
      parent_agency_id: location.parent_agency_id || '',
      ghl_location_id: location.ghl_location_id || '',
      webhook_url: location.webhook_url || '',
      webhook_secret: location.webhook_secret || '',
      password_hash: location.password_hash,
      settings: location.settings as LocationSettings
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async (locationId: string) => {
    if (!confirm('Sei sicuro di voler eliminare questa location? Questa azione è irreversibile.')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('locations')
        .delete()
        .eq('id', locationId);

      if (error) throw error;
      
      toast.success('Location eliminata con successo');
      fetchLocations();
    } catch (error) {
      console.error('Error deleting location:', error);
      toast.error('Errore nell\'eliminazione della location');
    }
  };

  const toggleLocationStatus = async (locationId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('locations')
        .update({ 
          is_active: !currentStatus,
          updated_at: new Date().toISOString()
        })
        .eq('id', locationId);

      if (error) throw error;
      
      toast.success(`Location ${!currentStatus ? 'attivata' : 'disattivata'} con successo`);
      fetchLocations();
    } catch (error) {
      console.error('Error toggling location status:', error);
      toast.error('Errore nel cambio stato della location');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      location_id: '',
      account_type: 'sub_account',
      parent_agency_id: '',
      ghl_location_id: '',
      webhook_url: '',
      webhook_secret: '',
      password_hash: '',
      settings: {
        timezone: 'Europe/Rome',
        currency: 'EUR',
        conversion_lookback_days: 30,
        auto_sync_enabled: true,
        webhook_enabled: true
      }
    });
  };

  const handleDialogClose = () => {
    setIsDialogOpen(false);
    setEditingLocation(null);
    resetForm();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gestione Location</h1>
          <p className="text-gray-600 mt-1">
            Gestisci le location e i loro account associati
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setIsDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Nuova Location
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingLocation ? 'Modifica Location' : 'Nuova Location'}
              </DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Nome Location</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="location_id">ID Location</Label>
                  <Input
                    id="location_id"
                    value={formData.location_id}
                    onChange={(e) => setFormData({ ...formData, location_id: e.target.value })}
                    disabled={!!editingLocation}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="account_type">Tipo Account</Label>
                  <Select
                    value={formData.account_type}
                    onValueChange={(value: 'sub_account' | 'agency') => 
                      setFormData({ ...formData, account_type: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sub_account">Sub Account</SelectItem>
                      <SelectItem value="agency">Agency</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="password_hash">Password Hash</Label>
                  <Input
                    id="password_hash"
                    type="password"
                    value={formData.password_hash}
                    onChange={(e) => setFormData({ ...formData, password_hash: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="ghl_location_id">GHL Location ID</Label>
                  <Input
                    id="ghl_location_id"
                    value={formData.ghl_location_id}
                    onChange={(e) => setFormData({ ...formData, ghl_location_id: e.target.value })}
                  />
                </div>

                <div>
                  <Label htmlFor="parent_agency_id">Parent Agency ID</Label>
                  <Input
                    id="parent_agency_id"
                    value={formData.parent_agency_id}
                    onChange={(e) => setFormData({ ...formData, parent_agency_id: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="webhook_url">Webhook URL</Label>
                <Input
                  id="webhook_url"
                  type="url"
                  value={formData.webhook_url}
                  onChange={(e) => setFormData({ ...formData, webhook_url: e.target.value })}
                />
              </div>

              <div>
                <Label htmlFor="webhook_secret">Webhook Secret</Label>
                <Input
                  id="webhook_secret"
                  value={formData.webhook_secret}
                  onChange={(e) => setFormData({ ...formData, webhook_secret: e.target.value })}
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={handleDialogClose}>
                  Annulla
                </Button>
                <Button type="submit">
                  {editingLocation ? 'Aggiorna' : 'Crea'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Locations Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Location Attive ({locations.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Location ID</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Webhook</TableHead>
                <TableHead>Azioni</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {locations.map((location) => (
                <TableRow key={location.id}>
                  <TableCell className="font-medium">{location.name}</TableCell>
                  <TableCell className="font-mono text-sm">{location.location_id}</TableCell>
                  <TableCell>
                    <Badge variant={location.account_type === 'agency' ? 'default' : 'secondary'}>
                      {location.account_type === 'agency' ? 'Agency' : 'Sub Account'}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant={location.is_active ? 'default' : 'destructive'}>
                      {location.is_active ? 'Attiva' : 'Inattiva'}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {location.webhook_url ? (
                      <CheckCircle className="h-4 w-4 text-green-500" />
                    ) : (
                      <AlertCircle className="h-4 w-4 text-yellow-500" />
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(location)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => toggleLocationStatus(location.id, location.is_active)}
                      >
                        {location.is_active ? 'Disattiva' : 'Attiva'}
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleDelete(location.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default LocationsManagement;