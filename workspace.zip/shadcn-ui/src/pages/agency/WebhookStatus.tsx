import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase, WebhookEvent } from '@/lib/supabaseClient';
import { 
  Activity, 
  AlertCircle, 
  CheckCircle, 
  Clock, 
  RefreshCw, 
  Zap,
  TrendingUp,
  AlertTriangle,
  Globe
} from 'lucide-react';
import { toast } from 'sonner';

interface WebhookStats {
  total_events: number;
  successful_events: number;
  failed_events: number;
  pending_events: number;
  success_rate: number;
}

interface LocationWebhookStatus {
  location_id: string;
  location_name: string;
  webhook_url: string | null;
  is_active: boolean;
  last_event: string | null;
  total_events: number;
  successful_events: number;
  failed_events: number;
}

const WebhookStatus: React.FC = () => {
  const [webhookEvents, setWebhookEvents] = useState<WebhookEvent[]>([]);
  const [locationStatuses, setLocationStatuses] = useState<LocationWebhookStatus[]>([]);
  const [webhookStats, setWebhookStats] = useState<WebhookStats>({
    total_events: 0,
    successful_events: 0,
    failed_events: 0,
    pending_events: 0,
    success_rate: 0
  });
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchWebhookData();
    // Auto-refresh every 30 seconds
    const interval = setInterval(fetchWebhookData, 30000);
    return () => clearInterval(interval);
  }, []);

  const fetchWebhookData = async () => {
    try {
      setRefreshing(true);
      
      // Fetch recent webhook events
      const { data: events, error: eventsError } = await supabase
        .from('webhook_events')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (eventsError) throw eventsError;

      // Fetch location webhook statuses
      const { data: locations, error: locationsError } = await supabase
        .from('locations')
        .select(`
          location_id,
          name,
          webhook_url,
          is_active
        `);

      if (locationsError) throw locationsError;

      // Calculate webhook stats for each location
      const locationStatuses: LocationWebhookStatus[] = locations?.map(location => {
        const locationEvents = events?.filter(e => e.location_id === location.location_id) || [];
        const successfulEvents = locationEvents.filter(e => e.processed).length;
        const failedEvents = locationEvents.filter(e => !e.processed && e.error_message).length;
        
        return {
          location_id: location.location_id,
          location_name: location.name,
          webhook_url: location.webhook_url,
          is_active: location.is_active,
          last_event: locationEvents[0]?.created_at || null,
          total_events: locationEvents.length,
          successful_events: successfulEvents,
          failed_events: failedEvents
        };
      }) || [];

      // Calculate overall stats
      const totalEvents = events?.length || 0;
      const successfulEvents = events?.filter(e => e.processed).length || 0;
      const failedEvents = events?.filter(e => !e.processed && e.error_message).length || 0;
      const pendingEvents = events?.filter(e => !e.processed && !e.error_message).length || 0;
      const successRate = totalEvents > 0 ? (successfulEvents / totalEvents) * 100 : 0;

      setWebhookEvents(events || []);
      setLocationStatuses(locationStatuses);
      setWebhookStats({
        total_events: totalEvents,
        successful_events: successfulEvents,
        failed_events: failedEvents,
        pending_events: pendingEvents,
        success_rate: successRate
      });

    } catch (error) {
      console.error('Error fetching webhook data:', error);
      toast.error('Errore nel caricamento dei dati webhook');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const retryFailedWebhook = async (eventId: string) => {
    try {
      const { error } = await supabase
        .from('webhook_events')
        .update({
          processed: false,
          error_message: null,
          processed_at: null
        })
        .eq('id', eventId);

      if (error) throw error;
      
      toast.success('Webhook messo in coda per il retry');
      fetchWebhookData();
    } catch (error) {
      console.error('Error retrying webhook:', error);
      toast.error('Errore nel retry del webhook');
    }
  };

  const getStatusColor = (status: 'success' | 'failed' | 'pending') => {
    switch (status) {
      case 'success': return 'text-green-600';
      case 'failed': return 'text-red-600';
      case 'pending': return 'text-yellow-600';
      default: return 'text-gray-600';
    }
  };

  const getStatusIcon = (status: 'success' | 'failed' | 'pending') => {
    switch (status) {
      case 'success': return <CheckCircle className="h-4 w-4" />;
      case 'failed': return <AlertCircle className="h-4 w-4" />;
      case 'pending': return <Clock className="h-4 w-4" />;
      default: return <Activity className="h-4 w-4" />;
    }
  };

  const formatEventData = (eventData: Record<string, unknown>): string => {
    try {
      return JSON.stringify(eventData, null, 2);
    } catch {
      return 'Invalid JSON data';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Stato Webhook</h1>
          <p className="text-gray-600 mt-1">
            Monitoraggio in tempo reale degli eventi webhook
          </p>
        </div>
        
        <Button 
          onClick={fetchWebhookData} 
          disabled={refreshing}
          variant="outline"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
          {refreshing ? 'Aggiornamento...' : 'Aggiorna'}
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Eventi Totali</p>
                <p className="text-2xl font-bold">{webhookStats.total_events}</p>
              </div>
              <div className="p-3 rounded-lg bg-blue-50">
                <Activity className="h-6 w-6 text-blue-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Successi</p>
                <p className="text-2xl font-bold text-green-600">{webhookStats.successful_events}</p>
              </div>
              <div className="p-3 rounded-lg bg-green-50">
                <CheckCircle className="h-6 w-6 text-green-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Falliti</p>
                <p className="text-2xl font-bold text-red-600">{webhookStats.failed_events}</p>
              </div>
              <div className="p-3 rounded-lg bg-red-50">
                <AlertCircle className="h-6 w-6 text-red-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">In Attesa</p>
                <p className="text-2xl font-bold text-yellow-600">{webhookStats.pending_events}</p>
              </div>
              <div className="p-3 rounded-lg bg-yellow-50">
                <Clock className="h-6 w-6 text-yellow-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Tasso Successo</p>
                <p className="text-2xl font-bold">{webhookStats.success_rate.toFixed(1)}%</p>
              </div>
              <div className="p-3 rounded-lg bg-purple-50">
                <TrendingUp className="h-6 w-6 text-purple-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="events" className="space-y-4">
        <TabsList>
          <TabsTrigger value="events">Eventi Recenti</TabsTrigger>
          <TabsTrigger value="locations">Status per Location</TabsTrigger>
          <TabsTrigger value="monitoring">Monitoraggio</TabsTrigger>
        </TabsList>

        {/* Recent Events Tab */}
        <TabsContent value="events" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Eventi Webhook Recenti
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Timestamp</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Tipo Evento</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Errore</TableHead>
                    <TableHead>Azioni</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {webhookEvents.map((event) => {
                    const status = event.processed ? 'success' : event.error_message ? 'failed' : 'pending';
                    return (
                      <TableRow key={event.id}>
                        <TableCell className="font-mono text-sm">
                          {new Date(event.created_at).toLocaleString('it-IT')}
                        </TableCell>
                        <TableCell>{event.location_id}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{event.event_type}</Badge>
                        </TableCell>
                        <TableCell>
                          <div className={`flex items-center gap-2 ${getStatusColor(status)}`}>
                            {getStatusIcon(status)}
                            <span className="capitalize">{status}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          {event.error_message && (
                            <span className="text-red-600 text-sm">
                              {event.error_message.substring(0, 50)}...
                            </span>
                          )}
                        </TableCell>
                        <TableCell>
                          {status === 'failed' && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => retryFailedWebhook(event.id)}
                            >
                              Retry
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Location Status Tab */}
        <TabsContent value="locations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5" />
                Status Webhook per Location
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Location</TableHead>
                    <TableHead>Webhook URL</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Ultimo Evento</TableHead>
                    <TableHead>Eventi Totali</TableHead>
                    <TableHead>Successi</TableHead>
                    <TableHead>Falliti</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {locationStatuses.map((location) => (
                    <TableRow key={location.location_id}>
                      <TableCell className="font-medium">{location.location_name}</TableCell>
                      <TableCell className="font-mono text-sm">
                        {location.webhook_url ? (
                          <span className="text-green-600">Configurato</span>
                        ) : (
                          <span className="text-red-600">Non configurato</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant={location.is_active ? 'default' : 'destructive'}>
                          {location.is_active ? 'Attiva' : 'Inattiva'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {location.last_event ? (
                          <span className="text-sm">
                            {new Date(location.last_event).toLocaleString('it-IT')}
                          </span>
                        ) : (
                          <span className="text-gray-500">Nessun evento</span>
                        )}
                      </TableCell>
                      <TableCell>{location.total_events}</TableCell>
                      <TableCell className="text-green-600">{location.successful_events}</TableCell>
                      <TableCell className="text-red-600">{location.failed_events}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Monitoring Tab */}
        <TabsContent value="monitoring" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" />
                  Avvisi Sistema
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {webhookStats.success_rate < 90 && (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>
                        Tasso di successo webhook sotto il 90% ({webhookStats.success_rate.toFixed(1)}%)
                      </AlertDescription>
                    </Alert>
                  )}
                  
                  {webhookStats.failed_events > 10 && (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>
                        Numero elevato di webhook falliti: {webhookStats.failed_events}
                      </AlertDescription>
                    </Alert>
                  )}

                  {locationStatuses.filter(l => !l.webhook_url).length > 0 && (
                    <Alert>
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>
                        {locationStatuses.filter(l => !l.webhook_url).length} location senza webhook configurato
                      </AlertDescription>
                    </Alert>
                  )}

                  {webhookStats.total_events === 0 && (
                    <Alert>
                      <Clock className="h-4 w-4" />
                      <AlertDescription>
                        Nessun evento webhook ricevuto di recente
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Configurazione Webhook</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">Endpoint Webhook</h4>
                    <code className="bg-gray-100 p-2 rounded text-sm block">
                      https://your-domain.com/api/webhooks/ghl
                    </code>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">Eventi Supportati</h4>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline">ContactCreate</Badge>
                      <Badge variant="outline">ContactUpdate</Badge>
                      <Badge variant="outline">OpportunityCreate</Badge>
                      <Badge variant="outline">OpportunityUpdate</Badge>
                      <Badge variant="outline">AppointmentCreate</Badge>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-2">Formato Payload</h4>
                    <pre className="bg-gray-100 p-2 rounded text-xs overflow-x-auto">
{`{
  "type": "ContactCreate",
  "locationId": "location_123",
  "contact": {
    "id": "contact_456",
    "email": "user@example.com",
    "phone": "+1234567890"
  }
}`}
                    </pre>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default WebhookStatus;