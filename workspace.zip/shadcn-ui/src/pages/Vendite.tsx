import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import KPIConfigModal from '@/components/ui/KPIConfigModal';
import UTMFiltersPanel from '@/components/ui/UTMFiltersPanel';
import MetaAdsDatePicker from '@/components/ui/MetaAdsDatePicker';
import ModernKPIChart from '@/components/charts/ModernKPIChart';
import KPICards from '@/components/ui/KPICards';
import { RefreshCw, Download, TrendingUp, Users, Euro, Award, Target, Phone, Zap, ShoppingCart } from 'lucide-react';
import { subDays, format } from 'date-fns';
import { it } from 'date-fns/locale';
import { supabase } from '@/lib/supabase';
import { DailyKPI, Sales, DateRange } from '@/types/database';

const Vendite: React.FC = () => {
  const [selectedKPIs, setSelectedKPIs] = useState<string[]>([
    'sales_count', 'revenue', 'contracts', 'leads'
  ]);
  const [dateRange, setDateRange] = useState<DateRange>({
    from: subDays(new Date(), 30),
    to: new Date()
  });
  const [selectedSource, setSelectedSource] = useState<string>('all');
  const [selectedSales, setSelectedSales] = useState<string>('all');
  const [isLoading, setIsLoading] = useState(false);
  const [salesData, setSalesData] = useState<DailyKPI[]>([]);
  const [salesList, setSalesList] = useState<Sales[]>([]);

  useEffect(() => {
    loadSalesData();
    loadSalesList();
  }, [dateRange, selectedSource, selectedSales]);

  const loadSalesData = async () => {
    setIsLoading(true);
    
    try {
      let query = supabase
        .from('daily_kpis')
        .select('*')
        .gte('date', format(dateRange.from, 'yyyy-MM-dd'))
        .lte('date', format(dateRange.to, 'yyyy-MM-dd'))
        .order('date', { ascending: false });

      if (selectedSource !== 'all') {
        query = query.eq('traffic_source', selectedSource);
      }

      if (selectedSales !== 'all') {
        query = query.eq('sales_id', selectedSales);
      }

      const { data, error } = await query;

      if (error) {
        console.error('Error fetching sales data:', error);
        setSalesData([]);
      } else {
        setSalesData(data || []);
      }
    } catch (error) {
      console.error('Error loading sales data:', error);
      setSalesData([]);
    } finally {
      setIsLoading(false);
    }
  };

  const loadSalesList = async () => {
    try {
      const { data, error } = await supabase
        .from('sales')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setSalesList(data || []);
    } catch (error) {
      console.error('Error loading sales list:', error);
    }
  };

  const getPerformanceColor = (value: number, type: 'revenue' | 'sales' | 'rate') => {
    switch (type) {
      case 'revenue':
        if (value >= 10000) return 'bg-green-100 text-green-800';
        if (value >= 5000) return 'bg-yellow-100 text-yellow-800';
        if (value >= 1000) return 'bg-orange-100 text-orange-800';
        return 'bg-red-100 text-red-800';
      case 'sales':
        if (value >= 10) return 'bg-green-100 text-green-800';
        if (value >= 5) return 'bg-yellow-100 text-yellow-800';
        if (value >= 2) return 'bg-orange-100 text-orange-800';
        return 'bg-red-100 text-red-800';
      case 'rate':
        if (value >= 15) return 'bg-green-100 text-green-800';
        if (value >= 10) return 'bg-yellow-100 text-yellow-800';
        if (value >= 5) return 'bg-orange-100 text-orange-800';
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0
    }).format(value);
  };

  const handleReset = () => {
    setSelectedSource('all');
    setSelectedSales('all');
  };

  // Calculate totals safely
  const totals = salesData && salesData.length > 0 ? salesData.reduce((acc, day) => ({
    leads: acc.leads + (day.leads || 0),
    sales_count: acc.sales_count + (day.sales_count || 0),
    revenue: acc.revenue + (day.revenue || 0),
    contracts: acc.contracts + (day.contracts || 0),
    demos: acc.demos + (day.demos || 0),
    surveys: acc.surveys + (day.surveys || 0)
  }), { leads: 0, sales_count: 0, revenue: 0, contracts: 0, demos: 0, surveys: 0 }) :
  { leads: 0, sales_count: 0, revenue: 0, contracts: 0, demos: 0, surveys: 0 };

  // KPI Cards Data - First Row
  const kpiCardsRow1 = [
    {
      title: 'Vendite Totali',
      value: totals.sales_count,
      icon: ShoppingCart,
      color: '#3B82F6'
    },
    {
      title: 'Revenue Totale',
      value: formatCurrency(totals.revenue),
      icon: Euro,
      color: '#059669'
    },
    {
      title: 'Contratti Firmati',
      value: totals.contracts,
      icon: Award,
      color: '#DC2626'
    },
    {
      title: 'Lead Totali',
      value: totals.leads,
      icon: Target,
      color: '#F59E0B'
    }
  ];

  // KPI Cards Data - Second Row
  const kpiCardsRow2 = [
    {
      title: 'Revenue Media',
      value: formatCurrency(totals.sales_count > 0 ? totals.revenue / totals.sales_count : 0),
      icon: TrendingUp,
      color: '#8B5CF6'
    },
    {
      title: 'Tasso Conversione',
      value: `${totals.leads > 0 ? ((totals.sales_count / totals.leads) * 100).toFixed(1) : '0.0'}%`,
      icon: Zap,
      color: '#7C3AED'
    },
    {
      title: 'Demo Effettuate',
      value: totals.demos,
      icon: Users,
      color: '#EF4444'
    },
    {
      title: 'Tasso Chiusura',
      value: `${totals.demos > 0 ? ((totals.sales_count / totals.demos) * 100).toFixed(1) : '0.0'}%`,
      icon: Phone,
      color: '#10B981'
    }
  ];

  // Chart data
  const chartData = salesData && salesData.length > 0 ? salesData.map(day => ({
    date: format(new Date(day.date), 'dd/MM', { locale: it }),
    sales_count: day.sales_count || 0,
    revenue: day.revenue || 0,
    contracts: day.contracts || 0,
    leads: day.leads || 0,
    demos: day.demos || 0
  })) : [];

  const chartMetrics = [
    { key: 'sales_count', label: 'Vendite', color: '#3B82F6', format: 'number' },
    { key: 'revenue', label: 'Revenue', color: '#059669', format: 'currency' },
    { key: 'contracts', label: 'Contratti', color: '#DC2626', format: 'number' },
    { key: 'leads', label: 'Lead', color: '#F59E0B', format: 'number' },
    { key: 'demos', label: 'Demo', color: '#EF4444', format: 'number' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Report Vendite</h1>
          <p className="text-gray-600 mt-1">
            Analisi dettagliata delle performance di vendita e revenue
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" onClick={loadSalesData} disabled={isLoading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Aggiorna
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Esporta
          </Button>
        </div>
      </div>

      {/* Date Picker */}
      <MetaAdsDatePicker 
        dateRange={dateRange}
        onDateRangeChange={setDateRange}
      />

      {/* First Row KPI Cards */}
      <KPICards data={kpiCardsRow1} />

      {/* Second Row KPI Cards */}
      <KPICards data={kpiCardsRow2} />

      {/* Filters */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <KPIConfigModal
          selectedKPIs={selectedKPIs}
          onKPIChange={setSelectedKPIs}
          source="vendite"
        />
        
        <UTMFiltersPanel
          selectedSource={selectedSource}
          selectedSales={selectedSales}
          onSourceChange={setSelectedSource}
          onSalesChange={setSelectedSales}
          onReset={handleReset}
          salesOptions={salesList}
        />
      </div>

      {/* Performance Chart */}
      <ModernKPIChart
        data={chartData}
        title="Trend Performance Vendite"
        availableMetrics={chartMetrics}
        defaultMetrics={['sales_count', 'revenue', 'contracts']}
        height={300}
        dateRange={dateRange}
      />

      {/* Detailed Sales Grid */}
      <Card>
        <CardHeader>
          <CardTitle>Griglia Vendite Dettagliata - Giorno per Giorno</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="sticky left-0 bg-white">Data</TableHead>
                  {selectedKPIs.includes('leads') && <TableHead>Lead</TableHead>}
                  {selectedKPIs.includes('sales_count') && <TableHead>Vendite</TableHead>}
                  {selectedKPIs.includes('revenue') && <TableHead>Revenue</TableHead>}
                  {selectedKPIs.includes('contracts') && <TableHead>Contratti</TableHead>}
                  <TableHead>Revenue Media</TableHead>
                  <TableHead>Conv. Rate</TableHead>
                  <TableHead>Close Rate</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {salesData && salesData.length > 0 ? salesData.map((day) => {
                  const avgRevenue = (day.sales_count || 0) > 0 ? (day.revenue || 0) / (day.sales_count || 0) : 0;
                  const conversionRate = (day.leads || 0) > 0 ? ((day.sales_count || 0) / (day.leads || 0)) * 100 : 0;
                  const closeRate = (day.demos || 0) > 0 ? ((day.sales_count || 0) / (day.demos || 0)) * 100 : 0;
                  
                  return (
                    <TableRow key={day.id}>
                      <TableCell className="sticky left-0 bg-white font-medium">
                        {format(new Date(day.date), 'dd/MM/yyyy', { locale: it })}
                      </TableCell>
                      {selectedKPIs.includes('leads') && (
                        <TableCell>{day.leads || 0}</TableCell>
                      )}
                      {selectedKPIs.includes('sales_count') && (
                        <TableCell>
                          <Badge className={getPerformanceColor(day.sales_count || 0, 'sales')}>
                            {day.sales_count || 0}
                          </Badge>
                        </TableCell>
                      )}
                      {selectedKPIs.includes('revenue') && (
                        <TableCell>
                          <Badge className={getPerformanceColor(day.revenue || 0, 'revenue')}>
                            {formatCurrency(day.revenue || 0)}
                          </Badge>
                        </TableCell>
                      )}
                      {selectedKPIs.includes('contracts') && (
                        <TableCell>{day.contracts || 0}</TableCell>
                      )}
                      <TableCell>{formatCurrency(avgRevenue)}</TableCell>
                      <TableCell>
                        <Badge className={getPerformanceColor(conversionRate, 'rate')}>
                          {conversionRate.toFixed(1)}%
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={getPerformanceColor(closeRate, 'rate')}>
                          {closeRate.toFixed(1)}%
                        </Badge>
                      </TableCell>
                    </TableRow>
                  );
                }) : (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8">
                      <p className="text-muted-foreground">
                        Nessun dato di vendita trovato per il periodo selezionato
                      </p>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          
          {isLoading && (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Vendite;