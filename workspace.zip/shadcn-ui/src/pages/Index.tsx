import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CalendarDateRangePicker } from '@/components/ui/date-range-picker';
import ModernKPIChart from '@/components/charts/ModernKPIChart';
import { RefreshCw, Download, TrendingUp, Users, Euro, Eye, Target, Award } from 'lucide-react';
import { subDays, format } from 'date-fns';
import { it } from 'date-fns/locale';
import { supabase } from '@/lib/supabase';
import { DailyKPI, Sales, DateRange } from '@/types/database';

const Dashboard: React.FC = () => {
  const [dateRange, setDateRange] = useState<DateRange>({
    from: subDays(new Date(), 30),
    to: new Date()
  });
  const [selectedTrafficSource, setSelectedTrafficSource] = useState<string>('all');
  const [selectedSales, setSelectedSales] = useState<string>('all');
  const [isLoading, setIsLoading] = useState(false);
  const [kpiData, setKpiData] = useState<DailyKPI[]>([]);
  const [salesList, setSalesList] = useState<Sales[]>([]);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());

  useEffect(() => {
    loadDashboardData();
    loadSalesList();
  }, [dateRange, selectedTrafficSource, selectedSales]);

  const loadDashboardData = async () => {
    setIsLoading(true);
    
    try {
      let query = supabase
        .from('daily_kpis')
        .select('*')
        .gte('date', format(dateRange.from, 'yyyy-MM-dd'))
        .lte('date', format(dateRange.to, 'yyyy-MM-dd'))
        .order('date', { ascending: false });

      if (selectedTrafficSource !== 'all') {
        query = query.eq('traffic_source', selectedTrafficSource);
      }

      if (selectedSales !== 'all') {
        query = query.eq('sales_id', selectedSales);
      }

      const { data, error } = await query;

      if (error) {
        console.error('Error fetching dashboard data:', error);
        setKpiData([]);
      } else {
        setKpiData(data || []);
        setLastUpdate(new Date());
      }
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      setKpiData([]);
    } finally {
      setIsLoading(false);
    }
  };

  const loadSalesList = async () => {
    try {
      const { data, error } = await supabase
        .from('sales')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setSalesList(data || []);
    } catch (error) {
      console.error('Error loading sales list:', error);
      setSalesList([]);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0
    }).format(value);
  };

  // Calculate totals safely from real data
  const totals = kpiData && kpiData.length > 0 ? kpiData.reduce((acc, day) => ({
    impressions: acc.impressions + (day.impressions || 0),
    clicks: acc.clicks + (day.clicks || 0),
    leads: acc.leads + (day.leads || 0),
    sales_count: acc.sales_count + (day.sales_count || 0),
    revenue: acc.revenue + (day.revenue || 0),
    ad_spend: acc.ad_spend + (day.ad_spend || 0),
    contracts: acc.contracts + (day.contracts || 0),
    demos: acc.demos + (day.demos || 0),
    surveys: acc.surveys + (day.surveys || 0)
  }), { impressions: 0, clicks: 0, leads: 0, sales_count: 0, revenue: 0, ad_spend: 0, contracts: 0, demos: 0, surveys: 0 }) :
  { impressions: 0, clicks: 0, leads: 0, sales_count: 0, revenue: 0, ad_spend: 0, contracts: 0, demos: 0, surveys: 0 };

  // Chart data from real database
  const chartData = kpiData && kpiData.length > 0 ? kpiData.map(day => ({
    date: format(new Date(day.date), 'dd/MM', { locale: it }),
    leads: day.leads || 0,
    sales_count: day.sales_count || 0,
    revenue: day.revenue || 0,
    ad_spend: day.ad_spend || 0
  })) : [];

  const chartMetrics = [
    { key: 'leads', label: 'Lead', color: '#10B981', format: 'number' },
    { key: 'sales_count', label: 'Vendite', color: '#8B5CF6', format: 'number' },
    { key: 'revenue', label: 'Revenue', color: '#059669', format: 'currency' },
    { key: 'ad_spend', label: 'Spesa ADS', color: '#DC2626', format: 'currency' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard KPI</h1>
          <p className="text-gray-600 mt-1">
            Panoramica delle performance di tutte le fonti di traffico
          </p>
          <p className="text-sm text-gray-500 mt-1">
            Ultimo aggiornamento: {format(lastUpdate, 'HH:mm:ss')}
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" onClick={loadDashboardData} disabled={isLoading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Aggiorna
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Esporta
          </Button>
        </div>
      </div>

      {/* Date Range Picker */}
      <CalendarDateRangePicker
        date={dateRange}
        onDateChange={setDateRange}
      />

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Filtri</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  Fonte di Traffico
                </label>
                <Select value={selectedTrafficSource} onValueChange={setSelectedTrafficSource}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tutte le Fonti</SelectItem>
                    <SelectItem value="ads">ADS</SelectItem>
                    <SelectItem value="organic">Organico</SelectItem>
                    <SelectItem value="outbound">Outbound</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  Sales
                </label>
                <Select value={selectedSales} onValueChange={setSelectedSales}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tutti i Sales</SelectItem>
                    {salesList.map((sales) => (
                      <SelectItem key={sales.id} value={sales.id}>
                        {sales.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Summary Stats */}
        <Card>
          <CardHeader>
            <CardTitle>Riepilogo Periodo</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{totals.leads}</div>
                <div className="text-sm text-gray-600">Lead Totali</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{totals.sales_count}</div>
                <div className="text-sm text-gray-600">Vendite</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">
                  {formatCurrency(totals.revenue)}
                </div>
                <div className="text-sm text-gray-600">Revenue</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600">
                  {totals.leads > 0 ? ((totals.sales_count / totals.leads) * 100).toFixed(1) : '0.0'}%
                </div>
                <div className="text-sm text-gray-600">Conv. Rate</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Chart */}
      <ModernKPIChart
        data={chartData}
        title="Trend Performance Generale"
        availableMetrics={chartMetrics}
        defaultMetrics={['leads', 'sales_count', 'revenue']}
        height={300}
        dateRange={dateRange}
      />

      {/* KPI Table */}
      <Card>
        <CardHeader>
          <CardTitle>Dettaglio KPI per Giorno</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>Fonte</TableHead>
                  <TableHead>Lead</TableHead>
                  <TableHead>Vendite</TableHead>
                  <TableHead>Revenue</TableHead>
                  <TableHead>Spesa ADS</TableHead>
                  <TableHead>ROAS</TableHead>
                  <TableHead>Conv. Rate</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {kpiData && kpiData.length > 0 ? kpiData.map((day) => {
                  const roas = (day.ad_spend || 0) > 0 ? (day.revenue || 0) / (day.ad_spend || 0) : 0;
                  const conversionRate = (day.leads || 0) > 0 ? ((day.sales_count || 0) / (day.leads || 0)) * 100 : 0;
                  
                  return (
                    <TableRow key={day.id}>
                      <TableCell>
                        {format(new Date(day.date), 'dd/MM/yyyy', { locale: it })}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {day.traffic_source}
                        </Badge>
                      </TableCell>
                      <TableCell>{day.leads || 0}</TableCell>
                      <TableCell>{day.sales_count || 0}</TableCell>
                      <TableCell>{formatCurrency(day.revenue || 0)}</TableCell>
                      <TableCell>{formatCurrency(day.ad_spend || 0)}</TableCell>
                      <TableCell>
                        <Badge variant={roas > 3 ? "default" : "secondary"}>
                          {roas.toFixed(2)}x
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={conversionRate > 10 ? "default" : "secondary"}>
                          {conversionRate.toFixed(1)}%
                        </Badge>
                      </TableCell>
                    </TableRow>
                  );
                }) : (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8">
                      <p className="text-muted-foreground">
                        {isLoading ? 'Caricamento dati...' : 'Nessun dato trovato per il periodo selezionato'}
                      </p>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;