import { DailyKPI } from '@/types/database';
import { format, differenceInDays, eachWeekOfInterval, eachMonthOfInterval, startOfWeek, endOfWeek, startOfMonth, endOfMonth } from 'date-fns';
import { it } from 'date-fns/locale';

export interface AggregatedChartData {
  date: string;
  [key: string]: number | string;
}

export const aggregateChartData = (
  data: DailyKPI[],
  dateRange: { from: Date; to: Date },
  metrics: string[]
): AggregatedChartData[] => {
  const daysDiff = differenceInDays(dateRange.to, dateRange.from);
  
  // Determine aggregation level based on date range
  if (daysDiff <= 30) {
    // Daily aggregation (≤30 days)
    return aggregateDaily(data, metrics);
  } else if (daysDiff <= 90) {
    // Weekly aggregation (31-90 days)
    return aggregateWeekly(data, dateRange, metrics);
  } else {
    // Monthly aggregation (>90 days)
    return aggregateMonthly(data, dateRange, metrics);
  }
};

const aggregateDaily = (data: DailyKPI[], metrics: string[]): AggregatedChartData[] => {
  return data.map(day => {
    const result: AggregatedChartData = {
      date: format(new Date(day.date), 'dd/MM', { locale: it })
    };
    
    metrics.forEach(metric => {
      result[metric] = (day as Record<string, unknown>)[metric] as number || 0;
    });
    
    return result;
  });
};

const aggregateWeekly = (
  data: DailyKPI[], 
  dateRange: { from: Date; to: Date }, 
  metrics: string[]
): AggregatedChartData[] => {
  const weeks = eachWeekOfInterval(dateRange, { weekStartsOn: 1 });
  
  return weeks.map(weekStart => {
    const weekEnd = endOfWeek(weekStart, { weekStartsOn: 1 });
    const weekData = data.filter(day => {
      const dayDate = new Date(day.date);
      return dayDate >= weekStart && dayDate <= weekEnd;
    });
    
    const result: AggregatedChartData = {
      date: format(weekStart, 'dd/MM', { locale: it })
    };
    
    metrics.forEach(metric => {
      result[metric] = weekData.reduce((sum, day) => sum + ((day as Record<string, unknown>)[metric] as number || 0), 0);
    });
    
    return result;
  });
};

const aggregateMonthly = (
  data: DailyKPI[], 
  dateRange: { from: Date; to: Date }, 
  metrics: string[]
): AggregatedChartData[] => {
  const months = eachMonthOfInterval(dateRange);
  
  return months.map(monthStart => {
    const monthEnd = endOfMonth(monthStart);
    const monthData = data.filter(day => {
      const dayDate = new Date(day.date);
      return dayDate >= startOfMonth(monthStart) && dayDate <= monthEnd;
    });
    
    const result: AggregatedChartData = {
      date: format(monthStart, 'MMM', { locale: it })
    };
    
    metrics.forEach(metric => {
      result[metric] = monthData.reduce((sum, day) => sum + ((day as Record<string, unknown>)[metric] as number || 0), 0);
    });
    
    return result;
  });
};