// Database creation utility that can be run from the web app
import { supabase } from '../lib/supabaseClient';

export interface DatabaseCreationResult {
  success: boolean;
  message: string;
  details?: Record<string, unknown>;
}

export async function createDatabaseStructure(): Promise<DatabaseCreationResult> {
  try {
    console.log('🚀 Starting database creation from web app...');

    // Step 1: Create locations data
    console.log('📍 Creating locations...');
    const locations = [
      {
        id: 'demo_location',
        location_id: 'demo_location',
        password_hash: 'demo_hash',
        name: 'Demo Location',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: 'location_1',
        location_id: 'location_1',
        password_hash: 'location1_hash',
        name: 'Milano Centro',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: 'location_2',
        location_id: 'location_2',
        password_hash: 'location2_hash',
        name: 'Roma EUR',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }
    ];

    const locationResults = [];
    for (const location of locations) {
      const { data, error } = await supabase.from('locations').upsert(location).select();
      if (error) {
        console.warn(`Location ${location.name}:`, error.message);
        locationResults.push({ location: location.name, error: error.message });
      } else {
        console.log(`✅ Created location: ${location.name}`);
        locationResults.push({ location: location.name, success: true });
      }
    }

    // Step 2: Create commerciali data
    console.log('👥 Creating commerciali...');
    const commerciali = [
      {
        id: 'comm_1',
        location_id: 'demo_location',
        nome: 'Marco',
        cognome: 'Rossi',
        email: 'marco.rossi@company.com',
        telefono: '+39 333 1234567',
        is_active: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: 'comm_2',
        location_id: 'location_1',
        nome: 'Laura',
        cognome: 'Bianchi',
        email: 'laura.bianchi@company.com',
        telefono: '+39 333 2345678',
        is_active: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: 'comm_3',
        location_id: 'location_2',
        nome: 'Giuseppe',
        cognome: 'Verdi',
        email: 'giuseppe.verdi@company.com',
        telefono: '+39 333 3456789',
        is_active: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }
    ];

    const commercialiResults = [];
    for (const commerciale of commerciali) {
      const { data, error } = await supabase.from('commerciali').upsert(commerciale).select();
      if (error) {
        console.warn(`Commerciale ${commerciale.nome}:`, error.message);
        commercialiResults.push({ commerciale: `${commerciale.nome} ${commerciale.cognome}`, error: error.message });
      } else {
        console.log(`✅ Created commerciale: ${commerciale.nome} ${commerciale.cognome}`);
        commercialiResults.push({ commerciale: `${commerciale.nome} ${commerciale.cognome}`, success: true });
      }
    }

    // Step 3: Create comprehensive KPI data with all 16+ fields
    console.log('📊 Creating comprehensive KPI data...');
    const today = new Date();
    const dates = [];
    
    // Generate last 7 days
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      dates.push(date.toISOString().split('T')[0]);
    }

    const trafficSources = ['ads', 'organic', 'outbound'];
    const locationIds = ['demo_location', 'location_1', 'location_2'];

    const kpiResults = [];
    let successfulKpis = 0;

    for (const locationId of locationIds) {
      for (const trafficSource of trafficSources) {
        for (const date of dates) {
          const baseMultiplier = trafficSource === 'ads' ? 1.8 : trafficSource === 'organic' ? 1.3 : 0.9;
          const randomFactor = 0.85 + Math.random() * 0.3;

          const kpiData = {
            id: `kpi_${locationId}_${trafficSource}_${date.replace(/-/g, '')}`,
            location_id: locationId,
            commerciale_id: `comm_${Math.floor(Math.random() * 3) + 1}`,
            date: date,
            traffic_source: trafficSource,
            
            // UTM Parameters
            utm_source: trafficSource === 'ads' ? ['google', 'facebook'][Math.floor(Math.random() * 2)] : 'organic',
            utm_medium: trafficSource === 'ads' ? 'cpc' : 'organic',
            utm_campaign: trafficSource === 'ads' ? `campaign_${Math.floor(Math.random() * 3) + 1}` : null,
            utm_term: trafficSource === 'ads' ? `keyword_${Math.floor(Math.random() * 5) + 1}` : null,
            utm_content: trafficSource === 'ads' ? `ad_${Math.floor(Math.random() * 2) + 1}` : null,
            
            // All 16+ KPI fields for comprehensive dashboard
            impressions: Math.floor(1200 * baseMultiplier * randomFactor),
            click_sul_link: Math.floor(180 * baseMultiplier * randomFactor),
            lead_generati: Math.floor(54 * baseMultiplier * randomFactor),
            survey: Math.floor(42 * baseMultiplier * randomFactor),
            
            disco_inbound_prenotata: Math.floor(30 * baseMultiplier * randomFactor),
            disco_outbound_prenotata: Math.floor(24 * baseMultiplier * randomFactor),
            disco_showed_inbound: Math.floor(26 * baseMultiplier * randomFactor),
            disco_showed_outbound: Math.floor(21 * baseMultiplier * randomFactor),
            
            demo: Math.floor(18 * baseMultiplier * randomFactor),
            demo_showed: Math.floor(15 * baseMultiplier * randomFactor),
            pre_vendita: Math.floor(10 * baseMultiplier * randomFactor),
            vendita: Math.floor(6 * baseMultiplier * randomFactor),
            
            totale_contratti: Math.floor(5 * baseMultiplier * randomFactor),
            totale_incassato: Math.floor(15000 * baseMultiplier * randomFactor),
            spesa_ads: trafficSource === 'ads' ? Math.floor(3500 * randomFactor) : 0,
            
            // Calculated fields
            roas: 0,
            costo_per_lead_generati: 0,
            costo_per_survey: 0,
            costo_per_disco_inbound: 0,
            costo_per_disco_showed_inbound: 0,
            costo_per_demo: 0,
            costo_per_demo_showed: 0,
            costo_per_pre_vendita: 0,
            costo_per_vendita: 0,
            
            // Product Packs (Additional KPIs for 16 total)
            pack_1: Math.floor(3 * baseMultiplier * randomFactor),
            pack_2: Math.floor(2 * baseMultiplier * randomFactor),
            pack_3: Math.floor(1 * baseMultiplier * randomFactor),
            pack_4: Math.floor(0.5 * baseMultiplier * randomFactor),
            
            // Upsells
            upsell_1: Math.floor(1.5 * baseMultiplier * randomFactor),
            upsell_2: Math.floor(0.8 * baseMultiplier * randomFactor),
            upsell_3: Math.floor(0.4 * baseMultiplier * randomFactor),
            
            // AOV
            aov: 0,
            
            // Outbound-specific
            chiamate_effettuate: trafficSource === 'outbound' ? Math.floor(80 * randomFactor) : 0,
            risposte_ricevute: trafficSource === 'outbound' ? Math.floor(35 * randomFactor) : 0,
            
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          };

          // Calculate derived values
          if (kpiData.spesa_ads > 0) {
            kpiData.roas = parseFloat((kpiData.totale_incassato / kpiData.spesa_ads).toFixed(2));
            kpiData.costo_per_lead_generati = kpiData.lead_generati > 0 ? parseFloat((kpiData.spesa_ads / kpiData.lead_generati).toFixed(2)) : 0;
            kpiData.costo_per_survey = kpiData.survey > 0 ? parseFloat((kpiData.spesa_ads / kpiData.survey).toFixed(2)) : 0;
            kpiData.costo_per_demo = kpiData.demo > 0 ? parseFloat((kpiData.spesa_ads / kpiData.demo).toFixed(2)) : 0;
            kpiData.costo_per_vendita = kpiData.vendita > 0 ? parseFloat((kpiData.spesa_ads / kpiData.vendita).toFixed(2)) : 0;
          }
          
          if (kpiData.vendita > 0) {
            kpiData.aov = parseFloat((kpiData.totale_incassato / kpiData.vendita).toFixed(2));
          }

          const { data, error } = await supabase.from('daily_kpis').upsert(kpiData).select();
          if (error) {
            console.warn(`KPI ${locationId}/${trafficSource}/${date}:`, error.message);
            kpiResults.push({ kpi: `${locationId}/${trafficSource}/${date}`, error: error.message });
          } else {
            successfulKpis++;
            kpiResults.push({ kpi: `${locationId}/${trafficSource}/${date}`, success: true });
          }
        }
      }
    }

    console.log(`✅ KPI data creation completed: ${successfulKpis} records created`);

    // Step 4: Verify database state
    console.log('🔍 Verifying database...');
    const tables = ['locations', 'commerciali', 'daily_kpis'];
    const verification: Record<string, unknown> = {};
    
    for (const table of tables) {
      const { count, error } = await supabase.from(table).select('*', { count: 'exact', head: true });
      if (error) {
        verification[table] = { error: error.message };
      } else {
        verification[table] = { count };
      }
    }

    return {
      success: true,
      message: `Database creation completed. Created ${successfulKpis} KPI records.`,
      details: {
        locations: locationResults,
        commerciali: commercialiResults,
        kpis: { total: kpiResults.length, successful: successfulKpis },
        verification
      }
    };

  } catch (error) {
    console.error('❌ Database creation failed:', error);
    return {
      success: false,
      message: `Database creation failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
      details: { error: error instanceof Error ? error.message : 'Unknown error' }
    };
  }
}

export async function testDatabaseConnection(): Promise<DatabaseCreationResult> {
  try {
    console.log('🔗 Testing database connection...');
    
    const { data, error } = await supabase.from('locations').select('*').limit(1);
    
    if (error) {
      return {
        success: false,
        message: `Connection test failed: ${error.message}`,
        details: { error }
      };
    }

    return {
      success: true,
      message: 'Database connection successful',
      details: { data }
    };

  } catch (error) {
    return {
      success: false,
      message: `Connection test failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
      details: { error: error instanceof Error ? error.message : 'Unknown error' }
    };
  }
}