import { NextApiRequest, NextApiResponse } from 'next';
import { supabase } from '@/lib/supabase';
import { processAdsData } from '@/lib/webhookHandlers';

// Make.com Ads Webhook Payload Examples
export interface MakeComAdsPayload {
  location_id: string;
  date: string; // YYYY-MM-DD format
  platform: 'google_ads' | 'facebook_ads' | 'linkedin_ads';
  campaign_data: {
    campaign_id: string;
    campaign_name: string;
    utm_source: string;
    utm_campaign: string;
    utm_medium: string;
    utm_content?: string;
    utm_term?: string;
  };
  metrics: {
    impressions: number;
    clicks: number;
    spend: number; // in euros
    ctr: number; // click-through rate
    cpc: number; // cost per click
    cpm: number; // cost per mille
  };
  timestamp: string;
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const payload: MakeComAdsPayload = req.body;
    
    // Validate required fields
    if (!payload.location_id || !payload.date || !payload.metrics) {
      return res.status(400).json({ 
        error: 'Missing required fields: location_id, date, metrics' 
      });
    }

    // Check for duplicates using location_id + date + campaign_id combination
    const { data: existingRecord } = await supabase
      .from('ads_data')
      .select('id')
      .eq('location_id', payload.location_id)
      .eq('date', payload.date)
      .eq('campaign_id', payload.campaign_data.campaign_id)
      .eq('platform', payload.platform)
      .single();

    if (existingRecord) {
      // Update existing record instead of creating duplicate
      await supabase
        .from('ads_data')
        .update({
          impressions: payload.metrics.impressions,
          clicks: payload.metrics.clicks,
          spend: payload.metrics.spend,
          ctr: payload.metrics.ctr,
          cpc: payload.metrics.cpc,
          cpm: payload.metrics.cpm,
          updated_at: new Date().toISOString()
        })
        .eq('id', existingRecord.id);

      console.log(`Updated existing ads data for campaign ${payload.campaign_data.campaign_id}`);
      return res.status(200).json({ 
        message: 'Ads data updated successfully',
        campaign_id: payload.campaign_data.campaign_id 
      });
    }

    // Process the ads data
    await processAdsData(payload);

    res.status(200).json({ 
      message: 'Ads webhook processed successfully',
      campaign_id: payload.campaign_data.campaign_id,
      date: payload.date
    });

  } catch (error) {
    console.error('Make.com Webhook Error:', error);
    res.status(500).json({ 
      error: 'Internal server error',
      details: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}

// Example payload structures for documentation:
export const MAKECOM_PAYLOAD_EXAMPLES = {
  google_ads: {
    location_id: "loc_67890",
    date: "2024-10-01",
    platform: "google_ads",
    campaign_data: {
      campaign_id: "gads_12345",
      campaign_name: "Summer Sale Campaign",
      utm_source: "google",
      utm_campaign: "summer_campaign",
      utm_medium: "cpc",
      utm_content: "ad_variant_1",
      utm_term: "buy_now"
    },
    metrics: {
      impressions: 15420,
      clicks: 892,
      spend: 245.67,
      ctr: 5.78,
      cpc: 0.28,
      cpm: 15.93
    },
    timestamp: "2024-10-01T23:59:00Z"
  },

  facebook_ads: {
    location_id: "loc_67890", 
    date: "2024-10-01",
    platform: "facebook_ads",
    campaign_data: {
      campaign_id: "fb_67890",
      campaign_name: "Autumn Promotion",
      utm_source: "facebook",
      utm_campaign: "autumn_promo",
      utm_medium: "social",
      utm_content: "carousel_ad"
    },
    metrics: {
      impressions: 28750,
      clicks: 1456,
      spend: 189.34,
      ctr: 5.06,
      cpc: 0.13,
      cpm: 6.58
    },
    timestamp: "2024-10-01T23:59:00Z"
  },

  linkedin_ads: {
    location_id: "loc_67890",
    date: "2024-10-01", 
    platform: "linkedin_ads",
    campaign_data: {
      campaign_id: "li_54321",
      campaign_name: "B2B Lead Generation",
      utm_source: "linkedin",
      utm_campaign: "b2b_leads",
      utm_medium: "social",
      utm_content: "sponsored_content"
    },
    metrics: {
      impressions: 8920,
      clicks: 267,
      spend: 456.78,
      ctr: 2.99,
      cpc: 1.71,
      cpm: 51.22
    },
    timestamp: "2024-10-01T23:59:00Z"
  }
};

// Webhook URLs for configuration:
export const WEBHOOK_URLS = {
  ghl: "https://your-domain.com/api/webhooks/ghl",
  makecom: "https://your-domain.com/api/webhooks/makecom"
};