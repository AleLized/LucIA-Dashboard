import { NextApiRequest, NextApiResponse } from 'next';
import { supabase, supabaseAdmin } from '@/lib/supabase';
import { processKPIData } from '@/lib/webhookHandlers';

// GHL Webhook Payload Examples
export interface GHLLeadPayload {
  contact_id: string;
  location_id: string;
  sales_id: string;
  event_type: 'lead' | 'survey' | 'disco_inbound' | 'disco_outbound' | 'demo' | 'sale';
  utm_source?: string;
  utm_campaign?: string;
  utm_medium?: string;
  utm_content?: string;
  utm_term?: string;
  source: 'ads' | 'organic' | 'outbound';
  timestamp: string;
  data: {
    // For leads
    lead_score?: number;
    lead_quality?: 'hot' | 'warm' | 'cold';
    
    // For surveys
    survey_completed?: boolean;
    survey_score?: number;
    
    // For appointments
    appointment_type?: 'disco_inbound' | 'disco_outbound' | 'demo';
    appointment_date?: string;
    appointment_status?: 'scheduled' | 'completed' | 'no_show' | 'cancelled';
    
    // For sales
    product_id?: string;
    sale_amount?: number;
    sale_status?: 'contrattualizzato' | 'incassato';
    commission_rate?: number;
  };
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const payload: GHLLeadPayload = req.body;
    
    // Validate required fields
    if (!payload.contact_id || !payload.location_id || !payload.event_type) {
      return res.status(400).json({ 
        error: 'Missing required fields: contact_id, location_id, event_type' 
      });
    }

    // Check for duplicates using contact_id + event_type + UTM combination
    const { data: existingRecord } = await supabase
      .from('kpi_events')
      .select('id')
      .eq('contact_id', payload.contact_id)
      .eq('event_type', payload.event_type)
      .eq('location_id', payload.location_id)
      .eq('utm_source', payload.utm_source || '')
      .eq('utm_campaign', payload.utm_campaign || '')
      .eq('source', payload.source)
      ;

    if (existingRecord) {
      console.log(`Duplicate webhook detected for contact ${payload.contact_id}`);
      return res.status(200).json({ 
        message: 'Duplicate event ignored',
        contact_id: payload.contact_id 
      });
    }

    // Process the KPI data
    await processKPIData(payload);

    res.status(200).json({ 
      message: 'Webhook processed successfully',
      contact_id: payload.contact_id,
      event_type: payload.event_type
    });

  } catch (error) {
    console.error('GHL Webhook Error:', error);
    res.status(500).json({ 
      error: 'Internal server error',
      details: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}

// Example payload structures for documentation:
export const GHL_PAYLOAD_EXAMPLES = {
  lead: {
    contact_id: "contact_12345",
    location_id: "loc_67890",
    sales_id: "sales_001",
    event_type: "lead",
    utm_source: "google",
    utm_campaign: "summer_campaign",
    utm_medium: "cpc",
    utm_content: "ad_variant_1",
    utm_term: "buy_now",
    source: "ads",
    timestamp: "2024-10-01T10:30:00Z",
    data: {
      lead_score: 85,
      lead_quality: "hot"
    }
  },
  
  survey: {
    contact_id: "contact_12345",
    location_id: "loc_67890", 
    sales_id: "sales_001",
    event_type: "survey",
    utm_source: "google",
    utm_campaign: "summer_campaign",
    source: "ads",
    timestamp: "2024-10-02T14:15:00Z",
    data: {
      survey_completed: true,
      survey_score: 9
    }
  },

  disco_inbound: {
    contact_id: "contact_12345",
    location_id: "loc_67890",
    sales_id: "sales_001", 
    event_type: "disco_inbound",
    utm_source: "google",
    utm_campaign: "summer_campaign",
    source: "ads",
    timestamp: "2024-10-03T09:00:00Z",
    data: {
      appointment_type: "disco_inbound",
      appointment_date: "2024-10-05T15:00:00Z",
      appointment_status: "scheduled"
    }
  },

  sale: {
    contact_id: "contact_12345",
    location_id: "loc_67890",
    sales_id: "sales_001",
    event_type: "sale", 
    utm_source: "google",
    utm_campaign: "summer_campaign",
    source: "ads",
    timestamp: "2024-10-10T16:30:00Z",
    data: {
      product_id: "prod_premium_001",
      sale_amount: 2500,
      sale_status: "contrattualizzato",
      commission_rate: 0.15
    }
  }
};