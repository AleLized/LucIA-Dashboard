// Core application types
export interface KpiMetrics {
  impression?: number
  click_sul_link?: number
  lead_generati?: number
  chiamata_outbound_iniziata?: number
  chiamata_outbound_completata?: number
  disco_inbound_prenotata?: number
  disco_outbound_prenotata?: number
  disco_showed_inbound?: number
  disco_showed_outbound?: number
  demo?: number
  demo_showed?: number
  pre_vendita?: number
  vendita?: number
  contratti?: number
  incassato?: number
  spesa_ads?: number
  roas?: number
  pack_1?: number
  pack_2?: number
  pack_3?: number
  pack_4?: number
  upsell_1?: number
  upsell_2?: number
  upsell_3?: number
  aov?: number
}

export interface SalesPerformance {
  sales_id: string
  nome: string
  cognome: string
  email: string
  total_metrics: KpiMetrics
  by_traffic_source: {
    ads: KpiMetrics
    organic: KpiMetrics
    outbound: KpiMetrics
  }
  budget_allocato: number
  lead_assegnati: number
  costo_medio_lead: number
}

export interface DateRange {
  start: string
  end: string
}

export interface ColumnVisibility {
  [key: string]: boolean
}

export interface WebhookEvent {
  location_id: string
  sales_id?: string
  product_id?: string
  traffic_source: 'ads' | 'organic' | 'outbound'
  event_type: string
  value: number
  date?: string
  utm_source?: string
  utm_medium?: string
  utm_campaign?: string
  utm_term?: string
  utm_content?: string
}

export interface BudgetAllocation {
  sales_id: string
  lead_assegnati: number
  costo_medio_ultimi_3_giorni: number
  budget_allocato: number
}