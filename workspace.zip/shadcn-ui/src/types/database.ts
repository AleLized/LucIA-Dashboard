// Database types based on actual Supabase schema
export interface DailyKPI {
  id: string;
  location_id: string;
  sales_id: string;
  product_id?: string;
  date: string;
  traffic_source: 'ads' | 'organic' | 'outbound';
  leads: number;
  sales_count: number;
  revenue: number;
  ad_spend: number;
  impressions: number;
  clicks: number;
  surveys: number;
  demos: number;
  contracts: number;
  utm_source?: string;
  utm_medium?: string;
  utm_campaign?: string;
  utm_content?: string;
  utm_term?: string;
  roas: number;
  cost_per_lead: number;
  conversion_rate: number;
  created_at: string;
  updated_at: string;
}

export interface Sales {
  id: string;
  location_id: string;
  ghl_sales_id: string;
  name: string;
  email: string;
  password_hash: string;
  status: 'active' | 'inactive' | 'suspended';
  commission_percent: number;
  commission_fixed: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Location {
  id: string;
  location_id: string;
  name: string;
  ghl_location_id: string;
  password_hash: string;
  webhook_url?: string;
  webhook_secret?: string;
  is_active: boolean;
  settings?: {
    currency?: string;
    timezone?: string;
    default_kpis?: string[];
  };
  created_at: string;
  updated_at: string;
}

export interface Product {
  id: string;
  location_id: string;
  name: string;
  description?: string;
  price: number;
  currency: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface DateRange {
  from: Date;
  to: Date;
}

export interface KPIMetrics {
  leads: number;
  sales_count: number;
  revenue: number;
  ad_spend: number;
  impressions: number;
  clicks: number;
  surveys: number;
  demos: number;
  contracts: number;
  roas: number;
  cost_per_lead: number;
  conversion_rate: number;
}

export interface KPIConfig {
  id: string;
  location_id: string;
  page_type: 'ads' | 'organic' | 'outbound' | 'sales' | 'vendite' | 'prodotti';
  selected_kpis: string[];
  display_order: number[];
  created_at: string;
  updated_at: string;
}

export interface UTMFilters {
  source?: string;
  medium?: string;
  campaign?: string;
  content?: string;
  term?: string;
}

export interface ChartDataPoint {
  date: string;
  [key: string]: string | number;
}

export interface ChartMetric {
  key: string;
  label: string;
  color: string;
  format?: 'number' | 'currency' | 'percentage';
}

// Aggregated data interfaces
export interface SalesPerformance {
  sales: Sales;
  kpis: DailyKPI[];
  totals: KPIMetrics;
}

export interface LocationPerformance {
  location: Location;
  kpis: DailyKPI[];
  totals: KPIMetrics;
}

// API Response interfaces
export interface APIResponse<T> {
  data: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  count: number;
  page: number;
  limit: number;
  total_pages: number;
}

// Form interfaces
export interface SalesFormData {
  name: string;
  email: string;
  location_id: string;
  ghl_sales_id: string;
  status: 'active' | 'inactive' | 'suspended';
  commission_percent: number;
  commission_fixed: number;
  is_active: boolean;
}

export interface LocationFormData {
  location_id: string;
  name: string;
  ghl_location_id: string;
  webhook_url?: string;
  webhook_secret?: string;
  is_active: boolean;
  settings?: {
    currency?: string;
    timezone?: string;
    default_kpis?: string[];
  };
}

export interface ProductFormData {
  name: string;
  description?: string;
  price: number;
  currency: string;
  is_active: boolean;
}

// Settings interfaces
export interface AppSettings {
  id: string;
  location_id: string;
  kpi_configs: {
    [key: string]: {
      selected_kpis: string[];
      display_order: number[];
    };
  };
  date_formats: {
    display: string;
    api: string;
  };
  currency: string;
  timezone: string;
  created_at: string;
  updated_at: string;
}

// Filter interfaces
export interface KPIFilters {
  dateRange: DateRange;
  trafficSource?: 'ads' | 'organic' | 'outbound' | 'all';
  salesId?: string;
  locationId?: string;
  productId?: string;
  utmFilters?: UTMFilters;
}

// Available KPI options
export const AVAILABLE_KPIS = [
  { key: 'leads', label: 'Lead', format: 'number' },
  { key: 'sales_count', label: 'Vendite', format: 'number' },
  { key: 'revenue', label: 'Revenue', format: 'currency' },
  { key: 'ad_spend', label: 'Spesa ADS', format: 'currency' },
  { key: 'impressions', label: 'Impressioni', format: 'number' },
  { key: 'clicks', label: 'Click', format: 'number' },
  { key: 'surveys', label: 'Survey', format: 'number' },
  { key: 'demos', label: 'Demo', format: 'number' },
  { key: 'contracts', label: 'Contratti', format: 'number' },
  { key: 'roas', label: 'ROAS', format: 'number' },
  { key: 'cost_per_lead', label: 'Costo per Lead', format: 'currency' },
  { key: 'conversion_rate', label: 'Tasso Conversione', format: 'percentage' }
] as const;

export type KPIKey = typeof AVAILABLE_KPIS[number]['key'];