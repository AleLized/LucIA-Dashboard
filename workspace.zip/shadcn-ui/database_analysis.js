// Script per analizzare il database Supabase
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://xqehyjcrytigudfesjst.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhxZWh5amNyeXRpZ3VkZmVzanN0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTg4Nzk2NTAsImV4cCI6MjA3NDQ1NTY1MH0.n7fjg2S2qEuo9aR_aua83bx0M1FpB-yMP6Rt1898edQ';

const supabase = createClient(supabaseUrl, supabaseAnonKey);

async function analyzeDatabase() {
  console.log('=== ANALISI DATABASE SUPABASE ===\n');
  
  try {
    // 1. Test connessione
    console.log('1. TEST CONNESSIONE:');
    const { data: testData, error: testError } = await supabase
      .from('information_schema.tables')
      .select('table_name')
      .limit(1);
    
    if (testError) {
      console.log('   ✗ Errore connessione:', testError.message);
      return;
    } else {
      console.log('   ✓ Connessione al database riuscita');
    }

    // 2. Lista delle tabelle
    console.log('\n2. TABELLE NEL DATABASE:');
    const { data: tables, error: tablesError } = await supabase.rpc('get_schema_tables');
    
    if (tablesError) {
      // Metodo alternativo per ottenere le tabelle
      console.log('   Tentativo alternativo per ottenere le tabelle...');
      
      // Proviamo con alcune tabelle comuni che potrebbero esistere
      const commonTables = ['users', 'kpi_data', 'locations', 'sales', 'leads', 'products', 'auth_users'];
      
      for (const tableName of commonTables) {
        try {
          const { data, error } = await supabase
            .from(tableName)
            .select('*')
            .limit(1);
          
          if (!error) {
            console.log(`   ✓ Tabella trovata: ${tableName}`);
          }
        } catch (e) {
          // Tabella non esiste o non accessibile
        }
      }
    } else {
      tables.forEach(table => {
        console.log(`   - ${table.table_name}`);
      });
    }

    // 3. Analisi tabella users/auth
    console.log('\n3. ANALISI SISTEMA AUTENTICAZIONE:');
    
    // Prova con tabella users
    try {
      const { data: users, error: usersError } = await supabase
        .from('users')
        .select('*')
        .limit(5);
      
      if (!usersError && users) {
        console.log('   ✓ Tabella users trovata');
        console.log(`   - Numero utenti campione: ${users.length}`);
        if (users.length > 0) {
          console.log('   - Campi disponibili:', Object.keys(users[0]).join(', '));
          
          // Analizza i ruoli
          const roles = [...new Set(users.map(u => u.role).filter(Boolean))];
          console.log('   - Ruoli trovati:', roles.join(', '));
        }
      }
    } catch (e) {
      console.log('   ✗ Tabella users non accessibile');
    }

    // 4. Analisi dati KPI
    console.log('\n4. ANALISI DATI KPI:');
    
    try {
      const { data: kpiData, error: kpiError } = await supabase
        .from('kpi_data')
        .select('*')
        .limit(5);
      
      if (!kpiError && kpiData) {
        console.log('   ✓ Tabella kpi_data trovata');
        console.log(`   - Numero record campione: ${kpiData.length}`);
        if (kpiData.length > 0) {
          console.log('   - Campi disponibili:', Object.keys(kpiData[0]).join(', '));
        }
      }
    } catch (e) {
      console.log('   ✗ Tabella kpi_data non accessibile');
    }

    // 5. Analisi locations
    console.log('\n5. ANALISI LOCATIONS:');
    
    try {
      const { data: locations, error: locError } = await supabase
        .from('locations')
        .select('*')
        .limit(5);
      
      if (!locError && locations) {
        console.log('   ✓ Tabella locations trovata');
        console.log(`   - Numero locations: ${locations.length}`);
        if (locations.length > 0) {
          console.log('   - Campi disponibili:', Object.keys(locations[0]).join(', '));
          locations.forEach(loc => {
            console.log(`     * ${loc.name || loc.location_name || loc.id}: ${loc.id}`);
          });
        }
      }
    } catch (e) {
      console.log('   ✗ Tabella locations non accessibile');
    }

  } catch (error) {
    console.error('Errore generale:', error);
  }
}

// Esegui l'analisi
analyzeDatabase().then(() => {
  console.log('\n=== ANALISI COMPLETATA ===');
}).catch(error => {
  console.error('Errore durante l\'analisi:', error);
});