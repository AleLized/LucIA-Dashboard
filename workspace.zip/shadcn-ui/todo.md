# KPI Dashboard - TODO Implementation

## MVP Features to Implement:

### 1. Supabase Configuration ✅
- [x] Update Supabase client with correct credentials
- [x] Database schema already created with 11 tables

### 2. Core Components (8 files max)
- [ ] `src/lib/supabaseClient.ts` - Supabase configuration
- [ ] `src/components/Dashboard.tsx` - Main dashboard with sales table
- [ ] `src/components/SalesDetail.tsx` - Individual sales performance page
- [ ] `src/components/SalesSettings.tsx` - Sales management (add/remove/edit)
- [ ] `src/components/ProductSettings.tsx` - Product management with pricing
- [ ] `src/components/WebhookEndpoints.tsx` - Webhook system for GHL/Make.com
- [ ] `src/types/index.ts` - TypeScript interfaces
- [ ] `src/pages/Index.tsx` - Main app router

### 3. Key Functionalities:
- [ ] Sales table with all KPIs (except impression/click for outbound)
- [ ] Date range selector
- [ ] Column visibility toggle
- [ ] Budget allocation calculation (lead assegnati x costo medio ultimi 3 giorni)
- [ ] Sales detail page with traffic source breakdown
- [ ] Sales management with GHL ID mapping
- [ ] Product management with price history
- [ ] Webhook endpoints for real-time data updates
- [ ] Auto-detection of unknown sales/products

### 4. Database Integration:
- [ ] Use existing test account: `test_kpi_2025`
- [ ] Real-time KPI calculations
- [ ] Proper error handling
- [ ] Data validation

### 5. Deploy Ready:
- [ ] All files in correct structure
- [ ] No missing dependencies
- [ ] Fully functional MVP

## Implementation Priority:
1. Supabase client setup
2. Basic dashboard with sales table
3. Sales detail view
4. Settings pages
5. Webhook system
6. Testing with test data