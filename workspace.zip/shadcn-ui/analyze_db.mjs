import fetch from 'node-fetch';

const supabaseUrl = 'https://xqehyjcrytigudfesjst.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhxZWh5amNyeXRpZ3VkZmVzanN0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTg4Nzk2NTAsImV4cCI6MjA3NDQ1NTY1MH0.n7fjg2S2qEuo9aR_aua83bx0M1FpB-yMP6Rt1898edQ';

async function querySupabase(table, select = '*', limit = 5) {
  const url = `${supabaseUrl}/rest/v1/${table}?select=${select}&limit=${limit}`;
  
  try {
    const response = await fetch(url, {
      headers: {
        'apikey': supabaseAnonKey,
        'Authorization': `Bearer ${supabaseAnonKey}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=representation'
      }
    });

    if (response.ok) {
      const data = await response.json();
      return { data, error: null };
    } else {
      const errorText = await response.text();
      return { data: null, error: { message: errorText, status: response.status } };
    }
  } catch (error) {
    return { data: null, error: { message: error.message } };
  }
}

async function analyzeDatabase() {
  console.log('=== ANALISI DATABASE SUPABASE ===\n');
  
  // Lista delle tabelle probabili basata sul codice analizzato
  const probableTables = [
    'users', 'kpi_data', 'locations', 'sales_data', 'leads', 'products', 
    'sales_team', 'demos', 'discos', 'webhook_logs', 'settings',
    'auth.users', 'public.users', 'public.locations', 'public.kpi_data'
  ];

  console.log('1. TEST CONNESSIONE E RICERCA TABELLE:');
  
  const foundTables = [];
  
  for (const table of probableTables) {
    const { data, error } = await querySupabase(table, '*', 1);
    
    if (!error && data !== null) {
      foundTables.push(table);
      console.log(`   ✓ Tabella trovata: ${table}`);
    } else if (error && error.status !== 404) {
      console.log(`   ? Errore su ${table}: ${error.message}`);
    }
  }

  console.log(`\n   Totale tabelle trovate: ${foundTables.length}`);

  // Analisi dettagliata delle tabelle trovate
  for (const table of foundTables) {
    console.log(`\n2. ANALISI TABELLA: ${table.toUpperCase()}`);
    
    const { data, error } = await querySupabase(table, '*', 10);
    
    if (!error && data && data.length > 0) {
      console.log(`   - Record trovati: ${data.length}`);
      console.log(`   - Campi: ${Object.keys(data[0]).join(', ')}`);
      
      // Analisi specifica per tabella users
      if (table.includes('users')) {
        console.log('   - DETTAGLI UTENTI:');
        data.forEach((user, index) => {
          console.log(`     ${index + 1}. Email: ${user.email || user.user_email || 'N/A'}`);
          console.log(`        Role: ${user.role || user.user_role || 'N/A'}`);
          console.log(`        Name: ${user.name || user.full_name || user.display_name || 'N/A'}`);
          console.log(`        Location: ${user.location_id || user.location || 'N/A'}`);
        });
      }
      
      // Analisi specifica per locations
      if (table.includes('locations')) {
        console.log('   - DETTAGLI LOCATIONS:');
        data.forEach((location, index) => {
          console.log(`     ${index + 1}. ID: ${location.id || location.location_id}`);
          console.log(`        Name: ${location.name || location.location_name || 'N/A'}`);
          console.log(`        Type: ${location.type || location.location_type || 'N/A'}`);
        });
      }
      
      // Analisi specifica per kpi_data
      if (table.includes('kpi')) {
        console.log('   - DETTAGLI KPI DATA:');
        const sources = [...new Set(data.map(d => d.source || d.attribution_source).filter(Boolean))];
        const locations = [...new Set(data.map(d => d.location_id).filter(Boolean))];
        console.log(`     - Fonti di attribuzione: ${sources.join(', ')}`);
        console.log(`     - Location IDs: ${locations.join(', ')}`);
        
        if (data[0]) {
          console.log(`     - Esempio record: ${JSON.stringify(data[0], null, 2)}`);
        }
      }
      
    } else if (error) {
      console.log(`   ✗ Errore: ${error.message}`);
    } else {
      console.log('   - Tabella vuota');
    }
  }

  // Test di autenticazione
  console.log('\n3. TEST SISTEMA AUTENTICAZIONE:');
  
  // Prova a fare login con credenziali di test
  const testCredentials = [
    { email: 'admin@test.com', password: 'admin123' },
    { email: 'agency@test.com', password: 'agency123' },
    { email: 'sales@test.com', password: 'sales123' },
    { email: 'test@test.com', password: 'test123' }
  ];

  for (const cred of testCredentials) {
    try {
      const loginUrl = `${supabaseUrl}/auth/v1/token?grant_type=password`;
      const response = await fetch(loginUrl, {
        method: 'POST',
        headers: {
          'apikey': supabaseAnonKey,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          email: cred.email,
          password: cred.password
        })
      });

      if (response.ok) {
        const authData = await response.json();
        console.log(`   ✓ Login riuscito per: ${cred.email}`);
      } else {
        console.log(`   ✗ Login fallito per: ${cred.email}`);
      }
    } catch (error) {
      console.log(`   ? Errore login ${cred.email}: ${error.message}`);
    }
  }
}

analyzeDatabase().then(() => {
  console.log('\n=== ANALISI DATABASE COMPLETATA ===');
}).catch(error => {
  console.error('Errore durante l\'analisi:', error);
});