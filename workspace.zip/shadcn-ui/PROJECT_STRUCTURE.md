# LucIA KPI Platform - Project Structure

## 📁 Directory Overview

```
/workspace/shadcn-ui/
├── api/                          # API endpoints and webhook handlers
│   ├── webhooks/                 # Webhook integration endpoints
│   │   ├── ghl.ts               # GoHighLevel webhook handler
│   │   └── makecom.ts           # Make.com webhook handler
│   └── KpiEventReceiver.tsx     # KPI event processing component
├── components/                   # Reusable React components
│   ├── Layout/                  # Layout components
│   │   ├── Header.tsx           # Application header
│   │   ├── MainLayout.tsx       # Main layout wrapper
│   │   └── Sidebar.tsx          # Navigation sidebar
│   ├── ui/                      # UI components
│   │   ├── KPIConfigModal.tsx   # KPI configuration modal
│   │   ├── UTMFiltersPanel.tsx  # UTM filtering component
│   │   ├── MetaAdsDatePicker.tsx # Date range picker component
│   │   ├── KPICard.tsx          # KPI display card
│   │   ├── EditableCell.tsx     # Inline editing cell component
│   │   ├── CRUDModal.tsx        # Generic CRUD operations modal
│   │   └── ThresholdColorPicker.tsx # Color picker for thresholds
│   └── charts/                  # Chart and visualization components
│       ├── ModernKPIChart.tsx   # Modern KPI chart component
│       └── PerformanceChart.tsx # Performance visualization chart
├── lib/                         # Utility libraries and configurations
│   ├── webhookHandlers.ts       # Webhook processing utilities
│   ├── supabase.ts             # Supabase configuration
│   └── supabaseClient.ts       # Supabase client setup
├── hooks/                       # Custom React hooks
│   ├── useAuth.tsx             # Authentication hook
│   ├── useKPIData.ts           # KPI data management hook
│   ├── useCRUD.ts              # CRUD operations hook
│   └── useRealTimeEdit.ts      # Real-time editing hook
├── pages/                       # Application pages
│   ├── Dashboard.tsx           # Main dashboard page
│   ├── ADS.tsx                 # Ads performance page
│   ├── Organic.tsx             # Organic traffic performance page
│   ├── Outbound.tsx            # Outbound activities performance page
│   ├── Sales.tsx               # Sales team management page
│   ├── Vendite.tsx             # Sales transactions management page
│   ├── Prodotti.tsx            # Product management page
│   ├── Settings.tsx            # Application settings page
│   ├── AgencyDashboard.tsx     # Multi-location agency dashboard
│   └── DatabaseAdmin.tsx       # Database administration interface
├── src/                        # Source files
│   └── App.tsx                 # Main application component
├── docs/                       # Documentation files
│   ├── CHANGELOG.md            # Version history and changes
│   ├── FEATURES.md             # Feature documentation
│   └── PROJECT_STRUCTURE.md    # This file
└── database_verification_and_updates.sql # Database setup script
```

## 🏗️ Architecture Overview

### Frontend Architecture
- **React 18** with TypeScript for type safety
- **Component-based architecture** with reusable UI components
- **Custom hooks** for state management and business logic
- **Tailwind CSS** for styling with Shadcn-ui component library

### Backend Integration
- **Supabase** as Backend-as-a-Service (PostgreSQL database)
- **Real-time subscriptions** for live data updates
- **Webhook integration** for external data sources
- **RESTful API** patterns for data operations

### State Management
- **Zustand** for global state management
- **React Query/SWR** for server state management
- **Custom hooks** for component-level state

## 📦 Component Categories

### Layout Components (`/components/Layout/`)
**Purpose**: Provide consistent layout structure across the application

- **Header.tsx**: Top navigation bar with user actions and branding
- **MainLayout.tsx**: Main wrapper component that combines header and sidebar
- **Sidebar.tsx**: Navigation menu with route management

### UI Components (`/components/ui/`)
**Purpose**: Reusable interface elements with consistent styling

- **KPIConfigModal.tsx**: Modal for selecting and configuring KPI displays
- **UTMFiltersPanel.tsx**: Advanced UTM parameter filtering interface
- **MetaAdsDatePicker.tsx**: Date range selection with Meta Ads styling
- **KPICard.tsx**: Metric display cards with threshold-based coloring
- **EditableCell.tsx**: Inline editing functionality for table cells
- **CRUDModal.tsx**: Generic modal for create, read, update, delete operations
- **ThresholdColorPicker.tsx**: Color configuration for performance thresholds

### Chart Components (`/components/charts/`)
**Purpose**: Data visualization and analytics displays

- **ModernKPIChart.tsx**: Advanced KPI visualization with multiple chart types
- **PerformanceChart.tsx**: Performance metrics visualization with time-based analysis

## 🔧 Utility Libraries (`/lib/`)

### Database Integration
- **supabase.ts**: Supabase configuration and initialization
- **supabaseClient.ts**: Client-side Supabase connection management

### Webhook Processing
- **webhookHandlers.ts**: Centralized webhook processing logic
- **Data validation and sanitization** for incoming webhook data
- **Duplicate detection and handling** for data integrity

## 🎣 Custom Hooks (`/hooks/`)

### Authentication & Security
- **useAuth.tsx**: User authentication state and methods

### Data Management
- **useKPIData.ts**: KPI data fetching, caching, and real-time updates
- **useCRUD.ts**: Generic CRUD operations for all data entities
- **useRealTimeEdit.ts**: Real-time editing capabilities with optimistic updates

## 📄 Page Components (`/pages/`)

### Dashboard & Analytics
- **Dashboard.tsx**: Main overview with configurable KPI cards and charts
- **AgencyDashboard.tsx**: Multi-location performance overview

### Performance Pages
- **ADS.tsx**: Advertising campaign performance with UTM filtering
- **Organic.tsx**: Organic traffic analysis and SEO metrics
- **Outbound.tsx**: Outbound marketing campaign tracking

### Management Pages
- **Sales.tsx**: Sales team management with CRUD operations
- **Vendite.tsx**: Sales transaction management with inline editing
- **Prodotti.tsx**: Product catalog management

### Configuration
- **Settings.tsx**: Application configuration and user preferences
- **DatabaseAdmin.tsx**: Advanced database management interface

## 🔌 API Integration (`/api/`)

### Webhook Endpoints
- **webhooks/ghl.ts**: GoHighLevel integration for CRM data
- **webhooks/makecom.ts**: Make.com integration for automation workflows
- **KpiEventReceiver.tsx**: Central event processing for all webhook sources

## 🗄️ Database Schema

### Core Tables
- **kpi_events**: Main KPI data storage with UTM parameters
- **sales_reps**: Sales representative information and assignments
- **products**: Product catalog and performance metrics
- **settings**: Application configuration and user preferences
- **conversion_windows**: Configurable conversion tracking periods
- **threshold_colors**: Custom color schemes for performance indicators

### Relationships
- **One-to-Many**: Sales reps to sales transactions
- **Many-to-Many**: Products to sales transactions
- **Foreign Keys**: UTM parameters linked to performance data

## 🔄 Data Flow

### Real-time Updates
1. **Webhook Reception**: External data received via API endpoints
2. **Data Processing**: Validation, sanitization, and transformation
3. **Database Storage**: Upsert operations with conflict resolution
4. **Real-time Sync**: Supabase real-time subscriptions notify clients
5. **UI Updates**: Components automatically re-render with new data

### User Interactions
1. **User Action**: CRUD operation initiated through UI
2. **Optimistic Update**: UI immediately reflects changes
3. **API Call**: Data sent to Supabase
4. **Validation**: Server-side validation and processing
5. **Confirmation**: Success/error feedback to user
6. **Sync**: Real-time updates to other connected clients

## 🎨 Styling Architecture

### Design System
- **Tailwind CSS**: Utility-first CSS framework
- **Shadcn-ui**: Pre-built component library
- **Custom Components**: Extended components with business logic
- **Responsive Design**: Mobile-first approach with breakpoint management

### Theme Management
- **CSS Variables**: Dynamic theming support
- **Color Schemes**: Configurable color palettes for different metrics
- **Consistent Spacing**: Standardized padding and margin scales
- **Typography**: Consistent font hierarchy and sizing

## 🔒 Security Considerations

### Authentication
- **Supabase Auth**: Built-in authentication with JWT tokens
- **Row Level Security**: Database-level access control
- **API Security**: Webhook signature verification

### Data Protection
- **Input Validation**: Client and server-side validation
- **SQL Injection Prevention**: Parameterized queries
- **XSS Protection**: Content sanitization
- **HTTPS Enforcement**: Secure data transmission

## 📈 Performance Optimizations

### Frontend Optimizations
- **Code Splitting**: Lazy loading of page components
- **Memoization**: React.memo and useMemo for expensive operations
- **Virtual Scrolling**: Efficient rendering of large data sets
- **Image Optimization**: Compressed and responsive images

### Backend Optimizations
- **Database Indexing**: Optimized queries with proper indexes
- **Caching**: Redis caching for frequently accessed data
- **Connection Pooling**: Efficient database connection management
- **Query Optimization**: Minimized N+1 queries and efficient joins

## 🧪 Testing Strategy

### Unit Testing
- **Component Testing**: React Testing Library for UI components
- **Hook Testing**: Custom hook testing with React Hooks Testing Library
- **Utility Testing**: Jest for utility function testing

### Integration Testing
- **API Testing**: Webhook endpoint testing
- **Database Testing**: Supabase integration testing
- **E2E Testing**: Cypress for full user journey testing

## 🚀 Deployment Architecture

### Development Environment
- **Local Development**: Vite dev server with hot module replacement
- **Local Database**: Supabase local development setup
- **Environment Variables**: Secure configuration management

### Production Environment
- **Static Hosting**: Optimized build deployment
- **CDN**: Content delivery network for global performance
- **Database**: Production Supabase instance with backups
- **Monitoring**: Error tracking and performance monitoring

## 📋 Maintenance & Updates

### Code Organization
- **Modular Structure**: Clear separation of concerns
- **Consistent Naming**: Standardized naming conventions
- **Documentation**: Inline code documentation and README files
- **Version Control**: Git workflow with feature branches

### Dependency Management
- **Package Updates**: Regular dependency updates
- **Security Patches**: Automated security vulnerability fixes
- **Breaking Changes**: Careful handling of major version updates
- **Lock Files**: Consistent dependency versions across environments