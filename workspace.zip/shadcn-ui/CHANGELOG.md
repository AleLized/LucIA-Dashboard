# LucIA KPI Platform - Changelog

## [Unreleased] - 2025-01-XX

### 🔧 Bug Fixes & Improvements

#### Layout & UI Issues
- **Dashboard Padding**: Fixed excessive padding in dashboard main content area
- **Other Pages Padding**: Added appropriate internal padding to prevent content from being too close to container borders
- **Calendar Component**: 
  - Reduced calendar size for better UX
  - Improved internal organization and layout
  - Removed confusing day names display
  - Fixed day selection interface
  - Implemented proper date range selection functionality
- **Data Refresh Bug**: Fixed issue where data would change when clicking "Aggiorna" without changing any filters

#### Chart & Visualization Fixes
- **Time Range Selector**: Fixed non-functional time range selector in charts (weekly, monthly, annual)
- **Weekly View**: Now correctly shows current week data when "settimanale" is selected
- **Monthly View**: Now correctly shows current month data when "mensile" is selected
- **Annual View**: Now correctly shows full year data when "annuale" is selected
- **Date Range Consistency**: Fixed issue where applying the same date range would change data unexpectedly

#### Filter System Overhaul
- **UTM Filters**: Converted traffic source filters to proper UTM parameter filters
- **UTM Filter UI**: Redesigned UTM filter panel to be minimal and more efficient
- **Filter Consistency**: Applied proper UTM filtering across all relevant pages (Ads, Organic, Outbound)
- **Quarter Filter**: Added quarter filter option to all date range selectors

#### Data Display & Metrics
- **KPI Visibility**: Fixed issue where not all selected KPIs were visible
- **Monthly Totals**: Added total monthly data display at the top of relevant pages
- **Quarterly Totals**: Added total quarterly data display at the top of relevant pages

### ✨ New Features

#### CRUD Operations
- **Sales Management**: 
  - Create new sales representatives
  - Edit existing sales data
  - Delete sales representatives
  - Real-time database updates
- **Sales Details Page**: Added detailed view for individual sales representatives
- **Vendite Management**:
  - Edit sales transactions by double-clicking data cells
  - Create new sales transactions manually
  - Delete existing transactions
  - Assign/reassign transactions to sales representatives
  - Real-time database synchronization
- **Product Management**:
  - Create new products manually
  - Edit existing product data
  - Delete products
  - Real-time database updates

#### Enhanced Editing System
- **Inline Editing**: Double-click any data cell to edit
- **Save Functionality**: Click save button to update database in real-time
- **Grid Updates**: All data grids now support real-time editing capabilities

#### Improved Settings
- **Threshold Color Configuration**: Added ability to set custom colors for conversion rate thresholds
- **Conversion Window Settings**: Added configuration for conversion rate time windows (7-30 days)
- **Per-Metric Configuration**: Individual conversion window settings for each KPI metric

#### Sales Page Enhancements
- **Traffic Source Badges**: Added badges to identify which traffic sources each sales rep has data for
- **Badge Logic**: Dynamic badge display based on available data (Ads, Organic, Outbound combinations)
- **Removed Irrelevant Filters**: Removed UTM and traffic source filters (not applicable to sales data)

#### Vendite Page Improvements
- **Complete UTM Selection**: Added dropdown menus for all available UTM parameters
- **Manual Assignment**: Ability to manually assign sales transactions to representatives
- **Enhanced Filtering**: Proper UTM-based filtering system

#### Product Page Updates
- **Removed UTM Filters**: UTM filters removed as they're not relevant for product management
- **Focus on Product Data**: Streamlined interface focused on product-specific metrics

### 🏗️ Technical Improvements
- **Real-time Updates**: Implemented real-time database synchronization across all CRUD operations
- **Component Reusability**: Enhanced reusable components for consistent editing experience
- **Database Optimization**: Improved query efficiency for real-time operations
- **State Management**: Better state management for real-time data updates

### 📋 Removed Features
- **Irrelevant Filters**: Removed UTM filters from pages where they don't apply (Sales, Products)
- **Confusing UI Elements**: Removed confusing calendar day names and oversized components

---

## Previous Versions

### [1.0.0] - 2024-12-XX
- Initial release of LucIA KPI Platform
- Basic dashboard functionality
- Sales performance tracking
- Initial webhook integration
- Basic KPI visualization