# LucIA KPI System Design

## Implementation Approach

The LucIA KPI system is designed as a comprehensive sales performance tracking and management platform built with modern web technologies. The system uses **React with TypeScript** for the frontend, **Supabase** as the backend database and API layer, and **Tailwind CSS with Shadcn/ui** for the user interface.

### Key Technical Decisions:
- **Frontend**: React 18 + TypeScript + Vite for fast development and type safety
- **UI Framework**: Shadcn/ui components with Tailwind CSS for consistent design
- **Database**: PostgreSQL via Supabase with real-time subscriptions
- **Authentication**: Supabase Auth with custom location-based access control
- **State Management**: React Query for server state and React Context for client state
- **Deployment**: Cloudflare Pages for global CDN and edge computing

### Difficult Points Analysis:
1. **Sales Performance Calculation**: Complex budget allocation based on 3-day average lead costs
2. **Real-time Data Synchronization**: Webhook processing with rate limiting and retry logic
3. **Multi-tenant Architecture**: Location-based data isolation and access control
4. **Dynamic Product Pricing**: Historical price tracking without affecting past data
5. **Sales Ranking System**: Performance-based ranking with cached calculations

## Data Structures and Interfaces

### Core Database Schema

```mermaid
classDiagram
    class Location {
        +UUID id
        +String location_id
        +String password_hash
        +String name
        +String account_type
        +String parent_agency_id
        +String ghl_location_id
        +String webhook_url
        +String webhook_secret
        +Boolean is_active
        +JSONB settings
        +DateTime created_at
        +DateTime updated_at
        +authenticate(password: string) Boolean
        +updateSettings(settings: object) void
    }

    class Sales {
        +UUID id
        +String location_id
        +String ghl_sales_id
        +String name
        +String surname
        +String email
        +String phone
        +String password_hash
        +String status
        +Date hire_date
        +Date termination_date
        +Decimal base_commission_rate
        +JSONB settings
        +DateTime created_at
        +DateTime updated_at
        +calculatePerformance(dateFrom: Date, dateTo: Date) PerformanceData
        +getBudgetAllocation(dateFrom: Date, dateTo: Date) Decimal
        +getRanking(location_id: string, dateFrom: Date, dateTo: Date) Integer
    }

    class Product {
        +UUID id
        +String location_id
        +String product_id
        +String name
        +String description
        +Decimal current_price
        +String currency
        +String status
        +String category
        +JSONB settings
        +DateTime created_at
        +DateTime updated_at
        +updatePrice(newPrice: Decimal, reason: string) void
        +getPriceHistory() ProductPriceHistory[]
        +getCommissionForSales(sales_id: UUID) Commission
    }

    class DailyKpi {
        +UUID id
        +String location_id
        +Date date
        +String traffic_source
        +UUID sales_id
        +Integer impressions
        +Integer clicks
        +Integer leads
        +Integer surveys
        +Integer disco_inbound_prenotata
        +Integer disco_outbound_prenotata
        +Integer disco_showed_inbound
        +Integer disco_showed_outbound
        +Integer demos
        +Integer demos_showed
        +Integer pre_vendita
        +Integer vendita
        +Integer contratti
        +Decimal incassato
        +Decimal spesa_ads
        +Integer pack_1
        +Integer pack_2
        +Integer pack_3
        +Integer pack_4
        +Integer upsell_1
        +Integer upsell_2
        +Integer upsell_3
        +Integer chiamate_effettuate
        +Integer risposte_ricevute
        +String utm_source
        +String utm_medium
        +String utm_campaign
        +String utm_content
        +String utm_term
        +String custom_field_1
        +String custom_field_2
        +String custom_field_3
        +Decimal roas
        +Decimal aov
        +Decimal ctr
        +Decimal conversion_rate
        +Decimal cost_per_lead
        +DateTime created_at
        +DateTime updated_at
        +calculateMetrics() void
        +updateFromWebhook(payload: object) void
    }

    class SalesLeadAssignment {
        +UUID id
        +String location_id
        +UUID sales_id
        +String lead_id
        +String traffic_source
        +DateTime assigned_date
        +Decimal lead_cost
        +String lead_status
        +JSONB utm_data
        +JSONB custom_data
        +DateTime created_at
        +assignToSales(sales_id: UUID) void
        +updateStatus(status: string) void
        +calculateCost() Decimal
    }

    class SalesProductCommission {
        +UUID id
        +String location_id
        +UUID sales_id
        +UUID product_id
        +String commission_type
        +Decimal commission_value
        +String currency
        +DateTime effective_from
        +DateTime effective_to
        +Boolean is_active
        +DateTime created_at
        +DateTime updated_at
        +calculateCommission(sales_amount: Decimal) Decimal
        +isActiveForDate(date: Date) Boolean
    }

    class WebhookLog {
        +UUID id
        +String location_id
        +String webhook_type
        +JSONB payload
        +JSONB headers
        +String ip_address
        +String user_agent
        +String status
        +String error_message
        +DateTime processed_at
        +Integer retry_count
        +DateTime created_at
        +process() void
        +retry() void
        +markAsProcessed() void
    }

    class SalesPerformanceCache {
        +UUID id
        +String location_id
        +UUID sales_id
        +Date date_from
        +Date date_to
        +String traffic_source
        +Integer total_leads
        +Decimal total_budget_allocated
        +Decimal total_sales
        +Decimal total_commissions
        +Decimal performance_score
        +Integer ranking_position
        +JSONB metrics_data
        +DateTime last_calculated
        +DateTime created_at
        +refresh() void
        +isStale() Boolean
    }

    class RateLimit {
        +UUID id
        +String location_id
        +String ip_address
        +String endpoint
        +Integer request_count
        +DateTime window_start
        +DateTime window_end
        +Boolean is_blocked
        +DateTime created_at
        +DateTime updated_at
        +checkLimit() Boolean
        +incrementCount() void
        +resetWindow() void
    }

    %% Relationships
    Location ||--o{ Sales : "has many"
    Location ||--o{ Product : "has many"
    Location ||--o{ DailyKpi : "has many"
    Location ||--o{ WebhookLog : "has many"
    Location ||--o{ RateLimit : "has many"
    
    Sales ||--o{ DailyKpi : "has many"
    Sales ||--o{ SalesLeadAssignment : "has many"
    Sales ||--o{ SalesProductCommission : "has many"
    Sales ||--o{ SalesPerformanceCache : "has many"
    
    Product ||--o{ SalesProductCommission : "has many"
    
    DailyKpi ||--o{ SalesLeadAssignment : "relates to"
```

### Frontend Component Architecture

```mermaid
classDiagram
    class App {
        +Router router
        +AuthProvider authProvider
        +QueryClient queryClient
        +render() JSX.Element
    }

    class AuthProvider {
        +User currentUser
        +Location currentLocation
        +login(locationId: string, password: string) Promise~User~
        +logout() void
        +checkAuth() Boolean
    }

    class DashboardLayout {
        +Navigation navigation
        +Sidebar sidebar
        +MainContent mainContent
        +render() JSX.Element
    }

    class KpiDashboard {
        +DateRange dateRange
        +TrafficSource selectedSource
        +KpiData kpiData
        +fetchKpiData() Promise~KpiData~
        +updateDateRange(range: DateRange) void
        +render() JSX.Element
    }

    class SalesDashboard {
        +SalesData[] salesData
        +SalesFilters filters
        +SalesRanking ranking
        +fetchSalesData() Promise~SalesData[]~
        +updateFilters(filters: SalesFilters) void
        +render() JSX.Element
    }

    class SalesDetailView {
        +UUID salesId
        +SalesPerformance performance
        +LeadAssignment[] assignments
        +CommissionData commissions
        +fetchSalesDetail(id: UUID) Promise~SalesPerformance~
        +render() JSX.Element
    }

    class ProductManagement {
        +Product[] products
        +ProductForm productForm
        +PriceHistory[] priceHistory
        +createProduct(data: ProductData) Promise~Product~
        +updateProduct(id: UUID, data: ProductData) Promise~Product~
        +deleteProduct(id: UUID) Promise~void~
        +render() JSX.Element
    }

    class SalesManagement {
        +Sales[] salesTeam
        +SalesForm salesForm
        +createSales(data: SalesData) Promise~Sales~
        +updateSales(id: UUID, data: SalesData) Promise~Sales~
        +deleteSales(id: UUID) Promise~void~
        +render() JSX.Element
    }

    class WebhookReceiver {
        +WebhookLog[] logs
        +processWebhook(payload: object) Promise~void~
        +retryFailedWebhooks() Promise~void~
        +render() JSX.Element
    }

    class SettingsPanel {
        +SystemSettings settings
        +DisplayPreferences preferences
        +updateSettings(settings: SystemSettings) Promise~void~
        +updatePreferences(preferences: DisplayPreferences) Promise~void~
        +render() JSX.Element
    }

    %% Relationships
    App ||--|| AuthProvider : "provides"
    App ||--|| DashboardLayout : "renders"
    
    DashboardLayout ||--|| KpiDashboard : "contains"
    DashboardLayout ||--|| SalesDashboard : "contains"
    DashboardLayout ||--|| ProductManagement : "contains"
    DashboardLayout ||--|| SalesManagement : "contains"
    DashboardLayout ||--|| WebhookReceiver : "contains"
    DashboardLayout ||--|| SettingsPanel : "contains"
    
    SalesDashboard ||--|| SalesDetailView : "navigates to"
```

## Program Call Flow

### Main Application Flow

```mermaid
sequenceDiagram
    participant U as User
    participant A as App
    participant AP as AuthProvider
    participant SB as Supabase
    participant KD as KpiDashboard
    participant SD as SalesDashboard
    participant WH as WebhookReceiver

    U->>A: Access Application
    A->>AP: Check Authentication
    AP->>SB: Verify Session
    SB-->>AP: Session Status
    
    alt Not Authenticated
        AP->>U: Show Login Form
        U->>AP: Submit Credentials (location_id, password)
        AP->>SB: Authenticate User
        SB-->>AP: Authentication Result
        AP->>A: Set User Context
    end
    
    A->>KD: Initialize KPI Dashboard
    KD->>SB: Fetch KPI Data
    SB-->>KD: Return KPI Data
    KD->>KD: Process and Display Data
    
    A->>SD: Initialize Sales Dashboard
    SD->>SB: Fetch Sales Performance Data
    SB-->>SD: Return Sales Data
    SD->>SD: Calculate Rankings
    SD->>SD: Display Sales Performance
    
    par Webhook Processing
        WH->>SB: Listen for Webhook Events
        SB-->>WH: New Webhook Data
        WH->>WH: Process Webhook Payload
        WH->>SB: Update KPI Data
        WH->>KD: Trigger Data Refresh
        WH->>SD: Trigger Sales Data Refresh
    end
```

### Webhook Processing Flow

```mermaid
sequenceDiagram
    participant EXT as External System (GHL/Make.com)
    participant WH as Webhook Endpoint
    participant RL as Rate Limiter
    participant WL as Webhook Logger
    participant DP as Data Processor
    participant DB as Database
    participant CACHE as Performance Cache
    participant UI as User Interface

    EXT->>WH: POST Webhook Data
    WH->>RL: Check Rate Limits
    RL-->>WH: Rate Limit Status
    
    alt Rate Limit Exceeded
        WH-->>EXT: 429 Too Many Requests
    else Rate Limit OK
        WH->>WL: Log Webhook Request
        WL->>DB: Insert Webhook Log
        
        WH->>DP: Process Webhook Payload
        DP->>DP: Validate Payload Structure
        DP->>DP: Extract KPI Data
        DP->>DP: Identify Sales Assignment
        
        alt Sales ID Present
            DP->>DB: Check Sales Exists
            DB-->>DP: Sales Status
            
            alt Sales Not Found
                DP->>DB: Create Pending Sales
                DP->>UI: Notify Admin of Pending Sales
            end
        end
        
        DP->>DB: Insert/Update Daily KPI
        DP->>DB: Update Lead Assignments
        DP->>DB: Calculate Metrics
        
        DP->>CACHE: Invalidate Performance Cache
        CACHE->>DB: Recalculate Sales Performance
        
        DP->>WL: Mark Webhook as Processed
        WH-->>EXT: 200 OK
        
        DP->>UI: Trigger Real-time Updates
    end
```

### Sales Performance Calculation Flow

```mermaid
sequenceDiagram
    participant UI as User Interface
    participant SP as Sales Performance Service
    participant DB as Database
    participant CALC as Calculator Functions
    participant CACHE as Performance Cache

    UI->>SP: Request Sales Performance (date range)
    SP->>CACHE: Check Cache Validity
    CACHE-->>SP: Cache Status
    
    alt Cache Valid
        CACHE-->>SP: Return Cached Data
        SP-->>UI: Display Performance Data
    else Cache Invalid/Missing
        SP->>DB: Fetch Sales Data
        SP->>DB: Fetch Lead Assignments
        SP->>DB: Fetch KPI Data
        
        par Calculate Budget Allocation
            SP->>CALC: Calculate Average Lead Cost (3 days)
            CALC->>DB: Query Historical Lead Costs
            DB-->>CALC: Lead Cost Data
            CALC-->>SP: Average Cost per Lead
            
            SP->>CALC: Calculate Total Budget Allocated
            CALC->>DB: Count Assigned Leads
            DB-->>CALC: Lead Count Data
            CALC-->>SP: Total Budget Amount
        end
        
        par Calculate Sales Metrics
            SP->>CALC: Calculate Total Sales
            CALC->>DB: Sum Sales Revenue
            DB-->>CALC: Revenue Data
            CALC-->>SP: Total Revenue
            
            SP->>CALC: Calculate Commissions
            CALC->>DB: Get Commission Rates
            DB-->>CALC: Commission Data
            CALC-->>SP: Total Commissions
        end
        
        SP->>CALC: Calculate Performance Score
        CALC-->>SP: Performance Score (ROAS)
        
        SP->>DB: Calculate Rankings
        DB-->>SP: Ranking Positions
        
        SP->>CACHE: Update Performance Cache
        SP-->>UI: Display Performance Data
    end
```

### Product Management Flow

```mermaid
sequenceDiagram
    participant U as User
    participant PM as Product Management
    participant PF as Product Form
    participant DB as Database
    participant PH as Price History
    participant COM as Commission Manager

    U->>PM: Access Product Management
    PM->>DB: Fetch Products
    DB-->>PM: Return Products List
    PM-->>U: Display Products
    
    U->>PM: Create New Product
    PM->>PF: Show Product Form
    U->>PF: Fill Product Details
    PF->>PF: Validate Form Data
    PF->>DB: Insert New Product
    DB->>PH: Create Initial Price History
    PH->>DB: Insert Price Record
    DB-->>PF: Product Created
    PF-->>U: Success Message
    
    U->>PM: Update Product Price
    PM->>PF: Show Price Update Form
    U->>PF: Enter New Price + Reason
    PF->>DB: Update Product Current Price
    DB->>PH: Create New Price History Entry
    PH->>PH: Set Previous Price End Date
    PH->>DB: Insert New Price Record
    DB-->>PF: Price Updated
    PF-->>U: Success Message
    
    U->>PM: Set Sales Commission
    PM->>COM: Show Commission Form
    U->>COM: Set Commission Rate/Amount
    COM->>DB: Insert/Update Commission Record
    DB-->>COM: Commission Set
    COM-->>U: Success Message
```

## Anything UNCLEAR

### Clarifications Needed:

1. **Sales Login System**: For the individual sales dashboard, should sales members have separate login credentials or use their GHL ID + a system-generated password?

2. **Webhook Payload Format**: What is the exact structure of webhook payloads from GHL and Make.com? This affects data validation and processing logic.

3. **Commission Calculation Timing**: Should commissions be calculated in real-time when sales data arrives, or batch-processed daily/weekly?

4. **Data Retention Policy**: How long should webhook logs, performance cache, and historical data be retained?

5. **Multi-Currency Support**: Should the system support multiple currencies for international locations, or is EUR sufficient?

6. **Rate Limiting Thresholds**: What are the specific rate limiting requirements (requests per minute/hour) for webhook endpoints?

7. **Sales Territory Management**: Should sales be able to see leads/performance from other territories within the same location?

8. **Backup and Recovery**: What are the backup requirements for the database and how should disaster recovery be handled?

### Technical Assumptions Made:

- **Authentication**: Using location_id + password for main dashboard, sales_id + password for individual sales dashboard
- **Real-time Updates**: Using Supabase real-time subscriptions for live data updates
- **Caching Strategy**: Performance data cached for 1 hour, invalidated on new data arrival
- **Error Handling**: Webhook failures retry up to 3 times with exponential backoff
- **Data Validation**: Strict validation on all incoming webhook data with detailed error logging
- **Scalability**: Designed for up to 30 locations with 10 sales each, 5 years of historical data
- **Security**: All sensitive data encrypted, API endpoints protected with proper authentication
- **Deployment**: Optimized for Cloudflare Pages with edge caching and global distribution

The system is designed to be highly scalable, maintainable, and user-friendly while providing comprehensive sales performance tracking and management capabilities.